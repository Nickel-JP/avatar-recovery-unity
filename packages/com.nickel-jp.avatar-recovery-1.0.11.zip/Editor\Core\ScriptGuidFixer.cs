














using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class ScriptGuidFixer
    {
        #region 定数

        
        private const long StubFileID = 11500000;

        
        private static readonly string[] ScriptFolderNames = { ".Scripts", "Scripts" };

        #endregion

        #region 公開 DTO

        
        
        
        public class ScriptMapping
        {
            
            public string OldKey { get; set; }

            
            public string NewYaml { get; set; }

            
            public string TypeFullName { get; set; }

            
            public Type ResolvedType { get; set; }

            
            public bool Seen { get; set; }

            
            public int ReplaceCount { get; set; }
        }

        
        public class FixResult
        {
            
            public int MappingCount { get; set; }

            
            public int FixedFileCount { get; set; }

            
            public int FixedReferenceCount { get; set; }

            
            public List<string> UnresolvedTypes { get; set; } = new List<string>();

            
            public int UnseenMappings { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        
        
        
        
        public static FixResult FixFolder(string targetFolder)
        {
            var result = new FixResult();

            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder))
            {
                Debug.LogWarning($"[AvatarRecovery] FixScripts: フォルダーが存在しません: {targetFolder}");
                return result;
            }

            
            var scriptFolders = FindScriptFolders(targetFolder);
            if (scriptFolders.Count == 0)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] FixScripts: \"Scripts\" / \".Scripts\" フォルダーが見つかりません: {targetFolder}");
                return result;
            }

            
            var mappings = BuildMappingsFromScriptFolders(scriptFolders);
            if (mappings.Count == 0)
            {
                Debug.LogWarning("[AvatarRecovery] FixScripts: 有効な .cs.meta が見つかりませんでした。");
                return result;
            }

            result.MappingCount = mappings.Count;

            
            ResolveMappings(mappings, result);

            
            var assetExtensions = new[] { "*.prefab", "*.controller", "*.asset", "*.unity" };
            var animExtension   = "*.anim";

            var allAssetPaths = new List<string>();
            foreach (var ext in assetExtensions)
                allAssetPaths.AddRange(Directory.GetFiles(targetFolder, ext, SearchOption.AllDirectories));
            var allAnimPaths = Directory.GetFiles(targetFolder, animExtension, SearchOption.AllDirectories);

            int fileCount = 0;
            int refCount  = 0;

            foreach (var filePath in allAssetPaths)
            {
                var (modified, replaces) = FixAssetFile(filePath, mappings);
                if (modified) { fileCount++; refCount += replaces; }
            }

            foreach (var filePath in allAnimPaths)
            {
                var (modified, replaces) = FixAnimationFile(filePath, mappings);
                if (modified) { fileCount++; refCount += replaces; }
            }

            result.FixedFileCount      = fileCount;
            result.FixedReferenceCount = refCount;
            result.UnseenMappings      = mappings.Values.Count(m => !m.Seen);

            Debug.Log(
                $"[AvatarRecovery] FixScripts 完了: " +
                $"{result.FixedFileCount} ファイル / {result.FixedReferenceCount} 参照を修正 " +
                $"(マッピング: {result.MappingCount}, 未解決型: {result.UnresolvedTypes.Count})");

            return result;
        }

        
        
        
        
        public static void DeleteScriptFolders(string targetFolder)
        {
            var folders = FindScriptFolders(targetFolder);
            foreach (var folder in folders)
            {
                try
                {
                    Directory.Delete(folder, recursive: true);
                    var metaPath = folder + ".meta";
                    if (File.Exists(metaPath)) File.Delete(metaPath);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] スクリプトフォルダー削除失敗 '{folder}': {ex.Message}");
                }
            }
        }

        #endregion

        #region 内部実装 - フォルダー検索とマッピング構築

        
        private static List<string> FindScriptFolders(string targetFolder)
        {
            var result = new List<string>();
            try
            {
                foreach (var name in ScriptFolderNames)
                {
                    var found = Directory.GetDirectories(
                        targetFolder, name, SearchOption.AllDirectories);
                    result.AddRange(found.Select(p => p.Replace('\\', '/')));
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] スクリプトフォルダー検索エラー: {ex.Message}");
            }
            return result;
        }

        
        
        
        
        
        
        
        
        
        
        private static Dictionary<string, ScriptMapping> BuildMappingsFromScriptFolders(
            List<string> scriptFolders)
        {
            var mappings = new Dictionary<string, ScriptMapping>();
            var typeNameLookup = new Dictionary<string, ScriptMapping>();

            foreach (var scriptFolder in scriptFolders)
            {
                string[] metaPaths;
                try
                {
                    metaPaths = Directory.GetFiles(scriptFolder, "*.cs.meta", SearchOption.AllDirectories)
                        .Select(p => p.Replace('\\', '/')).ToArray();
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[AvatarRecovery] .meta 列挙失敗 '{scriptFolder}': {ex.Message}");
                    continue;
                }

                foreach (var metaPath in metaPaths)
                {
                    try
                    {
                        var typeFullName = ExtractTypeFullName(metaPath, scriptFolder);
                        if (string.IsNullOrEmpty(typeFullName)) continue;

                        var stubGuid = ReadGuidFromMeta(metaPath);
                        if (string.IsNullOrEmpty(stubGuid)) continue;

                        var oldKey = $"fileID: {StubFileID}, guid: {stubGuid}";
                        if (mappings.ContainsKey(oldKey)) continue;

                        
                        if (!typeNameLookup.TryGetValue(typeFullName, out var mapping))
                        {
                            mapping = new ScriptMapping { TypeFullName = typeFullName };
                            typeNameLookup[typeFullName] = mapping;
                        }

                        mappings[oldKey] = mapping;
                        
                        
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] .meta 解析失敗 '{metaPath}': {ex.Message}");
                    }
                }
            }

            
            foreach (var kv in mappings) kv.Value.OldKey = kv.Key;

            return mappings;
        }

        
        
        
        
        
        
        
        
        
        
        private static string ExtractTypeFullName(string metaPath, string scriptFolder)
        {
            var rel = metaPath.Replace(scriptFolder + "/", "");
            
            var firstSlash = rel.IndexOf('/');
            if (firstSlash < 0) return null; 

            
            const string ext = ".cs.meta";
            if (!rel.EndsWith(ext, StringComparison.OrdinalIgnoreCase)) return null;

            
            var typePath = rel.Substring(firstSlash + 1, rel.Length - firstSlash - 1 - ext.Length);
            if (string.IsNullOrEmpty(typePath)) return null;

            return typePath.Replace('/', '.');
        }

        
        
        
        
        private static string ReadGuidFromMeta(string metaPath)
        {
            try
            {
                using (var reader = LongPathIO.OpenReader(metaPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("guid:", StringComparison.Ordinal))
                            return line.Substring(5).Trim();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] .meta 読み取り失敗 '{metaPath}': {ex.Message}");
            }
            return null;
        }

        #endregion

        #region 内部実装 - 型解決

        
        
        
        
        
        
        private static void ResolveMappings(
            Dictionary<string, ScriptMapping> mappings, FixResult result)
        {
            
            var allTypes = AllAvailableScriptTypes();
            var typeLookup = allTypes.ToDictionary(t => t.FullName, t => t);

            
            var resolvedTypeNames = new HashSet<string>();

            foreach (var mapping in mappings.Values)
            {
                if (resolvedTypeNames.Contains(mapping.TypeFullName)) continue;
                resolvedTypeNames.Add(mapping.TypeFullName);

                if (!typeLookup.TryGetValue(mapping.TypeFullName, out var foundType))
                {
                    result.UnresolvedTypes.Add(mapping.TypeFullName);
                    continue;
                }

                mapping.ResolvedType = foundType;

                if (TryGetMonoScriptGuid(foundType, out var newGuid, out var newFileID))
                {
                    mapping.NewYaml = $"{{fileID: {newFileID}, guid: {newGuid}, type: 3}}";
                }
                else
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] MonoScript の GUID 取得失敗: {mapping.TypeFullName}");
                    result.UnresolvedTypes.Add(mapping.TypeFullName);
                }
            }
        }

        
        private static List<Type> AllAvailableScriptTypes()
        {
            var result = new List<Type>();

            
            result.AddRange(TypeCache.GetTypesDerivedFrom<MonoBehaviour>()
                .Where(t => t.DeclaringType == null && !t.IsAbstract));

            
            result.AddRange(TypeCache.GetTypesDerivedFrom<ScriptableObject>()
                .Where(t => t.DeclaringType == null && !t.IsAbstract
                            && !t.IsSubclassOf(typeof(StateMachineBehaviour))));

            
            result.AddRange(TypeCache.GetTypesDerivedFrom<StateMachineBehaviour>()
                .Where(t => t.DeclaringType == null && !t.IsAbstract));

            return result;
        }

        
        
        
        
        
        
        
        
        
        
        private static bool TryGetMonoScriptGuid(Type type, out string guid, out long fileID)
        {
            guid   = null;
            fileID = 0;

            try
            {
                MonoScript ms = null;

                if (type.IsSubclassOf(typeof(ScriptableObject)))
                {
                    var temp = ScriptableObject.CreateInstance(type);
                    if (temp != null)
                    {
                        ms = MonoScript.FromScriptableObject(temp);
                        UnityEngine.Object.DestroyImmediate(temp);
                    }
                }
                else if (type.IsSubclassOf(typeof(MonoBehaviour)))
                {
                    var tempGo = EditorUtility.CreateGameObjectWithHideFlags(
                        "AvatarRecovery_TempScriptResolve", HideFlags.HideAndDontSave);
                    MonoBehaviour tempComp = null;
                    try
                    {
                        
                        
                        tempComp = ComponentDependencyResolver.TryAddComponent(tempGo, type) as MonoBehaviour;
                        if (tempComp != null)
                            ms = MonoScript.FromMonoBehaviour(tempComp);
                    }
                    finally
                    {
                        
                        
                        
                        if (tempComp != null) UnityEngine.Object.DestroyImmediate(tempComp);
                        UnityEngine.Object.DestroyImmediate(tempGo);
                    }
                }

                if (ms == null) return false;

                if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(
                        ms, out var g, out long fid))
                {
                    guid   = g;
                    fileID = fid;
                    return true;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] MonoScript 解決例外 ({type.FullName}): {ex.Message}");
            }
            return false;
        }

        #endregion

        #region 内部実装 - YAML テキスト置換

        
        
        
        
        
        
        
        
        
        
        private static (bool modified, int replaces) FixAssetFile(
            string filePath, Dictionary<string, ScriptMapping> mappings)
        {
            int replaces = 0;
            var tempPath = filePath + ".avatar_recovery_tmp";

            try
            {
                
                
                using (var reader = LongPathIO.OpenReader(filePath))
                using (var writer = LongPathIO.OpenWriter(tempPath, append: false))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("--- !u!114 ", StringComparison.Ordinal))
                        {
                            
                            writer.WriteLine(line);
                            
                            do
                            {
                                line = reader.ReadLine();
                                if (line == null) break;
                                if (line.StartsWith("  m_Script: ", StringComparison.Ordinal)) break;
                                writer.WriteLine(line);
                            }
                            while (true);

                            if (line == null) break;

                            if (line.Contains("guid:"))
                            {
                                var key = ExtractFileIdGuidKey(line);
                                if (key != null && mappings.TryGetValue(key, out var mapping))
                                {
                                    mapping.Seen = true;
                                    if (!string.IsNullOrEmpty(mapping.NewYaml))
                                    {
                                        line = $"  m_Script: {mapping.NewYaml}";
                                        mapping.ReplaceCount++;
                                        replaces++;
                                    }
                                }
                            }
                        }
                        writer.WriteLine(line);
                    }
                }

                if (replaces > 0)
                {
                    
                    AtomicReplace(filePath, tempPath);
                    return (true, replaces);
                }
                else
                {
                    File.Delete(tempPath);
                    return (false, 0);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] FixAssetFile 失敗 '{Path.GetFileName(filePath)}': {ex.Message}");
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
                return (false, 0);
            }
        }

        
        
        
        
        
        
        
        private static (bool modified, int replaces) FixAnimationFile(
            string filePath, Dictionary<string, ScriptMapping> mappings)
        {
            int replaces = 0;
            var tempPath = filePath + ".avatar_recovery_tmp";
            var seenSubAssets = new Dictionary<ScriptMapping, string>();

            try
            {
                
                using (var reader = LongPathIO.OpenReader(filePath))
                using (var writer = LongPathIO.OpenWriter(tempPath, append: false))
                {
                    string line = reader.ReadLine();
                    while (line != null)
                    {
                        
                        while (line != null && !line.StartsWith("--- !u!74 ", StringComparison.Ordinal))
                        {
                            writer.WriteLine(line);
                            line = reader.ReadLine();
                        }
                        if (line == null) break;

                        var subAssetHeader = line;
                        writer.WriteLine(line);
                        line = reader.ReadLine();

                        
                        while (line != null && !line.StartsWith("--- !u!", StringComparison.Ordinal))
                        {
                            if (line.Contains("    script: {fileID:") && line.Contains("guid:"))
                            {
                                var key = ExtractFileIdGuidKey(line);
                                if (key != null && mappings.TryGetValue(key, out var mapping))
                                {
                                    mapping.Seen = true;
                                    if (!string.IsNullOrEmpty(mapping.NewYaml))
                                    {
                                        
                                        var ws = line.Length - line.TrimStart().Length;
                                        line = $"{new string(' ', ws)}script: {mapping.NewYaml}";

                                        
                                        if (!seenSubAssets.TryGetValue(mapping, out var lastSub) ||
                                            lastSub != subAssetHeader)
                                        {
                                            seenSubAssets[mapping] = subAssetHeader;
                                            mapping.ReplaceCount++;
                                            replaces++;
                                        }
                                    }
                                }
                            }
                            writer.WriteLine(line);
                            line = reader.ReadLine();
                        }
                    }
                }

                if (replaces > 0)
                {
                    AtomicReplace(filePath, tempPath);
                    return (true, replaces);
                }
                else
                {
                    File.Delete(tempPath);
                    return (false, 0);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] FixAnimationFile 失敗 '{Path.GetFileName(filePath)}': {ex.Message}");
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
                return (false, 0);
            }
        }

        
        
        
        
        
        private static string ExtractFileIdGuidKey(string line)
        {
            try
            {
                int start = line.IndexOf("fileID");
                if (start < 0) return null;
                int end = line.LastIndexOf(',');
                if (end <= start) return null;
                return line.Substring(start, end - start);
            }
            catch
            {
                return null;
            }
        }

        
        
        
        
        
        
        
        private static void AtomicReplace(string targetPath, string tempPath)
        {
            if (!LongPathIO.TryAtomicReplace(tempPath, targetPath))
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] AtomicReplace 失敗: " +
                    $"temp='{Path.GetFileName(tempPath)}' → target='{Path.GetFileName(targetPath)}'。" +
                    "ファイルが別プロセスでロックされている可能性があります。");
            }
        }

        #endregion
    }
}
