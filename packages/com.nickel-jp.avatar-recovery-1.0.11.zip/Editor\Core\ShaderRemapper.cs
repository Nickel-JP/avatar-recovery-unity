






using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class ShaderRemapper
    {
        #region 定数

        
        private static readonly string[] PreferredShaderNames =
        {
            ".poiyomi/Poiyomi Toon",        
            "Poiyomi/Poiyomi Toon",
            "arktoon/Opaque",               
            "lilToon",                      
            "VRChat/Mobile/Toon Lit",       
            "Standard"                      
        };

        
        private static readonly string[] PreviewFallbackShaderNames =
        {
            "lilToon",
            ".poiyomi/Poiyomi Toon",
            "Poiyomi/Poiyomi Toon",
            ".poiyomi/Poiyomi Pro",
            "Poiyomi/Poiyomi Pro",
            "Standard"
        };

        #endregion

        #region 公開 API

        
        
        
        
        
        
        public static int RemapInFolder(string assetFolder)
        {
            var guids = AssetDatabase.FindAssets("t:Material", new[] { assetFolder });
            int count = 0;

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var mat  = AssetDatabase.LoadAssetAtPath<Material>(path);

                if (mat == null) continue;

                if (RemapMaterial(mat))
                {
                    EditorUtility.SetDirty(mat);
                    count++;
                }
            }

            if (count > 0)
            {
                AssetDatabase.SaveAssets();
                Debug.Log($"[AvatarRecovery] シェーダー再割り当て: {count} 件のマテリアルを更新しました");
            }

            return count;
        }

        
        
        
        
        
        public static bool RemapMaterial(Material mat)
        {
            if (mat == null) return false;

            
            if (mat.shader != null &&
                mat.shader.name != "Hidden/InternalErrorShader" &&
                mat.shader.name != "Standard (Specular setup)" &&
                !mat.shader.name.StartsWith("Hidden/"))
            {
                return false;
            }

            var replacement = FindBestShader();
            if (replacement == null)
            {
                Debug.LogWarning($"[AvatarRecovery] 代替シェーダーが見つかりません: {mat.name}");
                return false;
            }

            Debug.Log($"[AvatarRecovery] シェーダー置換: {mat.name}  " +
                      $"{mat.shader?.name ?? "null"} → {replacement.name}");

            mat.shader = replacement;
            return true;
        }

        
        
        
        
        
        
        public static int RemapOnGameObject(GameObject root)
        {
            if (root == null) return 0;

            var renderers = root.GetComponentsInChildren<Renderer>(includeInactive: true);
            int count = 0;

            foreach (var renderer in renderers)
            {
                var mats = renderer.sharedMaterials;
                bool changed = false;

                for (int i = 0; i < mats.Length; i++)
                {
                    if (RemapMaterial(mats[i]))
                    {
                        changed = true;
                        count++;
                    }
                }

                if (changed)
                {
                    renderer.sharedMaterials = mats;
                    
                    
                    
                    EditorUtility.SetDirty(renderer);
                }
            }

            return count;
        }

        
        
        
        
        
        public static int RemapOnGameObjectForPreview(
            GameObject root,
            List<Material> createdMaterials)
        {
            if (root == null) return 0;

            var replacement = FindBestPreviewShader();
            if (replacement == null)
            {
                Debug.LogWarning("[AvatarRecovery] Preview用の代替シェーダーが見つかりません。");
                return 0;
            }

            var renderers = root.GetComponentsInChildren<Renderer>(includeInactive: true);
            int count = 0;

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;

                var sourceMaterials = renderer.sharedMaterials;
                if (sourceMaterials == null || sourceMaterials.Length == 0)
                    continue;

                var previewMaterials = new Material[sourceMaterials.Length];
                bool assigned = false;

                for (int i = 0; i < sourceMaterials.Length; i++)
                {
                    var source = sourceMaterials[i];
                    if (source == null)
                        continue;

                    Material previewMaterial;
                    try
                    {
                        previewMaterial = new Material(source)
                        {
                            name = $"{source.name} (Preview)",
                            hideFlags = HideFlags.HideAndDontSave
                        };
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] Preview Material複製失敗 '{source.name}': {ex.Message}");
                        previewMaterials[i] = source;
                        continue;
                    }

                    createdMaterials?.Add(previewMaterial);
                    if (previewMaterial.shader != replacement)
                    {
                        previewMaterial.shader = replacement;
                        count++;
                    }

                    previewMaterials[i] = previewMaterial;
                    assigned = true;
                }

                if (assigned)
                    renderer.sharedMaterials = previewMaterials;
            }

            return count;
        }

        
        
        
        
        public static Shader FindBestShader()
        {
            foreach (var name in PreferredShaderNames)
            {
                var shader = Shader.Find(name);
                if (shader != null) return shader;
            }

            return null;
        }

        private static Shader FindBestPreviewShader()
        {
            foreach (var name in PreviewFallbackShaderNames)
            {
                var shader = Shader.Find(name);
                if (shader != null) return shader;
            }

            return null;
        }

        
        
        
        public static List<string> GetAvailableShaders()
        {
            var result = new List<string>();
            foreach (var name in PreferredShaderNames)
            {
                if (Shader.Find(name) != null)
                    result.Add(name);
            }
            return result;
        }

        #endregion
    }
}
