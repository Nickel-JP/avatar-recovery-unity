












using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class AvatarRecoveryValidators
    {
        #region 定数 (型名定義)

        private const string TypeVRCPhysBone =
            "VRC.SDK3.Dynamics.PhysBone.Components.VRCPhysBone";
        private const string TypeVRCPhysBoneCollider =
            "VRC.SDK3.Dynamics.PhysBone.Components.VRCPhysBoneCollider";
        private const string TypeVRCContactReceiver =
            "VRC.SDK3.Dynamics.Contact.Components.VRCContactReceiver";
        private const string TypeVRCContactSender =
            "VRC.SDK3.Dynamics.Contact.Components.VRCContactSender";

        private const string LogTag = "[SARS]";

        #endregion

        #region MenuItem (パターン H)

        [MenuItem("AvatarRecovery/PhysBone・Contact 参照チェック", priority = 50)]
        private static void MenuValidatePhysBones()
        {
            var target = Selection.activeGameObject;
            if (target == null)
            {
                EditorUtility.DisplayDialog(
                    "PhysBone 参照チェック",
                    "ヒエラルキーでチェック対象の GameObject を選択してから実行してください。\n\n" +
                    "通常は復元したアバターのルートを選択します。",
                    "OK");
                return;
            }

            ValidatePhysBones(target);
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        
        
        public static void ValidatePhysBones(GameObject root)
        {
            if (root == null)
            {
                Debug.LogError($"{LogTag} ValidatePhysBones: root が null です");
                return;
            }

            var issues   = new List<string>();
            var warnings = new List<string>();

            int pbCount   = 0;
            int pbColl    = 0;
            int recvCount = 0;
            int sendCount = 0;

            
            var components = root.GetComponentsInChildren<Component>(includeInactive: true);
            foreach (var comp in components)
            {
                if (comp == null) continue;
                var typeName = comp.GetType().FullName;
                if (string.IsNullOrEmpty(typeName)) continue;

                switch (typeName)
                {
                    case TypeVRCPhysBone:
                        pbCount++;
                        CheckObjectRef(comp, "rootTransform",
                            out bool pbIsNull);
                        if (pbIsNull)
                        {
                            issues.Add(
                                $"ℹ️ PhysBone '{comp.gameObject.name}': " +
                                "rootTransform 未指定 (自身を root として動作。意図的でなければ確認推奨)");
                        }
                        break;

                    case TypeVRCPhysBoneCollider:
                        pbColl++;
                        CheckObjectRef(comp, "rootTransform",
                            out bool pbcIsNull);
                        if (pbcIsNull)
                        {
                            warnings.Add(
                                $"⚠️ PhysBoneCollider '{comp.gameObject.name}': " +
                                "rootTransform が null (参照切れの可能性)");
                        }
                        break;

                    case TypeVRCContactReceiver:
                        recvCount++;
                        if (IsArrayEmpty(comp, "collisionTags"))
                        {
                            issues.Add(
                                $"ℹ️ ContactReceiver '{comp.gameObject.name}': " +
                                "collisionTags が空");
                        }
                        break;

                    case TypeVRCContactSender:
                        sendCount++;
                        if (IsArrayEmpty(comp, "collisionTags"))
                        {
                            issues.Add(
                                $"ℹ️ ContactSender '{comp.gameObject.name}': " +
                                "collisionTags が空");
                        }
                        break;
                }
            }

            
            string summary =
                $"{LogTag} PhysBone / Contact 参照チェック完了\n" +
                $"  PhysBone: {pbCount}件, Collider: {pbColl}件, " +
                $"Receiver: {recvCount}件, Sender: {sendCount}件\n" +
                $"  Info: {issues.Count}件, Warning: {warnings.Count}件";

            Debug.Log(summary);

            foreach (var w in warnings) Debug.LogWarning(w);
            foreach (var i in issues)   Debug.Log(i);

            
            if (warnings.Count == 0 && issues.Count == 0)
            {
                ShowNotification(
                    $"✅ 参照チェック完了: 問題なし " +
                    $"(PhysBone:{pbCount}/Collider:{pbColl}/Recv:{recvCount}/Send:{sendCount})");
            }
            else
            {
                ShowNotification(
                    $"参照チェック完了: Warning {warnings.Count}件 / Info {issues.Count}件 " +
                    "(Console を確認)");
            }
        }

        #endregion

        #region Reflection ヘルパー

        
        
        
        
        private static void CheckObjectRef(Component comp, string propName, out bool isNull)
        {
            isNull = false;
            if (comp == null) return;
            try
            {
                using (var so = new SerializedObject(comp))
                {
                    var prop = so.FindProperty(propName);
                    if (prop == null) return; 
                    if (prop.propertyType != SerializedPropertyType.ObjectReference) return;
                    isNull = prop.objectReferenceValue == null;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"{LogTag} CheckObjectRef 失敗 ({comp.GetType().Name}.{propName}): {ex.Message}");
            }
        }

        
        private static bool IsArrayEmpty(Component comp, string propName)
        {
            if (comp == null) return false;
            try
            {
                using (var so = new SerializedObject(comp))
                {
                    var prop = so.FindProperty(propName);
                    if (prop == null || !prop.isArray) return false;
                    return prop.arraySize == 0;
                }
            }
            catch
            {
                return false;
            }
        }

        
        private static void ShowNotification(string message)
        {
            var window = EditorWindow.focusedWindow;
            if (window != null)
                window.ShowNotification(new GUIContent(message));
        }

        #endregion
    }
}
