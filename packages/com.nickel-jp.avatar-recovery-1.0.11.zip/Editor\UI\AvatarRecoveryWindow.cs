







using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public sealed class AvatarRecoveryWindow : EditorWindow
    {
        #region 定数

        private const string WindowTitle     = "AvatarRecovery";
        private const string SupportedFileExtensions = "vrca,vrcw,vrcp";

        
        
        private const string MenuItemPath    = "AvatarRecovery/ウィンドウを開く";

        
        private const string LegacyMenuItemPath = "Tools/AvatarRecovery";
        private const float  SidebarWidth    = 0f;   
        private const float  MinWindowWidth  = 620f; 
        private const float  MinWindowHeight = 400f;

        private static readonly string[] ScaleModeOptions = { "StretchToFill", "ScaleAndCrop", "ScaleToFit" };

        
        private readonly MissingScriptSearchPanel _missingScriptPanel = new MissingScriptSearchPanel();

        
        private readonly VrcaBackupPanel _backupPanel = new VrcaBackupPanel();

        
        private readonly AvatarDiagnosticsPanel _diagnosticsPanel = new AvatarDiagnosticsPanel();

        #endregion

        #region ウィンドウ エントリーポイント

        [MenuItem(MenuItemPath, priority = 0)]
        [MenuItem(LegacyMenuItemPath, priority = 0)] 
        private static void Open()
        {
            var window = GetWindow<AvatarRecoveryWindow>(WindowTitle);
            window.minSize = new Vector2(MinWindowWidth, MinWindowHeight);
            window.Show();
        }

        #endregion

        #region 状態

        
        private int _tab;

        
        private string                  _manualFilePath  = string.Empty;
        private List<VrcaFileInfo>      _manualFileInfos = new List<VrcaFileInfo>();
        private Vector2                 _manualListScrollPos;
        private bool                    _manualAvatarFoldout;
        private bool                    _manualWorldFoldout;
        private bool                    _manualPropFoldout;

        
        private string _avatarOutputPath;
        private string _worldOutputPath;
        private string _propOutputPath;
        private string _packageOutputPath;
        private bool   _placeInScene;
        private bool   _exportPackage;
        private bool   _remapShaders;
        private bool   _useAssetRipper;     
        private string _assetRipperExePath = string.Empty; 
        private MissingScriptDeletePolicy _missingScriptPolicy = MissingScriptDeletePolicy.Always; 
        private bool   _autoReassignShaders; 
        private bool   _autoDiagnosticsAfterExtract; 

        
        private string     _backgroundImagePath = string.Empty;
        private float      _backgroundOpacity   = 0.3f;
        private int        _backgroundScaleMode = 0;         
        private Texture2D  _backgroundTexture;               
        private string     _loadedTexturePath;               

        
        private string _statusMessage = string.Empty;
        private bool   _statusIsError;

        
        private Vector2 _settingsScrollPos;
        private Vector2 _licenseScrollPos;

        #endregion

        #region Unity コールバック

        private void OnEnable()
        {
            LoadAllPrefs();

            
            _tab = EditorPrefsHelper.LoadWindowTab();

            
            if (_tab < 0 || _tab >= 6) _tab = 0;

            _backupPanel.OnEnable();
            AvatarRecoveryEnvChecker.Run(); 
        }

        private void OnDisable()
        {
            EditorPrefsHelper.SaveWindowTab(_tab);
            ReleaseBackgroundTexture(); 

            
            
            EditorUtility.ClearProgressBar();
        }

        private void OnGUI()
        {
            Styles.EnsureInitialized();

            
            DrawBackgroundImage();

            DrawHeader();
            DrawEncryptionWarning();

            EditorGUI.BeginChangeCheck();
            _tab = GUILayout.Toolbar(_tab, Loc.S.TabLabels);
            if (EditorGUI.EndChangeCheck())
                EditorPrefsHelper.SaveWindowTab(_tab);

            GUILayout.Space(4);

            switch (_tab)
            {
                case 0: DrawFileTab();    break;
                case 1: _missingScriptPanel.Draw(this); break;
                case 2: _backupPanel.Draw(this); break;
                case 3: DrawSettingsTab(); break;
                case 4: _diagnosticsPanel.Draw(this); break;
                case 5: DrawLicenseTab(); break;
            }

            DrawStatusBar();
        }

        #endregion

        #region ヘッダー

        private void DrawHeader()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label(Loc.S.HeaderSubtitle, EditorStyles.boldLabel);
            GUILayout.FlexibleSpace();

            
            EditorGUI.BeginChangeCheck();
            int langIndex = EditorGUILayout.Popup(
                (int)Loc.Current, Loc.LanguageNames,
                EditorStyles.toolbarDropDown, GUILayout.Width(85));
            if (EditorGUI.EndChangeCheck())
            {
                Loc.SetLanguage((AppLanguage)langIndex);
                Repaint();
            }

            GUILayout.Space(4);

            if (GUILayout.Button(Loc.S.ResetSettings, EditorStyles.toolbarButton, GUILayout.Width(100)))
            {
                if (EditorUtility.DisplayDialog(
                    Loc.S.ResetConfirmTitle, Loc.S.ResetConfirmMsg,
                    Loc.S.ResetBtn, Loc.S.Cancel))
                {
                    EditorPrefsHelper.ResetAll();             
                    Loc.SetLanguage(AppLanguage.English);     
                    LoadAllPrefs();
                    ReleaseBackgroundTexture(); 
                    Repaint();
                }
            }
            EditorGUILayout.EndHorizontal();
        }

        private void DrawEncryptionWarning()
        {
            EditorGUILayout.HelpBox(Loc.S.EncryptionWarning, MessageType.Warning);
        }

        #endregion

        #region タブ0: ファイル指定

        private void DrawFileTab()
        {
            GUILayout.Label(Loc.S.FileSectionHeader, Styles.SectionHeader);

            
            EditorGUILayout.BeginHorizontal();

            if (GUILayout.Button(
                    new GUIContent(Loc.S.BrowseFileBtn, Loc.S.BrowseFileBtnTooltip),
                    GUILayout.Height(22)))
            {
                BrowseAndAddSingleFile();
            }

            if (GUILayout.Button(
                    new GUIContent(Loc.S.AddFromFolderBtn, Loc.S.AddFromFolderBtnTooltip),
                    GUILayout.Height(22)))
            {
                BrowseAndAddFolder();
            }

            EditorGUI.BeginDisabledGroup(_manualFileInfos.Count == 0);
            if (GUILayout.Button(Loc.S.ClearListBtn, GUILayout.Width(120), GUILayout.Height(22)))
            {
                _manualFileInfos.Clear();
                _statusMessage = string.Empty;
                Repaint();
            }
            EditorGUI.EndDisabledGroup();

            EditorGUILayout.EndHorizontal();

            DrawManualFileList();

            GUILayout.FlexibleSpace();

            
            DrawBatchExtractButton(_manualFileInfos);
        }

        
        
        
        
        
        private void BrowseAndAddSingleFile()
        {
            var path = EditorUtility.OpenFilePanel(
                Loc.S.DialogSelectFile,
                GetSafeDirectoryName(_manualFilePath),
                SupportedFileExtensions);

            if (string.IsNullOrEmpty(path)) return; 

            if (AddManualFile(path))
                SetStatus(string.Format(Loc.S.FileAddedFmt, Path.GetFileName(path)), isError: false);
            else
                SetStatus(Loc.S.AlreadyInList, isError: false);
        }

        
        
        
        private void BrowseAndAddFolder()
        {
            var dir = EditorUtility.OpenFolderPanel(
                Loc.S.DialogSelectFolderForFiles,
                GetSafeDirectoryName(_manualFilePath),
                string.Empty);

            if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return; 

            int added = AddFilesFromDirectory(dir);
            if (added == 0)
                SetStatus(Loc.S.NoFilesInFolder, isError: true);
            else
                SetStatus(string.Format(Loc.S.FilesAddedFmt, added), isError: false);
        }

        
        private int AddFilesFromDirectory(string dir)
        {
            int added = 0;
            try
            {
                
                var files = Directory.GetFiles(dir, "*.*", SearchOption.TopDirectoryOnly);
                foreach (var file in files)
                {
                    if (IsSupportedRecoveryFile(file))
                    {
                        if (AddManualFile(file)) added++;
                    }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] フォルダー読み取り失敗: {ex.Message}");
            }
            return added;
        }

        private void DrawManualFileList()
        {
            if (_manualFileInfos.Count == 0)
            {
                EditorGUILayout.HelpBox(Loc.S.NoFilesHelpBox, MessageType.Info);
                return;
            }

            EditorGUILayout.LabelField(
                string.Format(Loc.S.SelectedCountFmt, _manualFileInfos.Count),
                EditorStyles.boldLabel);

            var listHeight = Mathf.Max(80, position.height - 360);
            _manualListScrollPos = EditorGUILayout.BeginScrollView(
                _manualListScrollPos, GUILayout.Height(listHeight));

            if (DrawManualFileGroup(VrcaFileType.Avatar, Loc.S.TypeAvatar, ref _manualAvatarFoldout) ||
                DrawManualFileGroup(VrcaFileType.World, Loc.S.TypeWorld, ref _manualWorldFoldout) ||
                DrawManualFileGroup(VrcaFileType.Prop, Loc.S.TypeProp, ref _manualPropFoldout))
            {
                EditorGUILayout.EndScrollView();
                return;
            }

            EditorGUILayout.EndScrollView();
        }

        private bool DrawManualFileGroup(
            VrcaFileType fileType,
            string label,
            ref bool foldout)
        {
            var count = CountManualFilesOfType(fileType);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            foldout = EditorGUILayout.Foldout(
                foldout,
                label,
                true);
            GUILayout.FlexibleSpace();
            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.IntField(count, GUILayout.Width(48));
            }
            EditorGUILayout.EndHorizontal();

            if (foldout)
            {
                for (int i = 0; i < _manualFileInfos.Count; i++)
                {
                    var info = _manualFileInfos[i];
                    if (info == null || info.FileType != fileType)
                        continue;

                    if (DrawManualFileRow(info, i))
                    {
                        EditorGUILayout.EndVertical();
                        return true;
                    }
                }
            }

            EditorGUILayout.EndVertical();
            return false;
        }

        private bool DrawManualFileRow(VrcaFileInfo info, int index)
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);

            GUILayout.Label($"#{index + 1}", GUILayout.Width(28));

            EditorGUILayout.BeginVertical();
            var displayName = !string.IsNullOrEmpty(info.BlueprintId)
                ? info.BlueprintId
                : info.FileName;
            var hasError = info.IsParsed && !string.IsNullOrEmpty(info.ParseError);
            var labelStyle = hasError ? Styles.ErrorLabel : EditorStyles.label;
            GUILayout.Label((hasError ? "⚠ " : "") + displayName, labelStyle);
            GUILayout.Label(
                $"{GetFileTypeListLabel(info)}  •  " +
                $"{FormatFileSize(info.FileSize)}  •  {info.FilePath}",
                EditorStyles.miniLabel);
            EditorGUILayout.EndVertical();

            using (new EditorGUI.DisabledScope(hasError))
            {
                var previewContent = new GUIContent(
                    Loc.S.PreviewBtn,
                    GetEyeIcon(),
                    Loc.S.PreviewBtnTooltip);
                if (GUILayout.Button(previewContent,
                        GUILayout.Width(90), GUILayout.Height(28)))
                {
                    VrcaPreviewWindow.Open(info);
                }
            }

            if (GUILayout.Button("✕", GUILayout.Width(28), GUILayout.Height(28)))
            {
                _manualFileInfos.RemoveAt(index);
                GUI.changed = true;
                Repaint();
                EditorGUILayout.EndHorizontal();
                return true;
            }

            EditorGUILayout.EndHorizontal();
            return false;
        }

        
        private bool AddManualFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path)) return false;

            
            foreach (var existing in _manualFileInfos)
            {
                if (string.Equals(existing.FilePath, path,
                        System.StringComparison.OrdinalIgnoreCase))
                    return false;
            }

            var info = VrcaFileInfo.FromPath(path);
            VrcaLoader.ParseHeader(info);
            _manualFileInfos.Add(info);

            _manualFilePath = path; 
            EditorPrefsHelper.SaveLastFilePath(path);
            Repaint();
            return true;
        }

        #endregion

        #region タブ3: 設定

        private void DrawSettingsTab()
        {
            _settingsScrollPos = EditorGUILayout.BeginScrollView(_settingsScrollPos);

            
            
            
            var prevLabelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = Loc.S.SettingsLabelWidth;

            try
            {

            
            GUILayout.Label(Loc.S.OutputFolderHeader, Styles.SectionHeader);

            EditorGUILayout.BeginHorizontal();
            _avatarOutputPath = EditorGUILayout.TextField(Loc.S.LblAvatarOutput, _avatarOutputPath);
            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(70)))
            {
                var p = EditorUtility.OpenFolderPanel(Loc.S.DialogSelectAvatarOutput,
                    _avatarOutputPath, string.Empty);
                if (!string.IsNullOrEmpty(p)) _avatarOutputPath = NormalizePickedPath(p);
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            _worldOutputPath = EditorGUILayout.TextField(Loc.S.LblWorldOutput, _worldOutputPath);
            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(70)))
            {
                var p = EditorUtility.OpenFolderPanel(Loc.S.DialogSelectWorldOutput,
                    _worldOutputPath, string.Empty);
                if (!string.IsNullOrEmpty(p)) _worldOutputPath = NormalizePickedPath(p);
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            _propOutputPath = EditorGUILayout.TextField(Loc.S.LblPropOutput, _propOutputPath);
            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(70)))
            {
                var p = EditorUtility.OpenFolderPanel(Loc.S.DialogSelectPropOutput,
                    _propOutputPath, string.Empty);
                if (!string.IsNullOrEmpty(p)) _propOutputPath = NormalizePickedPath(p);
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            _packageOutputPath = EditorGUILayout.TextField(Loc.S.LblPackageOutput, _packageOutputPath);
            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(70)))
            {
                var p = EditorUtility.OpenFolderPanel(Loc.S.DialogSelectPackageOutput,
                    _packageOutputPath, string.Empty);
                if (!string.IsNullOrEmpty(p)) _packageOutputPath = p;
            }
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(8);

            
            GUILayout.Label(Loc.S.OptionsHeader, Styles.SectionHeader);

            _placeInScene   = EditorGUILayout.Toggle(
                new GUIContent(Loc.S.PlaceInSceneLabel, Loc.S.PlaceInSceneTooltip),
                _placeInScene);

            _autoReassignShaders = EditorGUILayout.Toggle(
                new GUIContent(Loc.S.AutoReassignShadersLabel, Loc.S.AutoReassignShadersTooltip),
                _autoReassignShaders);

            _autoDiagnosticsAfterExtract = EditorGUILayout.Toggle(
                new GUIContent(Loc.S.AutoDiagnosticsAfterExtractLabel, Loc.S.AutoDiagnosticsAfterExtractTooltip),
                _autoDiagnosticsAfterExtract);

            _remapShaders   = EditorGUILayout.Toggle(
                new GUIContent(Loc.S.RemapShadersLabel, Loc.S.RemapShadersTooltip),
                _remapShaders);

            _exportPackage  = EditorGUILayout.Toggle(
                new GUIContent(Loc.S.ExportPackageLabel, Loc.S.ExportPackageTooltip),
                _exportPackage);

            EditorGUI.BeginChangeCheck();
            int policyIndex = EditorGUILayout.Popup(
                new GUIContent(Loc.S.MissingScriptPolicyLabel, Loc.S.MissingScriptPolicyTooltip),
                (int)_missingScriptPolicy,
                Loc.S.MissingScriptPolicyOptions);
            if (EditorGUI.EndChangeCheck())
                _missingScriptPolicy = (MissingScriptDeletePolicy)policyIndex;

            GUILayout.Space(6);
            GUILayout.Label(Loc.S.AssetRipperHeader, Styles.SectionHeader);

            
            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();
            _assetRipperExePath = EditorGUILayout.TextField(
                new GUIContent(Loc.S.AssetRipperExeLabel, Loc.S.AssetRipperExeTooltip),
                _assetRipperExePath);
            if (EditorGUI.EndChangeCheck())
                EditorPrefsHelper.SaveAssetRipperExePath(_assetRipperExePath);

            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(60)))
            {
                var initial = string.IsNullOrEmpty(_assetRipperExePath)
                    ? string.Empty
                    : Path.GetDirectoryName(
                        Environment.ExpandEnvironmentVariables(_assetRipperExePath)) ?? string.Empty;
                var picked = EditorUtility.OpenFilePanel(
                    Loc.S.DialogSelectAssetRipper, initial, "exe");
                if (!string.IsNullOrEmpty(picked))
                {
                    _assetRipperExePath = picked.Replace('/', '\\');
                    EditorPrefsHelper.SaveAssetRipperExePath(_assetRipperExePath);
                    GUI.FocusControl(null);
                }
            }
            EditorGUILayout.EndHorizontal();

            
            var detectedPath = AssetRipperBridge.FindAssetRipperExe();
            if (detectedPath != null)
            {
                EditorGUILayout.LabelField(
                    new GUIContent(string.Format(Loc.S.AssetRipperDetectedFmt, detectedPath)),
                    Styles.SuccessLabel);
            }
            else
            {
                EditorGUILayout.HelpBox(Loc.S.AssetRipperNotFoundMsg, MessageType.Warning);
            }

            
            using (new EditorGUI.DisabledScope(!AssetRipperBridge.IsAvailable()))
            {
                var arLabel = AssetRipperBridge.IsAvailable()
                    ? Loc.S.UseAssetRipperLabel
                    : Loc.S.UseAssetRipperDisabledLabel;
                _useAssetRipper = EditorGUILayout.Toggle(
                    new GUIContent(arLabel, Loc.S.UseAssetRipperTooltip),
                    _useAssetRipper);
            }
            GUILayout.Space(6);

            GUILayout.Space(8);

            
            GUILayout.Label(Loc.S.AvailableShadersHeader, Styles.SectionHeader);
            var shaders = ShaderRemapper.GetAvailableShaders();
            if (shaders.Count == 0)
            {
                EditorGUILayout.HelpBox(Loc.S.NoShadersWarning, MessageType.Warning);
            }
            else
            {
                foreach (var s in shaders)
                    EditorGUILayout.LabelField("✔ " + s, EditorStyles.miniLabel);
            }

            GUILayout.Space(12);

            
            DrawBackgroundImageSettings();

            GUILayout.Space(12);

            
            if (GUILayout.Button(Loc.S.SaveSettingsBtn, GUILayout.Height(28)))
                SaveAllPrefs();

            } 
            finally
            {
                
                EditorGUIUtility.labelWidth = prevLabelWidth;
                EditorGUILayout.EndScrollView();
            }
        }

        #endregion

        #region 共通 UI パーツ

        
        private void DrawFileInfoPanel(VrcaFileInfo info)
        {
            GUILayout.Label(Loc.S.FileInfoHeader, Styles.SectionHeader);

            EditorGUI.indentLevel++;

            EditorGUILayout.LabelField(Loc.S.LblFile,
                string.IsNullOrEmpty(info.BlueprintId)
                    ? info.FileName
                    : $"{info.BlueprintId}  ({info.FileName})");

            EditorGUILayout.LabelField(Loc.S.LblSize,         FormatFileSize(info.FileSize));
            EditorGUILayout.LabelField(Loc.S.LblLastModified, info.LastModified.ToString("yyyy/MM/dd HH:mm:ss"));
            EditorGUILayout.LabelField(Loc.S.LblType,
                info.FileType == VrcaFileType.Avatar ? Loc.S.TypeAvatar :
                info.FileType == VrcaFileType.World  ? Loc.S.TypeWorld   :
                info.FileType == VrcaFileType.Prop   ? Loc.S.TypeProp    : Loc.S.Unknown);
            EditorGUILayout.LabelField(Loc.S.LblPlatform,
                info.Platform == VrcaPlatform.PC    ? Loc.S.PlatformPC    :
                info.Platform == VrcaPlatform.Quest ? Loc.S.PlatformQuest : Loc.S.Unknown);

            if (info.IsParsed)
            {
                EditorGUILayout.LabelField(Loc.S.LblUnityVersion,
                    string.IsNullOrEmpty(info.UnityVersionString)
                        ? Loc.S.Unknown
                        : info.UnityVersionString);

                if (!string.IsNullOrEmpty(info.ParseError))
                {
                    EditorGUILayout.HelpBox(info.ParseError, MessageType.Error);
                }
            }
            else if (!string.IsNullOrEmpty(info.ParseError))
            {
                EditorGUILayout.HelpBox(info.ParseError, MessageType.Error);
            }

            EditorGUI.indentLevel--;

            
            
            var hasErr = info.IsParsed && !string.IsNullOrEmpty(info.ParseError);
            using (new EditorGUI.DisabledScope(hasErr))
            {
                var content = new GUIContent(
                    Loc.S.PreviewFileBtn,
                    GetEyeIcon(),
                    Loc.S.PreviewFileBtnTooltip);
                if (GUILayout.Button(content, GUILayout.Height(26)))
                {
                    VrcaPreviewWindow.Open(info);
                }
            }
        }

        
        
        
        
        
        private static Texture2D GetEyeIcon()
        {
            
            
            string[] iconNames =
            {
                "d_scenevis_visible_hover",   
                "scenevis_visible_hover",     
                "d_ViewToolOrbit",             
                "ViewToolOrbit",
                "d_animationvisibilitytoggleon",
                "animationvisibilitytoggleon",
                "d_VisibilityOn",
                "VisibilityOn",
            };
            foreach (var name in iconNames)
            {
                var content = EditorGUIUtility.IconContent(name);
                if (content != null && content.image is Texture2D tex)
                    return tex;
            }
            return null;
        }

        
        private void DrawBatchExtractButton(List<VrcaFileInfo> infos)
        {
            
            int validCount = 0;
            if (infos != null)
            {
                foreach (var i in infos)
                {
                    if (i == null) continue;
                    var hasErr = i.IsParsed && !string.IsNullOrEmpty(i.ParseError);
                    if (!hasErr) validCount++;
                }
            }

            EditorGUI.BeginDisabledGroup(validCount == 0);

            GUILayout.Space(4);
            var label = validCount <= 1
                ? Loc.S.ExtractSingle
                : string.Format(Loc.S.ExtractBatchFmt, validCount);
            if (GUILayout.Button(label, Styles.PrimaryButton))
                RunBatchExtraction(infos);

            EditorGUI.EndDisabledGroup();

            if (infos == null || infos.Count == 0)
                EditorGUILayout.HelpBox(Loc.S.NeedFilesHelp, MessageType.Info);
            else if (validCount == 0)
                EditorGUILayout.HelpBox(Loc.S.AllSkippedError, MessageType.Error);
            else if (validCount < infos.Count)
                EditorGUILayout.HelpBox(
                    string.Format(Loc.S.SomeSkippedFmt, infos.Count - validCount),
                    MessageType.Warning);
        }

        
        private void DrawStatusBar()
        {
            if (string.IsNullOrEmpty(_statusMessage)) return;

            GUILayout.FlexibleSpace();
            var style = _statusIsError ? Styles.ErrorLabel : Styles.SuccessLabel;
            EditorGUILayout.LabelField(_statusMessage, style);
        }

        #endregion

        #region 展開処理

        
        
        
        
        
        private void RunBatchExtraction(List<VrcaFileInfo> infos)
        {
            
            var _sw_ = System.Diagnostics.Stopwatch.StartNew();
            try
            {
            
            if (infos == null || infos.Count == 0) return;

            SaveAllPrefs();

            int total      = infos.Count;
            int successCnt = 0;
            int failCnt    = 0;
            int skipCnt    = 0;
            var perFileLog = new System.Text.StringBuilder();

            
            int totalScriptFiles  = 0;
            int totalScriptRefs   = 0;
            int totalShaderFiles  = 0;
            int totalShaderRefs   = 0;
            int totalMissingRemoved = 0;
            int totalPoseReset      = 0;
            int totalDetectedShaders = 0; 
            int totalShaderListOutputs = 0; 
            int totalDiagnosticTargets = 0; 
            int totalDiagnosticCritical = 0;
            int totalDiagnosticWarning = 0;
            int totalDiagnosticInfo = 0;

            
            var successPrefabPaths = new List<string>();

            
            var successInfos = new List<VrcaFileInfo>();

            try
            {
                for (int i = 0; i < total; i++)
                {
                    var info = infos[i];
                    if (info == null) continue;

                    
                    if (info.IsParsed && !string.IsNullOrEmpty(info.ParseError))
                    {
                        skipCnt++;
                        perFileLog.AppendLine($"⊘ [{i + 1}/{total}] {info.DisplayName} — スキップ ({info.ParseError})");
                        continue;
                    }

                    
                    var progress = (float)i / total;
                    bool cancel = EditorUtility.DisplayCancelableProgressBar(
                        Loc.S.BatchProgressTitle,
                        $"[{i + 1}/{total}] {info.DisplayName}",
                        progress);
                    if (cancel)
                    {
                        perFileLog.AppendLine(Loc.S.BatchCancelledByUser);
                        break;
                    }

                    
                    var outputFolder = GetOutputFolderForFile(info);

                    try
                    {
                        var result = VrcaExtractor.Extract(
                            info,
                            outputFolder:        outputFolder,
                            placeInScene:        _placeInScene,
                            exportPackage:       _exportPackage,
                            packageOutputDir:    _packageOutputPath,
                            remapShaders:        _remapShaders,
                            useAssetRipper:      _useAssetRipper,
                            missingScriptPolicy: _missingScriptPolicy,
                            autoReassignShaders: _autoReassignShaders);

                        
                        if (result.Cancelled)
                        {
                            perFileLog.AppendLine(
                                $"⊘ [{i + 1}/{total}] {info.DisplayName} — " +
                                Loc.S.BatchCancelledByUser.TrimStart('⊘', ' '));
                            break; 
                        }

                        if (result.Success)
                        {
                            successCnt++;
                            successInfos.Add(info); 
                            perFileLog.AppendLine($"✓ [{i + 1}/{total}] {info.DisplayName}");
                            if (!string.IsNullOrEmpty(result.PrefabAssetPath))
                            {
                                perFileLog.AppendLine($"    → {result.PrefabAssetPath}");
                                successPrefabPaths.Add(result.PrefabAssetPath);

                                if (_autoDiagnosticsAfterExtract)
                                {
                                    var diagnosticReport =
                                        AvatarRecoveryDiagnostics.DiagnosePrefabAsset(
                                            result.PrefabAssetPath,
                                            GetDiagnosticOptionsForFile(info));
                                    totalDiagnosticTargets++;
                                    totalDiagnosticCritical += diagnosticReport.CriticalCount;
                                    totalDiagnosticWarning += diagnosticReport.WarningCount;
                                    totalDiagnosticInfo += diagnosticReport.InfoCount;

                                    Debug.Log(diagnosticReport.ToDisplayText());
                                    if (diagnosticReport.CriticalCount > 0 ||
                                        diagnosticReport.WarningCount > 0)
                                    {
                                        perFileLog.AppendLine(
                                            $"    診断: Critical {diagnosticReport.CriticalCount} / " +
                                            $"Warning {diagnosticReport.WarningCount} / Info {diagnosticReport.InfoCount}");
                                    }
                                }
                            }

                            
                            if (result.SarsBridgeResult != null)
                            {
                                var br = result.SarsBridgeResult;
                                if (br.ScriptFixResult != null)
                                {
                                    totalScriptFiles += br.ScriptFixResult.FixedFileCount;
                                    totalScriptRefs  += br.ScriptFixResult.FixedReferenceCount;
                                }
                                if (br.ShaderFixResult != null)
                                {
                                    totalShaderFiles += br.ShaderFixResult.FixedFileCount;
                                    totalShaderRefs  += br.ShaderFixResult.FixedReferenceCount;
                                }
                                totalMissingRemoved += br.RemovedMissingScripts;
                                totalPoseReset      += br.PoseResetCount;
                                totalDetectedShaders += br.DetectedShaderCount;
                                if (!string.IsNullOrEmpty(br.ShaderListOutputPath))
                                    totalShaderListOutputs++;
                            }
                        }
                        else
                        {
                            failCnt++;
                            perFileLog.AppendLine($"✗ [{i + 1}/{total}] {info.DisplayName} — {result.ErrorMessage}");
                        }
                    }
                    catch (System.Exception ex)
                    {
                        failCnt++;
                        perFileLog.AppendLine($"✗ [{i + 1}/{total}] {info.DisplayName} — 例外: {ex.Message}");
                        Debug.LogError($"[AvatarRecovery] バッチ展開例外 ({info.FileName}): {ex}");
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            
            
            
            
            int autoCleanRemovedCount = 0;
            if (_missingScriptPolicy == MissingScriptDeletePolicy.Ask)
                autoCleanRemovedCount = PromptAndRunAutoMissingScriptCleanup(successPrefabPaths);

            
            int removedManual = AutoRemoveSuccessfulEntries(successInfos);

            
            var summary = new System.Text.StringBuilder();
            summary.AppendLine(string.Format(Loc.S.BatchSummaryFmt,
                successCnt, failCnt, skipCnt, total));

            if (autoCleanRemovedCount > 0)
                summary.AppendLine(string.Format(Loc.S.BatchMissingRemovedFmt, autoCleanRemovedCount));

            if (removedManual > 0)
                summary.AppendLine(string.Format(Loc.S.BatchAutoRemovedFmt, removedManual));

            if (totalScriptRefs > 0 || totalShaderRefs > 0 ||
                totalMissingRemoved > 0 || totalPoseReset > 0 ||
                totalDiagnosticTargets > 0)
            {
                summary.AppendLine(Loc.S.SarsSummaryHeader);
                if (totalScriptRefs > 0)
                    summary.AppendLine(string.Format(Loc.S.FixScriptsFmt, totalScriptFiles, totalScriptRefs));
                if (totalShaderRefs > 0)
                    summary.AppendLine(string.Format(Loc.S.FixShadersFmt, totalShaderFiles, totalShaderRefs));
                if (totalMissingRemoved > 0)
                    summary.AppendLine(string.Format(Loc.S.MissingRemovedFmt, totalMissingRemoved));
                if (totalPoseReset > 0)
                    summary.AppendLine(string.Format(Loc.S.PoseResetFmt, totalPoseReset));
                if (totalDetectedShaders > 0)
                    summary.AppendLine(string.Format(Loc.S.ShaderDetectedFmt,
                        totalDetectedShaders, totalShaderListOutputs,
                        _autoReassignShaders ? Loc.S.AutoReassignOn : Loc.S.AutoReassignOff));
                if (totalDiagnosticTargets > 0)
                    summary.AppendLine(string.Format(Loc.S.BatchDiagnosticsFmt,
                        totalDiagnosticCritical, totalDiagnosticWarning, totalDiagnosticInfo));
            }

            
            var lines = perFileLog.ToString().TrimEnd().Split('\n');
            if (lines.Length > 0 && !string.IsNullOrEmpty(lines[0]))
            {
                summary.AppendLine();
                int displayLines = Mathf.Min(10, lines.Length);
                for (int i = 0; i < displayLines; i++)
                    summary.AppendLine(lines[i].TrimEnd('\r'));
                if (lines.Length > displayLines)
                    summary.AppendLine(string.Format(Loc.S.BatchOtherLinesFmt, lines.Length - displayLines));
            }

            
            Debug.Log($"[AvatarRecovery] 一括展開結果\n" +
                      $"成功: {successCnt}, 失敗: {failCnt}, スキップ: {skipCnt}\n" +
                      perFileLog.ToString());

            SetStatus(summary.ToString().TrimEnd(),
                isError: failCnt > 0 && successCnt == 0);

            Repaint();
            
            }
            finally
            {
                
                _sw_.Stop();
                UnityEngine.Debug.Log(
                    $"[SARS][計測] RunBatchExtraction: {_sw_.ElapsedMilliseconds}ms " +
                    $"({infos?.Count ?? 0} 件)");
            }
        }

        
        
        
        
        
        
        private int AutoRemoveSuccessfulEntries(List<VrcaFileInfo> successInfos)
        {
            if (successInfos == null || successInfos.Count == 0) return 0;

            var successPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var i in successInfos)
            {
                if (i != null && !string.IsNullOrEmpty(i.FilePath))
                    successPaths.Add(i.FilePath);
            }
            if (successPaths.Count == 0) return 0;

            int removed = _manualFileInfos.RemoveAll(
                x => x != null && !string.IsNullOrEmpty(x.FilePath) &&
                     successPaths.Contains(x.FilePath));

            if (removed > 0)
            {
                Debug.Log($"[AvatarRecovery] 成功ファイル自動削除: {removed} 件");
                Repaint();
            }
            return removed;
        }

        
        
        
        
        
        
        
        
        private int PromptAndRunAutoMissingScriptCleanup(List<string> prefabPaths)
        {
            if (prefabPaths == null || prefabPaths.Count == 0) return 0;

            
            bool ok = EditorUtility.DisplayDialog(
                Loc.S.MissingCleanupTitle,
                string.Format(Loc.S.MissingCleanupMsgFmt, prefabPaths.Count),
                Loc.S.MissingCleanupOk, Loc.S.MissingCleanupSkip);

            if (!ok)
            {
                Debug.Log("[AvatarRecovery] 展開後の Missing Script 削除をユーザーがスキップしました。");
                return 0;
            }

            
            int totalRemoved = 0;
            int processed = 0;
            try
            {
                for (int i = 0; i < prefabPaths.Count; i++)
                {
                    var path = prefabPaths[i];
                    if (string.IsNullOrEmpty(path)) continue;

                    EditorUtility.DisplayProgressBar(
                        "AvatarRecovery — Missing Script 自動削除",
                        $"[{i + 1}/{prefabPaths.Count}] {Path.GetFileName(path)}",
                        (float)i / prefabPaths.Count);

                    try
                    {
                        var cleanResult = MissingScriptCleaner.CleanPrefabAsset(path);
                        totalRemoved += cleanResult.RemovedScripts;
                        processed++;
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] Missing Script 削除失敗 '{path}': {ex.Message}");
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            Debug.Log(
                $"[AvatarRecovery] 展開後 Missing Script 自動削除完了: " +
                $"{processed} Prefab を処理、合計 {totalRemoved} 個削除");

            return totalRemoved;
        }

        #endregion

        #region EditorPrefs 読み書き

        private void LoadAllPrefs()
        {
            _avatarOutputPath  = EditorPrefsHelper.LoadAvatarOutput();
            _worldOutputPath   = EditorPrefsHelper.LoadWorldOutput();
            _propOutputPath    = EditorPrefsHelper.LoadPropOutput();
            _packageOutputPath = EditorPrefsHelper.LoadPackageOutput();
            _placeInScene      = EditorPrefsHelper.LoadPlaceInScene();
            _exportPackage     = EditorPrefsHelper.LoadExportPackage();
            _remapShaders      = EditorPrefsHelper.LoadRemapShaders();
            _useAssetRipper    = EditorPrefsHelper.LoadUseAssetRipper();
            _assetRipperExePath = EditorPrefsHelper.LoadAssetRipperExePath();
            _missingScriptPolicy = EditorPrefsHelper.LoadMissingScriptPolicy();
            _autoReassignShaders = EditorPrefsHelper.LoadAutoReassignShaders();
            _autoDiagnosticsAfterExtract = EditorPrefsHelper.LoadAutoDiagnosticsAfterExtract();

            
            _backgroundImagePath = EditorPrefsHelper.LoadBackgroundImagePath();
            _backgroundOpacity   = EditorPrefsHelper.LoadBackgroundOpacity();
            _backgroundScaleMode = EditorPrefsHelper.LoadBackgroundScaleMode();

            
            var lastPath = EditorPrefsHelper.LoadLastFilePath();
            if (!string.IsNullOrEmpty(lastPath) && File.Exists(lastPath))
            {
                _manualFilePath = lastPath;
            }
        }

        private void SaveAllPrefs()
        {
            EditorPrefsHelper.SaveAvatarOutput(_avatarOutputPath);
            EditorPrefsHelper.SaveWorldOutput(_worldOutputPath);
            EditorPrefsHelper.SavePropOutput(_propOutputPath);
            EditorPrefsHelper.SavePackageOutput(_packageOutputPath);
            EditorPrefsHelper.SavePlaceInScene(_placeInScene);
            EditorPrefsHelper.SaveExportPackage(_exportPackage);
            EditorPrefsHelper.SaveRemapShaders(_remapShaders);
            EditorPrefsHelper.SaveUseAssetRipper(_useAssetRipper);
            EditorPrefsHelper.SaveAssetRipperExePath(_assetRipperExePath);
            EditorPrefsHelper.SaveMissingScriptPolicy(_missingScriptPolicy);
            EditorPrefsHelper.SaveAutoReassignShaders(_autoReassignShaders);
            EditorPrefsHelper.SaveAutoDiagnosticsAfterExtract(_autoDiagnosticsAfterExtract);

            
            EditorPrefsHelper.SaveBackgroundImagePath(_backgroundImagePath);
            EditorPrefsHelper.SaveBackgroundOpacity(_backgroundOpacity);
            EditorPrefsHelper.SaveBackgroundScaleMode(_backgroundScaleMode);
        }

        #endregion

        #region ユーティリティ

        private void SetStatus(string message, bool isError)
        {
            _statusMessage = message;
            _statusIsError = isError;
        }

        
        
        
        
        
        private string NormalizePickedPath(string absolutePath)
        {
            if (string.IsNullOrEmpty(absolutePath)) return absolutePath;

            var normalized = absolutePath.Replace('\\', '/').TrimEnd('/');

            
            if (normalized == "Assets" || normalized.StartsWith("Assets/"))
                return normalized;

            var dataPath    = Application.dataPath.Replace('\\', '/').TrimEnd('/');
            var projectRoot = System.IO.Path.GetDirectoryName(dataPath)
                ?.Replace('\\', '/')?.TrimEnd('/');

            if (!string.IsNullOrEmpty(projectRoot))
            {
                if (normalized.Equals(projectRoot, StringComparison.OrdinalIgnoreCase))
                    return "Assets";
                if (normalized.StartsWith(projectRoot + "/", StringComparison.OrdinalIgnoreCase))
                    return normalized.Substring(projectRoot.Length + 1);
            }

            
            EditorUtility.DisplayDialog(
                Loc.S.OutsideProjectTitle,
                string.Format(Loc.S.OutsideProjectMsgFmt, absolutePath),
                "OK");
            return string.Empty; 
        }

        private static bool IsSupportedRecoveryFile(string path)
        {
            var ext = Path.GetExtension(path);
            return string.Equals(ext, ".vrca", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(ext, ".vrcw", StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(ext, ".vrcp", StringComparison.OrdinalIgnoreCase);
        }

        private int CountManualFilesOfType(VrcaFileType fileType)
        {
            var count = 0;
            foreach (var info in _manualFileInfos)
            {
                if (info != null && info.FileType == fileType)
                    count++;
            }
            return count;
        }

        private static string GetFileTypeListLabel(VrcaFileInfo info)
        {
            if (info == null) return "Unknown";

            return info.FileType == VrcaFileType.World ? "World" :
                   info.FileType == VrcaFileType.Prop  ? "Prop" :
                   info.FileType == VrcaFileType.Avatar ? "Avatar" : "Unknown";
        }

        private string GetOutputFolderForFile(VrcaFileInfo info)
        {
            if (info != null && info.FileType == VrcaFileType.World)
                return _worldOutputPath;
            if (info != null && info.FileType == VrcaFileType.Prop)
                return _propOutputPath;
            return _avatarOutputPath;
        }

        private static AvatarRecoveryDiagnosticOptions GetDiagnosticOptionsForFile(VrcaFileInfo info)
        {
            var options = AvatarRecoveryDiagnosticOptions.Default;
            if (info != null && info.FileType == VrcaFileType.Prop)
                options.CheckAvatarDescriptor = false;
            return options;
        }

        private static string FormatFileSize(long bytes)
        {
            if (bytes < 1024)         return $"{bytes} B";
            if (bytes < 1024 * 1024)  return $"{bytes / 1024f:F1} KB";
            return $"{bytes / (1024f * 1024f):F1} MB";
        }

        
        
        
        
        private static string GetSafeDirectoryName(string path)
        {
            if (string.IsNullOrEmpty(path)) return string.Empty;
            try { return Path.GetDirectoryName(path) ?? string.Empty; }
            catch { return string.Empty; }
        }

        #endregion

        #region タブ4: ライセンス

        private void DrawLicenseTab()
        {
            _licenseScrollPos = EditorGUILayout.BeginScrollView(_licenseScrollPos);

            
            GUILayout.Label("AvatarRecovery", Styles.SectionHeader);
            GUILayout.Label(Loc.S.LicAvatarRecoveryDesc, Styles.WrappedLabel);
            GUILayout.Space(4);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(Loc.S.LicMITLinkLabel, GUILayout.Width(110));
            DrawLinkButton("MIT License (opensource.org)",
                "https://opensource.org/licenses/MIT");
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(12);

            
            GUILayout.Label("SARS (Dean2k/SARS)", Styles.SectionHeader);
            GUILayout.Label(Loc.S.LicSarsDesc, Styles.WrappedLabel);
            GUILayout.Space(4);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(Loc.S.LicSarsLinkLabel, GUILayout.Width(120));
            DrawLinkButton("github.com/Dean2k/SARS",
                "https://github.com/Dean2k/SARS");
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(12);

            
            GUILayout.Label("AssetRipper", Styles.SectionHeader);
            GUILayout.Label(Loc.S.LicAssetRipperDesc, Styles.WrappedLabel);
            GUILayout.Space(4);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label(Loc.S.LicAssetRipperDownloadLabel, GUILayout.Width(200));
            DrawLinkButton("SARS Release.zip",
                "https://github.com/Dean2k/SARS/releases/latest/download/Release.zip");
            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(12);

            
            EditorGUILayout.HelpBox(Loc.S.LicDisclaimer, MessageType.Warning);

            EditorGUILayout.EndScrollView();
        }

        
        private static void DrawLinkButton(string label, string url)
        {
            if (GUILayout.Button(label, Styles.LinkButton))
                Application.OpenURL(url);
            var lastRect = GUILayoutUtility.GetLastRect();
            EditorGUIUtility.AddCursorRect(lastRect, MouseCursor.Link);
        }

        #endregion

        #region 背景画像 (v1.8)

        
        
        
        
        
        
        
        
        private void DrawBackgroundImage()
        {
            
            
            
            if (Event.current.type != EventType.Repaint) return;

            EnsureBackgroundLoaded();
            if (_backgroundTexture == null) return;

            
            var prevColor = GUI.color;
            GUI.color = new Color(1f, 1f, 1f, _backgroundOpacity);

            var rect = new Rect(0, 0, position.width, position.height);
            var mode = (ScaleMode)_backgroundScaleMode;
            GUI.DrawTexture(rect, _backgroundTexture, mode, alphaBlend: true);

            GUI.color = prevColor;
        }

        
        
        
        
        private void DrawBackgroundImageSettings()
        {
            GUILayout.Label(Loc.S.BackgroundHeader, Styles.SectionHeader);

            
            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();
            _backgroundImagePath = EditorGUILayout.TextField(
                new GUIContent(Loc.S.BackgroundImageLabel, Loc.S.BackgroundImageTooltip),
                _backgroundImagePath);
            if (EditorGUI.EndChangeCheck())
            {
                EditorPrefsHelper.SaveBackgroundImagePath(_backgroundImagePath);
                ReleaseBackgroundTexture(); 
            }

            if (GUILayout.Button(Loc.S.BrowseDots, GUILayout.Width(60)))
            {
                var initial = string.IsNullOrEmpty(_backgroundImagePath)
                    ? string.Empty
                    : Path.GetDirectoryName(_backgroundImagePath) ?? string.Empty;
                var picked = EditorUtility.OpenFilePanel(
                    Loc.S.DialogSelectBackground, initial, "png,jpg,jpeg");
                if (!string.IsNullOrEmpty(picked))
                {
                    _backgroundImagePath = picked.Replace('\\', '/');
                    EditorPrefsHelper.SaveBackgroundImagePath(_backgroundImagePath);
                    ReleaseBackgroundTexture();
                    GUI.FocusControl(null);
                }
            }
            if (GUILayout.Button(Loc.S.BackgroundClearBtn, GUILayout.Width(60)))
            {
                _backgroundImagePath = string.Empty;
                EditorPrefsHelper.SaveBackgroundImagePath(string.Empty);
                ReleaseBackgroundTexture();
                GUI.FocusControl(null);
            }
            EditorGUILayout.EndHorizontal();

            
            if (!string.IsNullOrEmpty(_backgroundImagePath))
            {
                if (File.Exists(_backgroundImagePath))
                {
                    var ext = Path.GetExtension(_backgroundImagePath).ToLowerInvariant();
                    if (ext != ".png" && ext != ".jpg" && ext != ".jpeg")
                    {
                        EditorGUILayout.HelpBox(Loc.S.BackgroundWrongFormat, MessageType.Warning);
                    }
                    else if (_backgroundTexture != null)
                    {
                        EditorGUILayout.LabelField(
                            string.Format(Loc.S.BackgroundLoadedFmt,
                                _backgroundTexture.width, _backgroundTexture.height),
                            Styles.SuccessLabel);
                    }
                    else
                    {
                        EditorGUILayout.LabelField(Loc.S.BackgroundPending, EditorStyles.miniLabel);
                    }
                }
                else
                {
                    EditorGUILayout.HelpBox(
                        string.Format(Loc.S.BackgroundNotFoundFmt, _backgroundImagePath),
                        MessageType.Error);
                }
            }

            
            EditorGUI.BeginChangeCheck();
            _backgroundOpacity = EditorGUILayout.Slider(
                new GUIContent(Loc.S.OpacityLabel, Loc.S.OpacityTooltip),
                _backgroundOpacity, 0f, 1f);
            if (EditorGUI.EndChangeCheck())
                EditorPrefsHelper.SaveBackgroundOpacity(_backgroundOpacity);

            
            EditorGUI.BeginChangeCheck();
            _backgroundScaleMode = EditorGUILayout.Popup(
                new GUIContent(Loc.S.ScaleModeLabel, Loc.S.ScaleModeTooltip),
                _backgroundScaleMode,
                ScaleModeOptions);
            if (EditorGUI.EndChangeCheck())
                EditorPrefsHelper.SaveBackgroundScaleMode(_backgroundScaleMode);

            
            
            
            
            
            if (_backgroundTexture != null)
            {
                GUILayout.Space(4);
                EditorGUILayout.LabelField(Loc.S.PreviewLabel, EditorStyles.miniLabel);

                const float previewMaxHeight = 120f;
                const float previewMaxWidth  = 400f;

                
                float aspect = (float)_backgroundTexture.width / _backgroundTexture.height;
                float w = previewMaxWidth;
                float h = w / aspect;
                if (h > previewMaxHeight) { h = previewMaxHeight; w = h * aspect; }

                var previewRect = GUILayoutUtility.GetRect(w, h,
                    GUILayout.Width(w), GUILayout.Height(h));

                
                EditorGUI.DrawRect(previewRect, new Color(0f, 0f, 0f, 0.4f));

                
                GUI.DrawTexture(previewRect, _backgroundTexture,
                    (ScaleMode)_backgroundScaleMode, alphaBlend: true);
            }
        }

        
        
        
        
        private void EnsureBackgroundLoaded()
        {
            
            if (string.IsNullOrEmpty(_backgroundImagePath))
            {
                ReleaseBackgroundTexture();
                return;
            }

            
            if (_backgroundTexture != null &&
                string.Equals(_loadedTexturePath, _backgroundImagePath,
                    StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            
            ReleaseBackgroundTexture();

            
            
            
            
            try
            {
                if (!File.Exists(_backgroundImagePath))
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] 背景画像ファイルが存在しません: {_backgroundImagePath}");
                    return;
                }

                var bytes = File.ReadAllBytes(_backgroundImagePath);
                var tex = new Texture2D(2, 2, TextureFormat.RGBA32, mipChain: false);
                tex.hideFlags = HideFlags.HideAndDontSave;

                if (tex.LoadImage(bytes))
                {
                    
                    
                    tex.filterMode = FilterMode.Bilinear;
                    tex.wrapMode   = TextureWrapMode.Clamp;
                    tex.anisoLevel = 4;
                    tex.Apply(updateMipmaps: false, makeNoLongerReadable: true);

                    _backgroundTexture = tex;
                }
                else
                {
                    DestroyImmediate(tex);
                    Debug.LogWarning(
                        $"[AvatarRecovery] 背景画像のデコードに失敗: {_backgroundImagePath}");
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] 背景画像ロード失敗 '{_backgroundImagePath}': {ex.Message}");
            }
            finally
            {
                
                
                _loadedTexturePath = _backgroundImagePath;
            }
        }

        
        private void ReleaseBackgroundTexture()
        {
            if (_backgroundTexture != null)
            {
                DestroyImmediate(_backgroundTexture);
                _backgroundTexture = null;
            }
            _loadedTexturePath = null;
        }

        #endregion
    }
}
