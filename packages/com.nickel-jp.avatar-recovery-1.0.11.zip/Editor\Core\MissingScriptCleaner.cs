








using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    
    
    public enum MissingScriptDeletePolicy
    {
        
        [InspectorName("自動削除 (推奨)")]
        Always = 0,

        
        [InspectorName("展開後にポップアップで確認")]
        Ask = 1,

        
        [InspectorName("削除しない")]
        Never = 2,
    }

    
    
    
    public static class MissingScriptCleaner
    {
        
        public class CleanResult
        {
            
            public int ScannedGameObjects { get; set; }

            
            public int RemovedScripts { get; set; }
        }

        #region 公開 API

        
        
        
        public static CleanResult CleanGameObject(GameObject root)
        {
            var result = new CleanResult();
            if (root == null) return result;

            int removed = RemoveRecursive(root.transform, out int scanned);
            result.ScannedGameObjects = scanned;
            result.RemovedScripts     = removed;

            if (removed > 0)
            {
                Debug.Log(
                    $"[AvatarRecovery] MissingScriptCleaner: " +
                    $"{removed} 個の Missing Script を削除しました ({scanned} GameObjects 走査)");
            }
            return result;
        }

        
        
        
        
        public static CleanResult CleanPrefabAsset(string prefabPath)
        {
            var result = new CleanResult();

            if (string.IsNullOrEmpty(prefabPath)) return result;

            var prefabRoot = PrefabUtility.LoadPrefabContents(prefabPath);
            if (prefabRoot == null)
            {
                Debug.LogWarning($"[AvatarRecovery] Prefab を読み込めませんでした: {prefabPath}");
                return result;
            }

            try
            {
                int removed = RemoveRecursive(prefabRoot.transform, out int scanned);
                result.ScannedGameObjects = scanned;
                result.RemovedScripts     = removed;

                if (removed > 0)
                {
                    PrefabUtility.SaveAsPrefabAsset(prefabRoot, prefabPath);
                    Debug.Log(
                        $"[AvatarRecovery] MissingScriptCleaner: " +
                        $"{removed} 個の Missing Script を Prefab から削除 ({prefabPath})");
                }
            }
            finally
            {
                PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return result;
        }

        
        
        
        public static CleanResult CleanPrefabsInFolder(string folder)
        {
            var totalResult = new CleanResult();

            if (string.IsNullOrEmpty(folder) || !AssetDatabase.IsValidFolder(folder))
                return totalResult;

            var guids = AssetDatabase.FindAssets("t:Prefab", new[] { folder });
            foreach (var guid in guids)
            {
                var path   = AssetDatabase.GUIDToAssetPath(guid);
                var result = CleanPrefabAsset(path);
                totalResult.ScannedGameObjects += result.ScannedGameObjects;
                totalResult.RemovedScripts     += result.RemovedScripts;
            }
            return totalResult;
        }

        #endregion

        #region 内部実装

        
        
        
        
        private static int RemoveRecursive(Transform t, out int scanned)
        {
            scanned = 1;
            int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(t.gameObject);

            foreach (Transform child in t)
            {
                removed += RemoveRecursive(child, out int childScanned);
                scanned += childScanned;
            }
            return removed;
        }

        #endregion
    }
}
