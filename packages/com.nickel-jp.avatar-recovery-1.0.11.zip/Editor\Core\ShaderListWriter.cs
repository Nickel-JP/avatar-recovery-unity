










using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class ShaderListWriter
    {
        #region 定数

        public const string ReportSubFolderName = "_ShaderReport";

        
        public const string LegacySubFolderName = "List of Shaders";

        
        public const string SubFolderSuffix = "of Shaders";

        
        public const string SubFolderName = ReportSubFolderName;

        
        public const string FileName = "Shaders.txt";

        
        public const string MaterialMapFileName = "MaterialShaderMap.txt";

        
        public const string MaterialMapCsvFileName = "MaterialShaderMap.csv";

        #endregion

        #region 結果 DTO

        
        public class WriteResult
        {
            
            public bool Success { get; set; }

            
            public string OutputAssetPath { get; set; }

            
            public int ShaderCount { get; set; }

            
            public int MaterialShaderUsageCount { get; set; }

            
            public int UnresolvedMaterialShaderUsageCount { get; set; }

            
            public string MaterialMapOutputAssetPath { get; set; }

            
            public string MaterialMapCsvOutputAssetPath { get; set; }

            
            public string ErrorMessage { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        public static WriteResult WriteList(
            string targetFolder,
            Dictionary<string, ShaderGuidFixer.ShaderMapping> mappings,
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages,
            VrcaFileInfo info,
            bool wasApplied)
        {
            var result = new WriteResult();

            if (mappings == null)
                mappings = new Dictionary<string, ShaderGuidFixer.ShaderMapping>();

            if (mappings.Count == 0 &&
                (materialUsages == null || materialUsages.Count == 0))
            {
                result.Success = true; 
                return result;
            }

            if (string.IsNullOrEmpty(targetFolder))
            {
                result.ErrorMessage = "targetFolder が空です。";
                return result;
            }

            
            
            
            
            var normalizedTarget = targetFolder.Replace('\\', '/').TrimEnd('/');
            if (normalizedTarget != "Assets" && !normalizedTarget.StartsWith("Assets/"))
            {
                result.ErrorMessage =
                    $"targetFolder が Assets/ 相対パスではありません: {targetFolder}";
                Debug.LogWarning($"[AvatarRecovery] {result.ErrorMessage}");
                return result;
            }

            try
            {
                
                var subFolderAssetPath = GetSubFolderAssetPath(normalizedTarget);
                EnsureUnityFolder(subFolderAssetPath);

                
                var content = BuildText(mappings, materialUsages, info, wasApplied);

                
                WriteTextFile($"{subFolderAssetPath}/{FileName}", content, "Shaders.txt");

                
                var unityAssetPath = $"{subFolderAssetPath}/{FileName}";
                AssetDatabase.ImportAsset(unityAssetPath, ImportAssetOptions.ForceUpdate);

                if (materialUsages != null && materialUsages.Count > 0)
                {
                    var materialTextPath = $"{subFolderAssetPath}/{MaterialMapFileName}";
                    WriteTextFile(
                        materialTextPath,
                        BuildMaterialText(materialUsages, info),
                        MaterialMapFileName);
                    AssetDatabase.ImportAsset(materialTextPath, ImportAssetOptions.ForceUpdate);

                    var materialCsvPath = $"{subFolderAssetPath}/{MaterialMapCsvFileName}";
                    WriteTextFile(
                        materialCsvPath,
                        BuildMaterialCsv(materialUsages),
                        MaterialMapCsvFileName);
                    AssetDatabase.ImportAsset(materialCsvPath, ImportAssetOptions.ForceUpdate);

                    result.MaterialMapOutputAssetPath = materialTextPath;
                    result.MaterialMapCsvOutputAssetPath = materialCsvPath;
                }

                result.Success         = true;
                result.OutputAssetPath = unityAssetPath;
                result.ShaderCount     = mappings.Count;
                result.MaterialShaderUsageCount = materialUsages?.Count ?? 0;
                result.UnresolvedMaterialShaderUsageCount =
                    CountUnresolvedMaterialUsages(materialUsages);

                Debug.Log(
                    $"[AvatarRecovery] Shader一覧を出力: " +
                    $"{unityAssetPath} ({mappings.Count} 件)");
            }
            catch (Exception ex)
            {
                result.ErrorMessage = $"書き込みエラー: {ex.Message}";
                Debug.LogError($"[AvatarRecovery] ShaderListWriter 例外: {ex}");
            }

            return result;
        }

        
        public static string GetSubFolderName(string restoredRootAssetPath)
        {
            return ReportSubFolderName;
        }

        
        public static string GetSubFolderAssetPath(string restoredRootAssetPath)
        {
            var normalized = NormalizeAssetPath(restoredRootAssetPath).TrimEnd('/');
            if (string.IsNullOrEmpty(normalized))
                return null;

            return $"{normalized}/{GetSubFolderName(normalized)}";
        }

        private static string GetNamedLegacySubFolderName(string restoredRootAssetPath)
        {
            var normalized = NormalizeAssetPath(restoredRootAssetPath).TrimEnd('/');
            var restoredName = Path.GetFileName(normalized);
            if (string.IsNullOrWhiteSpace(restoredName))
                restoredName = "Restored";

            return $"{restoredName} {SubFolderSuffix}";
        }

        
        public static string FindSubFolderAssetPath(string restoredRootAssetPath)
        {
            var normalized = NormalizeAssetPath(restoredRootAssetPath).TrimEnd('/');
            if (string.IsNullOrEmpty(normalized))
                return null;

            var reportPath = GetSubFolderAssetPath(normalized);
            if (HasShaderListFiles(reportPath))
                return reportPath;

            var namedLegacyPath = $"{normalized}/{GetNamedLegacySubFolderName(normalized)}";
            if (HasShaderListFiles(namedLegacyPath))
                return namedLegacyPath;

            var legacyPath = $"{normalized}/{LegacySubFolderName}";
            if (HasShaderListFiles(legacyPath))
                return legacyPath;

            if (!AssetDatabase.IsValidFolder(normalized))
                return null;

            foreach (var child in AssetDatabase.GetSubFolders(normalized))
            {
                var folderName = Path.GetFileName(NormalizeAssetPath(child));
                if (!IsShaderListFolderName(folderName))
                    continue;

                if (HasShaderListFiles(child))
                    return NormalizeAssetPath(child);
            }

            return null;
        }

        
        public static bool IsShaderListFolderName(string folderName)
        {
            if (string.IsNullOrEmpty(folderName))
                return false;

            return folderName.Equals(ReportSubFolderName, StringComparison.OrdinalIgnoreCase) ||
                   folderName.Equals(LegacySubFolderName, StringComparison.OrdinalIgnoreCase) ||
                   folderName.EndsWith($" {SubFolderSuffix}", StringComparison.OrdinalIgnoreCase);
        }

        
        public static bool IsShaderListFolderAssetPath(string assetPath)
        {
            var normalized = NormalizeAssetPath(assetPath).TrimEnd('/');
            if (string.IsNullOrEmpty(normalized))
                return false;

            return IsShaderListFolderName(Path.GetFileName(normalized)) &&
                   HasShaderListFiles(normalized);
        }

        
        public static bool HasShaderListFiles(string listFolderAssetPath)
        {
            if (string.IsNullOrEmpty(listFolderAssetPath))
                return false;

            var normalized = NormalizeAssetPath(listFolderAssetPath).TrimEnd('/');
            return AssetPathExists($"{normalized}/{MaterialMapCsvFileName}") ||
                   AssetPathExists($"{normalized}/{MaterialMapFileName}") ||
                   AssetPathExists($"{normalized}/{FileName}");
        }

        #endregion

        #region テキスト構築

        
        
        
        
        private static string BuildText(
            Dictionary<string, ShaderGuidFixer.ShaderMapping> mappings,
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages,
            VrcaFileInfo info,
            bool wasApplied)
        {
            var sb = new StringBuilder();

            
            sb.AppendLine("================================================================");
            sb.AppendLine("  AvatarRecovery — 元バンドルに含まれていたシェーダー一覧");
            sb.AppendLine("================================================================");
            sb.AppendLine();
            sb.AppendLine($"復元元ファイル     : {info?.FileName ?? "(不明)"}");
            if (!string.IsNullOrEmpty(info?.BlueprintId))
                sb.AppendLine($"Blueprint ID       : {info.BlueprintId}");
            if (!string.IsNullOrEmpty(info?.UnityVersionString))
                sb.AppendLine($"Unity バージョン   : {info.UnityVersionString}");
            sb.AppendLine($"生成日時           : {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"検出シェーダー数   : {mappings.Count}");
            sb.AppendLine($"Material対応数     : {materialUsages?.Count ?? 0}");
            sb.AppendLine($"自動置換モード     : {(wasApplied ? "実行済み (マテリアルを書き換え済み)" : "スキップ (設定で OFF)")}" );
            sb.AppendLine();

            
            int resolved   = 0;
            int unresolved = 0;
            foreach (var m in mappings.Values)
            {
                if (m.ResolvedShader != null) resolved++;
                else                          unresolved++;
            }
            sb.AppendLine("── 解決状況 ─────────────────────────────────────────────");
            sb.AppendLine($"  ✓ プロジェクト内で解決: {resolved} 件");
            sb.AppendLine($"  ⚠ 未解決 (フォールバック): {unresolved} 件");
            sb.AppendLine();

            
            sb.AppendLine("── シェーダー明細 ───────────────────────────────────────");
            sb.AppendLine();

            int index = 1;
            
            var sorted = new List<ShaderGuidFixer.ShaderMapping>(mappings.Values);
            sorted.Sort((a, b) =>
                string.Compare(a.OriginalName ?? "", b.OriginalName ?? "",
                    StringComparison.OrdinalIgnoreCase));

            foreach (var m in sorted)
            {
                var status = m.ResolvedShader != null ? "✓ 解決済み" : "⚠ 未解決";

                sb.AppendLine($"[{index:00}] {status}");
                sb.AppendLine($"      元シェーダー名 : {m.OriginalName ?? "(不明)"}");

                
                var stubGuid = ExtractGuid(m.OldKey);
                if (!string.IsNullOrEmpty(stubGuid))
                    sb.AppendLine($"      stub GUID      : {stubGuid}");

                if (m.ResolvedShader != null)
                {
                    sb.AppendLine($"      置換先         : {m.ResolvedShader.name}");

                    
                    var newGuid = ExtractGuidFromYaml(m.NewYaml);
                    if (!string.IsNullOrEmpty(newGuid))
                        sb.AppendLine($"      置換先 GUID    : {newGuid}");
                }
                else
                {
                    sb.AppendLine($"      置換先         : (プロジェクト内に見つからず)");
                    sb.AppendLine($"      ヒント         : 対応するシェーダーをインポートしてください");
                }

                if (wasApplied && m.ReplaceCount > 0)
                    sb.AppendLine($"      書き換え回数   : {m.ReplaceCount} 箇所 (.mat 内)");

                sb.AppendLine();
                index++;
            }

            AppendMaterialShaderSummary(sb, materialUsages);

            
            sb.AppendLine("── 使い方 ───────────────────────────────────────────────");
            sb.AppendLine("  ・自動置換 ON: マテリアルの m_Shader は置換済みなので追加作業不要");
            sb.AppendLine("  ・自動置換 OFF: マテリアルはピンクのまま。この一覧を参考に");
            sb.AppendLine("                  手動でシェーダーを割り当て直してください。");
            sb.AppendLine("  ・MaterialShaderMap.*: 各マテリアルが復元直後に参照していた");
            sb.AppendLine("                        元シェーダー名の対応表です。");
            sb.AppendLine("  ・未解決シェーダー: プロジェクトに該当シェーダーをインポートしてから");
            sb.AppendLine("                      再展開、または手動で代替シェーダーを選択。");
            sb.AppendLine();
            sb.AppendLine("================================================================");
            sb.AppendLine(" generated by AvatarRecovery");
            sb.AppendLine("================================================================");

            return sb.ToString();
        }

        
        private static void AppendMaterialShaderSummary(
            StringBuilder sb,
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages)
        {
            if (materialUsages == null || materialUsages.Count == 0)
                return;

            sb.AppendLine("── Material → 元Shader 対応 ─────────────────────────────");
            sb.AppendLine("  詳細な一覧は MaterialShaderMap.txt / MaterialShaderMap.csv にも出力します。");
            sb.AppendLine();

            var sorted = SortMaterialUsages(materialUsages);
            int index = 1;
            foreach (var usage in sorted)
            {
                sb.AppendLine($"[{index:000}] {(usage.Resolved ? "OK" : "未解決")}");
                sb.AppendLine($"      Material名     : {usage.MaterialName ?? "(不明)"}");
                sb.AppendLine($"      Materialパス   : {usage.MaterialRelativePath ?? "(不明)"}");
                sb.AppendLine($"      元Shader名     : {usage.OriginalShaderName ?? "(特定不可)"}");
                if (usage.ShaderFileId != 0)
                    sb.AppendLine($"      Shader fileID  : {usage.ShaderFileId}");
                if (!string.IsNullOrEmpty(usage.ShaderGuid))
                    sb.AppendLine($"      Shader GUID    : {usage.ShaderGuid}");
                sb.AppendLine($"      状態           : {usage.Status ?? "(不明)"}");
                sb.AppendLine();
                index++;
            }
        }

        
        private static string BuildMaterialText(
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages,
            VrcaFileInfo info)
        {
            var sb = new StringBuilder();
            sb.AppendLine("================================================================");
            sb.AppendLine("  AvatarRecovery — Material → 元Shader 対応表");
            sb.AppendLine("================================================================");
            sb.AppendLine();
            sb.AppendLine($"復元元ファイル   : {info?.FileName ?? "(不明)"}");
            if (!string.IsNullOrEmpty(info?.UnityVersionString))
                sb.AppendLine($"Unity バージョン : {info.UnityVersionString}");
            sb.AppendLine($"生成日時         : {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"Material数       : {materialUsages?.Count ?? 0}");
            sb.AppendLine($"未解決数         : {CountUnresolvedMaterialUsages(materialUsages)}");
            sb.AppendLine();
            sb.AppendLine("この表はShader自動再割り当ての前、AssetRipper出力直後の .mat を解析して生成します。");
            sb.AppendLine("元Shader名は .mat の m_Shader GUID と AssetRipper出力の .shader.meta GUID を照合した値です。");
            sb.AppendLine("照合できない場合は推測せず、特定不可として記録します。");
            sb.AppendLine();

            var sorted = SortMaterialUsages(materialUsages);
            int index = 1;
            foreach (var usage in sorted)
            {
                sb.AppendLine($"[{index:000}] {(usage.Resolved ? "OK" : "未解決")}");
                sb.AppendLine($"      Material名     : {usage.MaterialName ?? "(不明)"}");
                sb.AppendLine($"      Materialパス   : {usage.MaterialRelativePath ?? "(不明)"}");
                sb.AppendLine($"      元Shader名     : {usage.OriginalShaderName ?? "(特定不可)"}");
                sb.AppendLine($"      Shader fileID  : {(usage.ShaderFileId != 0 ? usage.ShaderFileId.ToString() : "(なし)")}");
                sb.AppendLine($"      Shader GUID    : {usage.ShaderGuid ?? "(なし)"}");
                sb.AppendLine($"      状態           : {usage.Status ?? "(不明)"}");
                sb.AppendLine();
                index++;
            }

            sb.AppendLine("================================================================");
            sb.AppendLine(" generated by AvatarRecovery");
            sb.AppendLine("================================================================");
            return sb.ToString();
        }

        
        private static string BuildMaterialCsv(
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages)
        {
            var sb = new StringBuilder();
            sb.AppendLine("MaterialName,MaterialPath,OriginalShaderName,ShaderFileID,ShaderGuid,Status");

            foreach (var usage in SortMaterialUsages(materialUsages))
            {
                sb.Append(EscapeCsv(usage.MaterialName));
                sb.Append(',');
                sb.Append(EscapeCsv(usage.MaterialRelativePath));
                sb.Append(',');
                sb.Append(EscapeCsv(usage.OriginalShaderName));
                sb.Append(',');
                sb.Append(EscapeCsv(usage.ShaderFileId != 0 ? usage.ShaderFileId.ToString() : string.Empty));
                sb.Append(',');
                sb.Append(EscapeCsv(usage.ShaderGuid));
                sb.Append(',');
                sb.Append(EscapeCsv(usage.Status));
                sb.AppendLine();
            }

            return sb.ToString();
        }

        
        private static List<ShaderGuidFixer.MaterialShaderUsage> SortMaterialUsages(
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages)
        {
            var sorted = new List<ShaderGuidFixer.MaterialShaderUsage>();
            if (materialUsages != null)
                sorted.AddRange(materialUsages);

            sorted.Sort((a, b) =>
                string.Compare(
                    a?.MaterialRelativePath ?? string.Empty,
                    b?.MaterialRelativePath ?? string.Empty,
                    StringComparison.OrdinalIgnoreCase));

            return sorted;
        }

        
        private static int CountUnresolvedMaterialUsages(
            List<ShaderGuidFixer.MaterialShaderUsage> materialUsages)
        {
            if (materialUsages == null) return 0;

            int count = 0;
            foreach (var usage in materialUsages)
            {
                if (usage == null || !usage.Resolved)
                    count++;
            }

            return count;
        }

        
        private static string EscapeCsv(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;

            var escaped = value.Replace("\"", "\"\"");
            return $"\"{escaped}\"";
        }

        
        private static string ExtractGuid(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;
            const string marker = "guid: ";
            int idx = key.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0) return null;
            return key.Substring(idx + marker.Length).Trim();
        }

        
        private static string ExtractGuidFromYaml(string yaml)
        {
            if (string.IsNullOrEmpty(yaml)) return null;
            const string marker = "guid: ";
            int start = yaml.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return null;
            start += marker.Length;

            int end = yaml.IndexOf(',', start);
            if (end < 0) end = yaml.IndexOf('}', start);
            if (end < 0) return null;

            return yaml.Substring(start, end - start).Trim();
        }

        #endregion

        #region Unity フォルダ操作

        
        private static void EnsureUnityFolder(string unityPath)
        {
            var parts   = unityPath.Replace('\\', '/').Split('/');
            var current = parts[0]; 

            for (int i = 1; i < parts.Length; i++)
            {
                if (string.IsNullOrEmpty(parts[i])) continue;
                var next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }

        
        private static void WriteTextFile(string unityPath, string content, string context)
        {
            var absolutePath = GetAbsolutePath(unityPath);
            RecoveryNameUtility.WarnIfFullPathIsLong(absolutePath, context);

            using (var writer = LongPathIO.OpenWriter(absolutePath, append: false))
            {
                writer.Write(content ?? string.Empty);
            }
        }

        
        private static string GetAbsolutePath(string unityPath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(
                Path.Combine(projectRoot,
                    unityPath.Replace('/', Path.DirectorySeparatorChar)));
        }

        
        private static bool AssetPathExists(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return false;

            if (AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath) != null)
                return true;

            var absolute = GetAbsolutePath(assetPath);
            return !string.IsNullOrEmpty(absolute) &&
                   File.Exists(LongPathIO.NormalizeLongPath(absolute));
        }

        
        private static string NormalizeAssetPath(string path)
        {
            return string.IsNullOrEmpty(path) ? string.Empty : path.Replace('\\', '/');
        }

        #endregion
    }
}
