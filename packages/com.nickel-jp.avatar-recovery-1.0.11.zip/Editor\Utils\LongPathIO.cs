












using System;
using System.IO;
using System.Text;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    internal static class LongPathIO
    {
        #region 公開 API

        
        
        
        
        
        public static StreamReader OpenReader(string path)
        {
            return new StreamReader(NormalizeLongPath(path), Encoding.UTF8);
        }

        
        
        
        
        
        public static StreamWriter OpenWriter(string path, bool append = false)
        {
            var utf8NoBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
            return new StreamWriter(NormalizeLongPath(path), append, utf8NoBom);
        }

        
        
        
        
        
        
        
        
        
        public static bool TryAtomicReplace(string tempPath, string targetPath)
        {
            if (string.IsNullOrEmpty(tempPath) || string.IsNullOrEmpty(targetPath)) return false;

            var normTemp   = NormalizeLongPath(tempPath);
            var normTarget = NormalizeLongPath(targetPath);

            
            try
            {
                if (File.Exists(normTarget))
                {
                    File.Replace(normTemp, normTarget,
                        destinationBackupFileName: null,
                        ignoreMetadataErrors: true);
                    return true;
                }
            }
            catch
            {
                
            }

            
            try
            {
                if (File.Exists(normTarget)) File.Delete(normTarget);
                File.Move(normTemp, normTarget);
                return true;
            }
            catch
            {
                return false;
            }
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        public static string NormalizeLongPath(string path)
        {
            if (string.IsNullOrEmpty(path)) return path;

            
            if (Path.DirectorySeparatorChar != '\\') return path;

            
            if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) return path;

            try
            {
                var fullPath = Path.GetFullPath(path);

                
                if (fullPath.StartsWith(@"\\", StringComparison.Ordinal))
                {
                    return @"\\?\UNC\" + fullPath.Substring(2);
                }

                return @"\\?\" + fullPath;
            }
            catch
            {
                
                
                return path;
            }
        }

        #endregion
    }
}
