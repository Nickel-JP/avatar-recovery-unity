



using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    internal sealed class VrcaBackupPanel
    {
        #region 状態

        private string _backupDestPath    = string.Empty;
        private bool   _autoBackupEnabled;

        #endregion

        #region 初期化

        internal void OnEnable()
        {
            _backupDestPath    = EditorPrefsHelper.LoadBackupDestPath();
            _autoBackupEnabled = EditorPrefsHelper.LoadAutoBackupEnabled();
        }

        #endregion

        #region UI 描画

        internal void Draw(EditorWindow window)
        {
            GUILayout.Label(Loc.S.BPBackupHeader, Styles.SectionHeader);

            EditorGUILayout.HelpBox(Loc.S.BPBackupHelpBox, MessageType.Info);

            EditorGUILayout.Space(10);

            
            var newEnabled = EditorGUILayout.Toggle(Loc.S.BPBackupToggle, _autoBackupEnabled);
            if (newEnabled != _autoBackupEnabled)
            {
                _autoBackupEnabled = newEnabled;
                EditorPrefsHelper.SaveAutoBackupEnabled(_autoBackupEnabled);
                VrcaAutoBackup.RefreshWatcher();
            }

            EditorGUILayout.Space(6);

            
            EditorGUI.BeginDisabledGroup(!_autoBackupEnabled);

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(Loc.S.BPDestLabel, GUILayout.Width(130));
            var newDest = EditorGUILayout.TextField(_backupDestPath);
            if (newDest != _backupDestPath)
            {
                _backupDestPath = newDest;
                EditorPrefsHelper.SaveBackupDestPath(_backupDestPath);
            }
            if (GUILayout.Button(Loc.S.BPBrowseBtn, GUILayout.Width(70)))
            {
                var picked = EditorUtility.OpenFolderPanel(Loc.S.BPBrowseFolderTitle, _backupDestPath, "");
                if (!string.IsNullOrEmpty(picked))
                {
                    _backupDestPath = picked;
                    EditorPrefsHelper.SaveBackupDestPath(_backupDestPath);
                }
            }
            EditorGUILayout.EndHorizontal();

            EditorGUI.EndDisabledGroup();

            
            EditorGUILayout.Space(10);

            if (_autoBackupEnabled)
            {
                if (string.IsNullOrEmpty(_backupDestPath))
                {
                    EditorGUILayout.HelpBox(Loc.S.BPNoDestWarning, MessageType.Warning);
                }
                else
                {
                    EditorGUILayout.HelpBox(
                        string.Format(Loc.S.BPWatchingFmt, VrcaAutoBackup.AvatarsFolder, _backupDestPath),
                        MessageType.None);
                }
            }
            else
            {
                EditorGUILayout.HelpBox(Loc.S.BPDisabledMsg, MessageType.None);
            }
        }

        #endregion
    }
}
