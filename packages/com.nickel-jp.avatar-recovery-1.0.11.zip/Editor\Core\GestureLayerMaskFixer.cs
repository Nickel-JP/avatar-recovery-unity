





using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class GestureLayerMaskFixer
    {
        #region 結果 DTO

        public struct FixResult
        {
            
            public bool Fixed;
            
            public string AppliedMaskPath;
            
            public bool MaskWasCreated;
            
            public string SkipReason;
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        public static FixResult FixPrefab(string prefabAssetPath, string searchFolder)
        {
            var result = new FixResult();

            if (string.IsNullOrEmpty(prefabAssetPath))
            {
                result.SkipReason = "Prefab パスが空です。";
                return result;
            }

            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabAssetPath);
            if (prefab == null)
            {
                result.SkipReason = $"Prefab をロードできません: {prefabAssetPath}";
                return result;
            }

            
            var desc = FindAvatarDescriptor(prefab);
            if (desc == null)
            {
                result.SkipReason = "VRCAvatarDescriptor が見つかりません。";
                return result;
            }

            var descriptorObject = new SerializedObject(desc);
            var customizeAnimationLayers = descriptorObject.FindProperty("customizeAnimationLayers");
            if (customizeAnimationLayers == null || !customizeAnimationLayers.boolValue)
            {
                result.SkipReason = "customizeAnimationLayers が OFF のためスキップ。";
                return result;
            }

            
            var gestureLayerTypeValue = GetGestureLayerTypeValue(desc.GetType());
            if (!gestureLayerTypeValue.HasValue)
            {
                result.SkipReason = "Gesture Layer の enum 値を取得できません。";
                return result;
            }

            var baseAnimationLayers = descriptorObject.FindProperty("baseAnimationLayers");
            if (baseAnimationLayers == null || !baseAnimationLayers.isArray)
            {
                result.SkipReason = "baseAnimationLayers を取得できません。";
                return result;
            }

            AnimatorController gestureAc = null;
            for (var i = 0; i < baseAnimationLayers.arraySize; i++)
            {
                var layer = baseAnimationLayers.GetArrayElementAtIndex(i);
                var type = layer.FindPropertyRelative("type");
                if (type == null || type.intValue != gestureLayerTypeValue.Value) continue;

                var isDefault = layer.FindPropertyRelative("isDefault");
                var animatorController = layer.FindPropertyRelative("animatorController");
                if ((isDefault != null && isDefault.boolValue) ||
                    animatorController == null ||
                    animatorController.objectReferenceValue == null)
                    break;

                gestureAc = animatorController.objectReferenceValue as AnimatorController;
                break;
            }

            if (gestureAc == null)
            {
                result.SkipReason = "Gesture Layer の AnimatorController が取得できません。";
                return result;
            }

            
            var layers = gestureAc.layers;
            if (layers.Length == 0)
            {
                result.SkipReason = "AnimatorController にレイヤーがありません。";
                return result;
            }

            if (layers[0].avatarMask != null)
            {
                result.SkipReason = "Layer[0] に AvatarMask が既に設定されています。";
                return result;
            }

            
            var mask = FindSuitableMask(searchFolder, gestureAc);

            bool wasCreated = false;
            if (mask == null)
            {
                
                mask = CreateHandsMask(searchFolder);
                wasCreated = true;
                Debug.Log("[AvatarRecovery] GestureLayerMaskFixer: 既存マスクが見つからないため Hands Only マスクを新規生成しました。");
            }
            else
            {
                Debug.Log($"[AvatarRecovery] GestureLayerMaskFixer: 復元済みマスクを流用します: {AssetDatabase.GetAssetPath(mask)}");
            }

            if (mask == null)
            {
                result.SkipReason = "AvatarMask の取得・生成に失敗しました。";
                return result;
            }

            
            var layer0 = layers[0];
            layer0.avatarMask = mask;
            layers[0] = layer0;
            gestureAc.layers = layers;
            EditorUtility.SetDirty(gestureAc);
            AssetDatabase.SaveAssets();

            result.Fixed          = true;
            result.AppliedMaskPath = AssetDatabase.GetAssetPath(mask);
            result.MaskWasCreated = wasCreated;

            Debug.Log(
                $"[AvatarRecovery] GestureLayerMaskFixer: Layer[0].avatarMask を設定しました。\n" +
                $"  Controller : {AssetDatabase.GetAssetPath(gestureAc)}\n" +
                $"  Mask       : {result.AppliedMaskPath} ({(wasCreated ? "新規生成" : "既存流用")})");

            return result;
        }

        #endregion

        #region VRChat Avatar Descriptor 取得

        private static Component FindAvatarDescriptor(GameObject prefab)
        {
            if (prefab == null) return null;

            foreach (var component in prefab.GetComponentsInChildren<Component>(includeInactive: true))
            {
                if (component == null) continue;

                var type = component.GetType();
                if (string.Equals(
                        type.FullName,
                        "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor",
                        StringComparison.Ordinal))
                    return component;
            }

            return null;
        }

        private static int? GetGestureLayerTypeValue(Type descriptorType)
        {
            if (descriptorType == null) return null;

            var enumType = descriptorType.GetNestedType(
                "AnimLayerType",
                System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic);
            if (enumType == null || !enumType.IsEnum) return null;

            try
            {
                return Convert.ToInt32(Enum.Parse(enumType, "Gesture"));
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] GestureLayerMaskFixer: Gesture enum 取得失敗: {ex.Message}");
                return null;
            }
        }

        #endregion

        #region マスク探索

        
        
        
        
        
        
        
        
        
        private static AvatarMask FindSuitableMask(string searchFolder, AnimatorController gestureAc)
        {
            if (string.IsNullOrEmpty(searchFolder)) return null;

            var guids = AssetDatabase.FindAssets("t:AvatarMask", new[] { searchFolder });
            if (guids == null || guids.Length == 0) return null;

            var candidates = new List<(AvatarMask mask, int priority)>();

            
            var acPath   = AssetDatabase.GetAssetPath(gestureAc);
            var acFolder = string.IsNullOrEmpty(acPath)
                ? string.Empty
                : Path.GetDirectoryName(acPath)?.Replace('\\', '/') ?? string.Empty;

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path)) continue;

                var mask = AssetDatabase.LoadAssetAtPath<AvatarMask>(path);
                if (mask == null) continue;

                int priority = 0;

                
                var maskFolder = Path.GetDirectoryName(path)?.Replace('\\', '/') ?? string.Empty;
                if (!string.IsNullOrEmpty(acFolder) &&
                    string.Equals(maskFolder, acFolder, StringComparison.OrdinalIgnoreCase))
                    priority += 100;

                
                if (IsHandsOnlyMask(mask))
                    priority += 50;

                
                var nameLower = Path.GetFileNameWithoutExtension(path).ToLowerInvariant();
                if (nameLower.Contains("gesture") || nameLower.Contains("hand") || nameLower.Contains("finger"))
                    priority += 10;

                if (priority > 0)
                    candidates.Add((mask, priority));
            }

            if (candidates.Count == 0) return null;

            
            candidates.Sort((a, b) => b.priority.CompareTo(a.priority));
            return candidates[0].mask;
        }

        
        
        
        
        private static bool IsHandsOnlyMask(AvatarMask mask)
        {
            if (mask == null) return false;

            
            var handParts = new[]
            {
                AvatarMaskBodyPart.LeftFingers,
                AvatarMaskBodyPart.RightFingers,
            };

            
            var bodyParts = new[]
            {
                AvatarMaskBodyPart.Body,
                AvatarMaskBodyPart.Head,
                AvatarMaskBodyPart.LeftLeg,
                AvatarMaskBodyPart.RightLeg,
                AvatarMaskBodyPart.LeftArm,
                AvatarMaskBodyPart.RightArm,
                AvatarMaskBodyPart.Root,
            };

            foreach (var part in handParts)
                if (!mask.GetHumanoidBodyPartActive(part)) return false;

            foreach (var part in bodyParts)
                if (mask.GetHumanoidBodyPartActive(part)) return false;

            return true;
        }

        #endregion

        #region マスク生成

        
        
        
        
        private static AvatarMask CreateHandsMask(string searchFolder)
        {
            var mask = new AvatarMask();

            
            for (int i = 0; i < (int)AvatarMaskBodyPart.LastBodyPart; i++)
                mask.SetHumanoidBodyPartActive((AvatarMaskBodyPart)i, false);

            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.LeftFingers,  true);
            mask.SetHumanoidBodyPartActive(AvatarMaskBodyPart.RightFingers, true);

            
            var savePath = string.IsNullOrEmpty(searchFolder)
                ? "Assets/GestureHandMask.mask"
                : searchFolder.TrimEnd('/') + "/GestureHandMask.mask";

            
            if (AssetDatabase.LoadAssetAtPath<AvatarMask>(savePath) != null)
            {
                var dir  = Path.GetDirectoryName(savePath)?.Replace('\\', '/') ?? "Assets";
                var stem = Path.GetFileNameWithoutExtension(savePath);
                int n = 2;
                while (AssetDatabase.LoadAssetAtPath<AvatarMask>($"{dir}/{stem}_{n}.mask") != null)
                    n++;
                savePath = $"{dir}/{stem}_{n}.mask";
            }

            try
            {
                AssetDatabase.CreateAsset(mask, savePath);
                AssetDatabase.SaveAssets();
                return AssetDatabase.LoadAssetAtPath<AvatarMask>(savePath);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] GestureLayerMaskFixer: マスク保存失敗: {ex.Message}");
                return null;
            }
        }

        #endregion
    }
}
