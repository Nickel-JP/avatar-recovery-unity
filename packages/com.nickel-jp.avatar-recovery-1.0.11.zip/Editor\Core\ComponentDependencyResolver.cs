




















using System;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    internal static class ComponentDependencyResolver
    {
        #region 公開 API

        
        
        
        
        
        
        
        public static Component TryAddComponent(GameObject go, Type type)
        {
            if (go == null || type == null) return null;

            try
            {
                
                
                return ObjectFactory.AddComponent(go, type);
            }
            catch (Exception ex)
            {
                return HandleAddFailure(go, type, ex);
            }
        }

        #endregion

        #region 内部実装 — エラー処理と依存追加

        
        
        
        
        
        
        
        private static Component HandleAddFailure(GameObject go, Type type, Exception ex)
        {
            var msg = ex.Message ?? string.Empty;

            
            
            
            if (msg.StartsWith("Adding component failed. Add required component of type",
                    StringComparison.Ordinal))
            {
                var reqAttrs = type.GetCustomAttributes(typeof(RequireComponent), inherit: true);
                if (reqAttrs.Length > 0)
                {
                    foreach (var attr in reqAttrs)
                    {
                        AddRequireComponents(go, (RequireComponent)attr);
                    }
                    
                    try
                    {
                        return ObjectFactory.AddComponent(go, type);
                    }
                    catch (Exception retryEx)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] AddComponent 再試行失敗 ({type.FullName}): " +
                            retryEx.Message);
                        return null;
                    }
                }
                return null;
            }

            
            
            if (msg.StartsWith("'type' parameter is abstract and can't be used in the ObjectFactory",
                    StringComparison.Ordinal) ||
                msg.EndsWith("because it is an editor script. To attach a script it needs to be outside the 'Editor' folder.",
                    StringComparison.Ordinal))
            {
                return null;
            }

            
            Debug.LogWarning(
                $"[AvatarRecovery] AddComponent 失敗 ({type.FullName}): {msg}");
            return null;
        }

        
        
        
        
        private static bool AddRequireComponents(GameObject go, RequireComponent rc)
        {
            bool added = false;
            if (rc.m_Type0 != null && FindTypeAndTryAdd(go, rc.m_Type0)) added = true;
            if (rc.m_Type1 != null && FindTypeAndTryAdd(go, rc.m_Type1)) added = true;
            if (rc.m_Type2 != null && FindTypeAndTryAdd(go, rc.m_Type2)) added = true;
            return added;
        }

        
        
        
        
        
        
        private static bool FindTypeAndTryAdd(GameObject go, Type baseType)
        {
            if (baseType == null) return false;
            if (typeof(Transform).IsAssignableFrom(baseType)) return false;

            try
            {
                var c = ObjectFactory.AddComponent(go, baseType);
                return c != null;
            }
            catch (Exception ex)
            {
                var msg = ex.Message ?? string.Empty;

                
                if (msg.StartsWith("'type' parameter is abstract and can't be used in the ObjectFactory",
                        StringComparison.Ordinal))
                {
                    var derived = TypeCache.GetTypesDerivedFrom(baseType);
                    foreach (var t in derived)
                    {
                        
                        if (t.IsAbstract) continue;
                        if (FindTypeAndTryAdd(go, t)) return true;
                    }
                }
                return false;
            }
        }

        #endregion
    }
}
