









using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EditorTools.AvatarRecovery
{
    
    
    
    internal class MissingScriptSearchPanel
    {
        #region 内部データ型

        private enum ScanMode { None, DropTarget, FullHierarchy }

        private struct MissingEntry
        {
            public GameObject Go;
            public int        ComponentIndex;
            public string     HierarchyPath;
            public bool       IsPrefabInstance;
        }

        #endregion

        #region 状態 (タブ切替で保持)

        private readonly List<MissingEntry> _missingList    = new List<MissingEntry>();
        private readonly HashSet<int>       _selectedMissingIndices = new HashSet<int>();
        

        private GameObject _targetRoot;
        private Vector2    _scrollPos;
        private ScanMode   _lastScanMode = ScanMode.None;
        private bool       _isDragOver;
        private string     _filterText = string.Empty;

        
        private int _lastClickedFilteredPos = -1;

        
        private List<int> _cachedFilteredIndices;
        private string    _cachedFilterText;

        
        private GUIStyle _dropAreaStyle;
        private GUIStyle _pathLabelStyle;

        #endregion

        #region 公開 API

        
        
        
        public void Draw(EditorWindow ownerWindow)
        {
            EnsureStyles();

            DrawDropArea(ownerWindow);
            GUILayout.Space(2);
            DrawScanButtons();
            GUILayout.Space(4);

            if (_lastScanMode == ScanMode.None)
            {
                EditorGUILayout.HelpBox(Loc.S.MSNoScanHelp, MessageType.Info);
                return;
            }

            if (_missingList.Count == 0)
            {
                EditorGUILayout.HelpBox(Loc.S.MSNoMissingHelp, MessageType.Info);
                if (GUILayout.Button(Loc.S.MSRescanBtn, GUILayout.Height(24)))
                    RunScan(_lastScanMode);
                return;
            }

            DrawFilterBar();
            DrawToolbar();
            GUILayout.Space(2);
            DrawList();
            GUILayout.Space(4);
            DrawDeleteButton();
        }

        #endregion

        #region GUI - ドロップエリア

        private void DrawDropArea(EditorWindow ownerWindow)
        {
            float height = _targetRoot != null ? 48f : 56f;
            Rect dropRect = GUILayoutUtility.GetRect(0, height, GUILayout.ExpandWidth(true));

            Color bg = _isDragOver
                ? new Color(0.3f, 0.6f, 1f, 0.25f)
                : new Color(0.2f, 0.2f, 0.2f, 0.15f);
            EditorGUI.DrawRect(dropRect, bg);

            string label = _targetRoot != null
                ? string.Format(Loc.S.MSDropHintHasTargetFmt, _targetRoot.name)
                : Loc.S.MSDropHintNoTarget;
            GUI.Label(dropRect, label, _dropAreaStyle);

            HandleDropEvents(dropRect, ownerWindow);
        }

        private void HandleDropEvents(Rect dropRect, EditorWindow ownerWindow)
        {
            Event e = Event.current;

            switch (e.type)
            {
                case EventType.DragUpdated:
                case EventType.DragPerform:
                    if (!dropRect.Contains(e.mousePosition)) break;

                    DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                    _isDragOver = (e.type == EventType.DragUpdated);

                    if (e.type == EventType.DragPerform)
                    {
                        DragAndDrop.AcceptDrag();
                        _isDragOver = false;

                        foreach (var obj in DragAndDrop.objectReferences)
                        {
                            if (obj is GameObject go)
                            {
                                _targetRoot = go;
                                RunScan(ScanMode.DropTarget);
                                break;
                            }
                        }
                    }
                    e.Use();
                    if (ownerWindow != null) ownerWindow.Repaint();
                    break;

                case EventType.DragExited:
                    _isDragOver = false;
                    if (ownerWindow != null) ownerWindow.Repaint();
                    break;
            }
        }

        #endregion

        #region GUI - スキャン操作 / フィルター / ツールバー

        private void DrawScanButtons()
        {
            using (new EditorGUILayout.HorizontalScope())
            {
                if (GUILayout.Button(Loc.S.MSScanHierarchyBtn, GUILayout.Height(28)))
                {
                    _targetRoot = null;
                    RunScan(ScanMode.FullHierarchy);
                }
            }
        }

        private void DrawFilterBar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                GUILayout.Label(Loc.S.MSFilterLabel, GUILayout.Width(60));
                EditorGUI.BeginChangeCheck();
                _filterText = EditorGUILayout.TextField(_filterText, EditorStyles.toolbarSearchField);
                if (EditorGUI.EndChangeCheck())
                {
                    InvalidateFilterCache();
                    ClearSelection();
                }

                if (GUILayout.Button("✕", EditorStyles.toolbarButton, GUILayout.Width(24)))
                {
                    _filterText = string.Empty;
                    InvalidateFilterCache();
                    ClearSelection();
                }
            }
        }

        private void DrawToolbar()
        {
            var filtered = GetFilteredIndices();

            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                string info = string.IsNullOrEmpty(_filterText)
                    ? string.Format(Loc.S.MSInfoNoFilterFmt,
                        _missingList.Count, _selectedMissingIndices.Count)
                    : string.Format(Loc.S.MSInfoFilterFmt,
                        filtered.Count, _missingList.Count, _selectedMissingIndices.Count);

                GUILayout.Label(info, EditorStyles.toolbarButton, GUILayout.ExpandWidth(true));
                GUILayout.FlexibleSpace();

                if (GUILayout.Button(Loc.S.MSRescanBtn, EditorStyles.toolbarButton, GUILayout.Width(78)))
                    RunScan(_lastScanMode);

                if (GUILayout.Button(Loc.S.MSSelectAllBtn, EditorStyles.toolbarButton, GUILayout.Width(70)))
                {
                    for (int p = 0; p < filtered.Count; p++)
                        _selectedMissingIndices.Add(filtered[p]);
                }

                if (GUILayout.Button(Loc.S.MSClearAllBtn, EditorStyles.toolbarButton, GUILayout.Width(70)))
                {
                    ClearSelection();
                }
            }
        }

        #endregion

        #region GUI - 検出リスト

        
        
        
        
        
        
        
        
        
        private void DrawList()
        {
            var filtered = GetFilteredIndices();
            var ev = Event.current;

            
            using var scroll = new EditorGUILayout.ScrollViewScope(_scrollPos);
            _scrollPos = scroll.scrollPosition;

            for (int filteredPos = 0; filteredPos < filtered.Count; filteredPos++)
            {
                int actualIndex = filtered[filteredPos];
                var entry       = _missingList[actualIndex];
                if (entry.Go == null) continue;

                bool selected = _selectedMissingIndices.Contains(actualIndex);

                Rect rowRect = EditorGUILayout.GetControlRect(GUILayout.Height(20));

                
                if (selected)
                    EditorGUI.DrawRect(rowRect, new Color(0.24f, 0.48f, 0.90f, 0.30f));
                else if (filteredPos % 2 == 1)
                    EditorGUI.DrawRect(rowRect, new Color(0f, 0f, 0f, 0.06f));

                
                Rect checkRect = new Rect(rowRect.x + 4, rowRect.y + 2, 16, 16);
                bool newCheck = EditorGUI.Toggle(checkRect, selected);
                if (newCheck != selected)
                {
                    if (newCheck) _selectedMissingIndices.Add(actualIndex);
                    else          _selectedMissingIndices.Remove(actualIndex);
                    _lastClickedFilteredPos = filteredPos;
                }

                
                Rect labelRect = new Rect(checkRect.xMax + 6, rowRect.y, rowRect.width * 0.4f, rowRect.height);
                string mainLabel = $"{entry.Go.name}  [Component #{entry.ComponentIndex}]" +
                                   (entry.IsPrefabInstance ? "  (Prefab)" : "");
                GUI.Label(labelRect, mainLabel, EditorStyles.label);

                
                Rect pathRect = new Rect(
                    labelRect.xMax + 4,
                    rowRect.y,
                    rowRect.xMax - labelRect.xMax - 8,
                    rowRect.height);
                GUI.Label(pathRect, TruncatePath(entry.HierarchyPath, 60), _pathLabelStyle);

                
                if (ev.type == EventType.MouseDown && ev.button == 0)
                {
                    var rowClickRect = new Rect(checkRect.xMax + 2, rowRect.y, rowRect.xMax - checkRect.xMax - 2, rowRect.height);
                    if (rowClickRect.Contains(ev.mousePosition))
                    {
                        HandleRowClick(filteredPos, filtered, ev);
                        ev.Use();
                    }
                }
            }
        }

        
        
        
        
        private void HandleRowClick(int filteredPos, List<int> filtered, Event ev)
        {
            if (filtered == null || filteredPos < 0 || filteredPos >= filtered.Count) return;
            int actualIndex = filtered[filteredPos];

            
            if (ev.shift && _lastClickedFilteredPos >= 0)
            {
                int from = Mathf.Min(_lastClickedFilteredPos, filteredPos);
                int to   = Mathf.Max(_lastClickedFilteredPos, filteredPos);
                for (int p = from; p <= to; p++)
                {
                    if (p >= 0 && p < filtered.Count)
                        _selectedMissingIndices.Add(filtered[p]);
                }
                
                return;
            }

            
            if (ev.control || ev.command)
            {
                if (_selectedMissingIndices.Contains(actualIndex))
                    _selectedMissingIndices.Remove(actualIndex);
                else
                    _selectedMissingIndices.Add(actualIndex);
                _lastClickedFilteredPos = filteredPos;
                return;
            }

            
            _selectedMissingIndices.Clear();
            _selectedMissingIndices.Add(actualIndex);
            _lastClickedFilteredPos = filteredPos;
        }

        #endregion

        #region GUI - 削除ボタン

        private void DrawDeleteButton()
        {
            int count = _selectedMissingIndices.Count;
            bool hasSelection = count > 0;

            using (new EditorGUI.DisabledScope(!hasSelection))
            {
                Color old = GUI.backgroundColor;
                GUI.backgroundColor = hasSelection ? new Color(1f, 0.4f, 0.4f) : Color.gray;

                if (GUILayout.Button(
                        string.Format(Loc.S.MSDeleteBtnFmt, count),
                        GUILayout.Height(32)))
                {
                    DeleteSelected();
                }

                GUI.backgroundColor = old;
            }
        }

        #endregion

        #region スキャン処理

        private void RunScan(ScanMode mode)
        {
            _missingList.Clear();
            ClearSelection();
            _lastScanMode = ScanMode.None;
            InvalidateFilterCache();

            var roots = new List<GameObject>();

            if (mode == ScanMode.FullHierarchy)
            {
                
                for (int i = 0; i < SceneManager.sceneCount; i++)
                {
                    var scene = SceneManager.GetSceneAt(i);
                    if (scene.isLoaded)
                        roots.AddRange(scene.GetRootGameObjects());
                }

                
                var prefabStage = UnityEditor.SceneManagement.PrefabStageUtility.GetCurrentPrefabStage();
                if (prefabStage != null && prefabStage.prefabContentsRoot != null)
                    roots.Add(prefabStage.prefabContentsRoot);
            }
            else if (mode == ScanMode.DropTarget)
            {
                if (_targetRoot == null) return;
                roots.Add(_targetRoot);
            }

            int totalObjects = 0;
            foreach (var root in roots)
            {
                if (root != null)
                    totalObjects += root.GetComponentsInChildren<Transform>(includeInactive: true).Length;
            }

            int processed = 0;
            try
            {
                foreach (var root in roots)
                {
                    if (root == null) continue;

                    var allTransforms = root.GetComponentsInChildren<Transform>(includeInactive: true);
                    foreach (var t in allTransforms)
                    {
                        
                        
                        if (t == null) continue;

                        processed++;

                        
                        if (totalObjects > 500 && processed % 200 == 0)
                        {
                            
                            float ratio = totalObjects > 0 ? (float)processed / totalObjects : 0f;
                            if (EditorUtility.DisplayCancelableProgressBar(
                                    Loc.S.MSScanProgressTitle,
                                    $"{processed} / {totalObjects}",
                                    ratio))
                            {
                                Debug.Log("[AvatarRecovery] [MissingScriptSearch] スキャンキャンセル");
                                return;
                            }
                        }

                        var go = t.gameObject;
                        if (go == null) continue; 

                        var components = go.GetComponents<Component>();
                        for (int ci = 0; ci < components.Length; ci++)
                        {
                            if (components[ci] == null)
                            {
                                _missingList.Add(new MissingEntry
                                {
                                    Go               = go,
                                    ComponentIndex   = ci,
                                    HierarchyPath    = GetHierarchyPath(go),
                                    IsPrefabInstance = PrefabUtility.IsPartOfPrefabInstance(go),
                                });
                            }
                        }
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            _lastScanMode = mode;

            Debug.Log(
                $"[AvatarRecovery] [MissingScriptSearch] スキャン完了: " +
                $"{_missingList.Count} 件検出 " +
                $"(対象 {(mode == ScanMode.FullHierarchy ? "Hierarchy 全体" : "ドロップ対象")}, " +
                $"走査 {processed} GameObjects)");
        }

        #endregion

        #region 削除処理

        private void DeleteSelected()
        {
            if (_selectedMissingIndices.Count == 0) return;

            
            var actualIndices = new List<int>();
            foreach (int idx in _selectedMissingIndices)
            {
                if (idx >= 0 && idx < _missingList.Count)
                    actualIndices.Add(idx);
            }

            if (actualIndices.Count == 0) return;

            
            bool hasPrefab = actualIndices.Any(i => _missingList[i].IsPrefabInstance);
            string prefabWarn = hasPrefab ? Loc.S.MSPrefabWarning : "";

            bool confirmed = EditorUtility.DisplayDialog(
                Loc.S.MSDeleteConfirmTitle,
                string.Format(Loc.S.MSDeleteConfirmMsgFmt, actualIndices.Count, prefabWarn),
                Loc.S.MSDeleteBtn, Loc.S.Cancel);
            if (!confirmed) return;

            
            var entriesByGameObject = new Dictionary<GameObject, List<MissingEntry>>();
            foreach (int idx in actualIndices)
            {
                var entry = _missingList[idx];
                if (entry.Go == null) continue;

                if (!entriesByGameObject.TryGetValue(entry.Go, out var entries))
                {
                    entries = new List<MissingEntry>();
                    entriesByGameObject[entry.Go] = entries;
                }
                entries.Add(entry);
            }

            
            Undo.SetCurrentGroupName("Delete Missing Scripts (AvatarRecovery)");
            int undoGroup = Undo.GetCurrentGroup();

            int totalRemoved = 0;
            foreach (var kv in entriesByGameObject)
            {
                int removed = RemoveSelectedMissingScripts(kv.Key, kv.Value);
                totalRemoved += removed;
            }

            Undo.CollapseUndoOperations(undoGroup);

            Debug.Log(
                $"[AvatarRecovery] [MissingScriptSearch] {entriesByGameObject.Count} 個の GameObject から " +
                $"選択された Missing Script を合計 {totalRemoved} 個削除しました (Undo 可能)");

            
            RunScan(_lastScanMode);
        }

        private static int RemoveSelectedMissingScripts(GameObject go, List<MissingEntry> entries)
        {
            if (go == null || entries == null || entries.Count == 0) return 0;

            var selectedIndices = new HashSet<int>(entries.Select(e => e.ComponentIndex));
            var components = go.GetComponents<Component>();
            var missingIndices = new HashSet<int>();
            for (int i = 0; i < components.Length; i++)
            {
                if (components[i] == null)
                    missingIndices.Add(i);
            }

            if (missingIndices.Count == 0) return 0;

            if (!missingIndices.SetEquals(selectedIndices))
            {
                Debug.LogWarning(
                    "[AvatarRecovery] [MissingScriptSearch] Unity API では同一 GameObject 上の " +
                    "Missing Script をスロット単位で安全に削除できないため、部分選択の削除をスキップしました: " +
                    GetHierarchyPath(go));
                return 0;
            }

            Undo.RegisterCompleteObjectUndo(go, "Remove Missing Scripts");
            int removed = GameObjectUtility.RemoveMonoBehavioursWithMissingScript(go);

            if (removed > 0)
            {
                EditorUtility.SetDirty(go);

                if (PrefabUtility.IsPartOfPrefabInstance(go))
                    PrefabUtility.RecordPrefabInstancePropertyModifications(go);
            }

            return removed;
        }

        #endregion

        #region フィルター / ユーティリティ

        private List<int> GetFilteredIndices()
        {
            
            if (_cachedFilteredIndices != null && _cachedFilterText == _filterText)
                return _cachedFilteredIndices;

            var result = new List<int>();
            var lowered = string.IsNullOrEmpty(_filterText) ? null : _filterText.ToLowerInvariant();

            for (int i = 0; i < _missingList.Count; i++)
            {
                if (_missingList[i].Go == null) continue;

                if (lowered != null)
                {
                    if (!_missingList[i].HierarchyPath.ToLowerInvariant().Contains(lowered) &&
                        !_missingList[i].Go.name.ToLowerInvariant().Contains(lowered))
                        continue;
                }

                result.Add(i);
            }

            _cachedFilteredIndices = result;
            _cachedFilterText = _filterText;
            return result;
        }

        private void InvalidateFilterCache()
        {
            _cachedFilteredIndices = null;
            _cachedFilterText = null;
        }

        private void ClearSelection()
        {
            _selectedMissingIndices.Clear();
            _lastClickedFilteredPos = -1;
        }

        private static string GetHierarchyPath(GameObject go)
        {
            var parts = new List<string>();
            var t = go.transform;
            while (t != null)
            {
                parts.Insert(0, t.name);
                t = t.parent;
            }
            return string.Join("/", parts);
        }

        private static string TruncatePath(string path, int maxChars)
        {
            if (string.IsNullOrEmpty(path) || path.Length <= maxChars) return path ?? string.Empty;
            return "…" + path.Substring(path.Length - maxChars);
        }

        #endregion

        #region GUIStyle 初期化

        private void EnsureStyles()
        {
            if (_dropAreaStyle == null)
            {
                _dropAreaStyle = new GUIStyle(GUI.skin.box)
                {
                    alignment = TextAnchor.MiddleCenter,
                    fontSize  = 12,
                    fontStyle = FontStyle.Bold,
                };
            }

            if (_pathLabelStyle == null)
            {
                _pathLabelStyle = new GUIStyle(EditorStyles.miniLabel)
                {
                    alignment = TextAnchor.MiddleRight,
                };
            }
        }

        #endregion
    }
}
