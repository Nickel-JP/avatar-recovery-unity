
















using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class PoseResetter
    {
        #region 結果 DTO

        
        public class ResetResult
        {
            
            public int ProcessedSmrCount { get; set; }

            
            public int ResetBoneCount { get; set; }

            
            public int HumanoidResetCount { get; set; }

            
            public int GenericAnimatorCount { get; set; }

            
            public int NonUnitScaleBoneCount { get; set; }

            
            public string ErrorMessage { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        
        public static ResetResult ResetGameObjectPose(GameObject root)
        {
            var result = new ResetResult();
            if (root == null)
            {
                result.ErrorMessage = "root が null です。";
                return result;
            }

            Debug.Log($"[AvatarRecovery] PoseResetter 開始: {root.name}");

            try
            {
                
                root.transform.localPosition = Vector3.zero;
                root.transform.localRotation = Quaternion.identity;
                root.transform.localScale    = Vector3.one;

                
                ResetBindPoseFromSmrs(root, result);

                
                
                
                ResetHumanoidPoses(root, result);
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
                Debug.LogError($"[AvatarRecovery] PoseResetter 例外: {ex}");
            }

            Debug.Log(
                $"[AvatarRecovery] PoseResetter 完了: " +
                $"SMR={result.ProcessedSmrCount}, ボーン={result.ResetBoneCount}, " +
                $"Humanoid={result.HumanoidResetCount}, " +
                $"Generic={result.GenericAnimatorCount}" +
                (result.NonUnitScaleBoneCount > 0
                    ? $", 非単位スケール={result.NonUnitScaleBoneCount}"
                    : ""));

            return result;
        }

        
        
        
        public static ResetResult ResetPrefabPose(string prefabPath)
        {
            var result = new ResetResult();

            if (string.IsNullOrEmpty(prefabPath))
            {
                result.ErrorMessage = "prefabPath が空です。";
                return result;
            }

            var prefabRoot = PrefabUtility.LoadPrefabContents(prefabPath);
            if (prefabRoot == null)
            {
                result.ErrorMessage = $"Prefab を読み込めません: {prefabPath}";
                return result;
            }

            try
            {
                result = ResetGameObjectPose(prefabRoot);

                
                
                if (string.IsNullOrEmpty(result.ErrorMessage))
                {
                    PrefabUtility.SaveAsPrefabAsset(prefabRoot, prefabPath);
                    Debug.Log($"[AvatarRecovery] Prefab 保存完了: {prefabPath}");
                }
                else
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] PoseResetter エラーのため Prefab 上書きをスキップ: " +
                        $"{prefabPath} ({result.ErrorMessage})");
                }
            }
            catch (Exception ex)
            {
                result.ErrorMessage = ex.Message;
                Debug.LogError($"[AvatarRecovery] PoseResetter.ResetPrefabPose 例外: {ex}");
            }
            finally
            {
                PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return result;
        }

        #endregion

        #region 内部実装 - SMR bindposes ベースのリセット

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        private static void ResetBindPoseFromSmrs(GameObject root, ResetResult result)
        {
            var smrs = root.GetComponentsInChildren<SkinnedMeshRenderer>(includeInactive: true);
            if (smrs == null || smrs.Length == 0)
            {
                Debug.LogWarning("[AvatarRecovery] PoseResetter: SkinnedMeshRenderer が見つかりません。");
                return;
            }

            
            var processedBones = new HashSet<Transform>();

            
            var entries = new List<(int depth, SkinnedMeshRenderer smr, int boneIndex)>();

            foreach (var smr in smrs)
            {
                if (smr == null || smr.sharedMesh == null) continue;

                var bones = smr.bones;
                var bindposes = smr.sharedMesh.bindposes;

                if (bones == null || bindposes == null) continue;
                if (bones.Length == 0 || bindposes.Length == 0) continue;
                if (bones.Length != bindposes.Length) continue;

                result.ProcessedSmrCount++;

                for (int i = 0; i < bones.Length; i++)
                {
                    if (bones[i] == null) continue;
                    entries.Add((GetTransformDepth(bones[i]), smr, i));
                }
            }

            
            entries.Sort((a, b) => a.depth.CompareTo(b.depth));

            foreach (var entry in entries)
            {
                var smr  = entry.smr;
                var bone = smr.bones[entry.boneIndex];

                if (bone == null) continue;
                if (processedBones.Contains(bone)) continue;

                try
                {
                    var bindpose = smr.sharedMesh.bindposes[entry.boneIndex];

                    
                    
                    
                    var smrToWorld = smr.transform.localToWorldMatrix;
                    var boneMatrix = smrToWorld * bindpose.inverse;

                    
                    DecomposeTRS(boneMatrix, out var pos, out var rot, out var scale);

                    bone.position = pos;
                    bone.rotation = rot;

                    
                    
                    
                    
                    
                    var parent = bone.parent;
                    var parentScale = parent != null ? parent.lossyScale : Vector3.one;
                    bone.localScale = SafeDivide(scale, parentScale);

                    
                    if (Mathf.Abs(scale.x - 1f) > 0.001f ||
                        Mathf.Abs(scale.y - 1f) > 0.001f ||
                        Mathf.Abs(scale.z - 1f) > 0.001f)
                    {
                        result.NonUnitScaleBoneCount++;
                    }

                    processedBones.Add(bone);
                    result.ResetBoneCount++;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] ボーン '{bone.name}' のリセット失敗: {ex.Message}");
                }
            }
        }

        
        
        
        
        private static Vector3 SafeDivide(Vector3 a, Vector3 b)
        {
            return new Vector3(
                Mathf.Abs(b.x) < 1e-6f ? a.x : a.x / b.x,
                Mathf.Abs(b.y) < 1e-6f ? a.y : a.y / b.y,
                Mathf.Abs(b.z) < 1e-6f ? a.z : a.z / b.z);
        }

        
        private static int GetTransformDepth(Transform t)
        {
            int depth = 0;
            while (t != null && t.parent != null)
            {
                depth++;
                t = t.parent;
            }
            return depth;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        private static void DecomposeTRS(
            Matrix4x4 m, out Vector3 position, out Quaternion rotation, out Vector3 scale)
        {
            
            position = new Vector3(m.m03, m.m13, m.m23);

            
            Vector3 col0 = new Vector3(m.m00, m.m10, m.m20);
            Vector3 col1 = new Vector3(m.m01, m.m11, m.m21);
            Vector3 col2 = new Vector3(m.m02, m.m12, m.m22);

            scale = new Vector3(col0.magnitude, col1.magnitude, col2.magnitude);

            
            
            float det =
                m.m00 * (m.m11 * m.m22 - m.m12 * m.m21) -
                m.m01 * (m.m10 * m.m22 - m.m12 * m.m20) +
                m.m02 * (m.m10 * m.m21 - m.m11 * m.m20);
            if (det < 0) scale.x = -scale.x;

            
            
            if (Mathf.Abs(scale.x) < 1e-6f || Mathf.Abs(scale.y) < 1e-6f ||
                Mathf.Abs(scale.z) < 1e-6f)
            {
                rotation = Quaternion.identity;
                return;
            }

            
            Vector3 rotCol0 = col0 / scale.x;
            Vector3 rotCol1 = col1 / scale.y;
            Vector3 rotCol2 = col2 / scale.z;

            
            
            try
            {
                if (rotCol2.sqrMagnitude < 1e-6f || rotCol1.sqrMagnitude < 1e-6f)
                {
                    rotation = Quaternion.identity;
                    return;
                }
                rotation = Quaternion.LookRotation(rotCol2, rotCol1);
            }
            catch
            {
                rotation = Quaternion.identity;
            }
        }

        #endregion

        #region 内部実装 - HumanPoseHandler ベースの仕上げ

        
        
        
        
        
        private static void ResetHumanoidPoses(GameObject root, ResetResult result)
        {
            var animators = root.GetComponentsInChildren<Animator>(includeInactive: true);
            foreach (var animator in animators)
            {
                if (animator == null) continue;

                
                
                if (!animator.isHuman)
                {
                    result.GenericAnimatorCount++;
                    continue;
                }

                if (animator.avatar == null || !animator.avatar.isValid) continue;

                try
                {
                    using (var handler = new HumanPoseHandler(animator.avatar, animator.transform))
                    {
                        var pose = new HumanPose();
                        handler.GetHumanPose(ref pose);

                        pose.bodyRotation = Quaternion.identity;
                        if (pose.muscles != null)
                        {
                            for (int i = 0; i < pose.muscles.Length; i++)
                                pose.muscles[i] = 0f;
                        }

                        handler.SetHumanPose(ref pose);
                    }
                    result.HumanoidResetCount++;
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] HumanPoseHandler リセット失敗 ({animator.name}): " +
                        ex.Message);
                }
            }
        }

        #endregion
    }
}
