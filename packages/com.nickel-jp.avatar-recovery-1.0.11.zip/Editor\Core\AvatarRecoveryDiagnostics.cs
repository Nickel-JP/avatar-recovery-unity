



using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    public enum DiagnosticSeverity
    {
        Info = 0,
        Warning = 1,
        Critical = 2,
    }

    public enum DiagnosticCategory
    {
        SDK,
        Shader,
        Material,
        MissingScript,
        Dependency,
        Tool,
    }

    public sealed class AvatarRecoveryDiagnosticIssue
    {
        public DiagnosticSeverity Severity { get; set; }
        public DiagnosticCategory Category { get; set; }
        public string Target { get; set; }
        public string Symptom { get; set; }
        public string Cause { get; set; }
        public string Recommendation { get; set; }
    }

    public sealed class AvatarRecoveryDiagnosticReport
    {
        private readonly HashSet<string> _keys = new HashSet<string>(StringComparer.Ordinal);

        public string TargetName { get; set; }
        public string TargetPath { get; set; }
        public List<AvatarRecoveryDiagnosticIssue> Issues { get; } =
            new List<AvatarRecoveryDiagnosticIssue>();

        public int CriticalCount => CountSeverity(DiagnosticSeverity.Critical);
        public int WarningCount => CountSeverity(DiagnosticSeverity.Warning);
        public int InfoCount => CountSeverity(DiagnosticSeverity.Info);
        public bool HasCritical => CriticalCount > 0;

        public void AddIssue(
            DiagnosticSeverity severity,
            DiagnosticCategory category,
            string target,
            string symptom,
            string cause,
            string recommendation,
            string uniqueKey = null)
        {
            if (!string.IsNullOrEmpty(uniqueKey) && !_keys.Add(uniqueKey))
                return;

            Issues.Add(new AvatarRecoveryDiagnosticIssue
            {
                Severity = severity,
                Category = category,
                Target = target ?? string.Empty,
                Symptom = symptom ?? string.Empty,
                Cause = cause ?? string.Empty,
                Recommendation = recommendation ?? string.Empty,
            });
        }

        public void Merge(AvatarRecoveryDiagnosticReport other)
        {
            if (other == null) return;
            foreach (var issue in other.Issues)
            {
                var key = $"{issue.Severity}|{issue.Category}|{issue.Target}|{issue.Symptom}";
                AddIssue(issue.Severity, issue.Category, issue.Target, issue.Symptom,
                    issue.Cause, issue.Recommendation, key);
            }
        }

        public string ToDisplayText()
        {
            var sb = new StringBuilder();
            sb.AppendLine("AvatarRecovery 診断レポート");
            sb.AppendLine($"対象: {TargetName ?? "(未指定)"}");
            if (!string.IsNullOrEmpty(TargetPath))
                sb.AppendLine($"パス: {TargetPath}");
            sb.AppendLine($"Critical: {CriticalCount} / Warning: {WarningCount} / Info: {InfoCount}");
            sb.AppendLine();

            if (Issues.Count == 0)
            {
                sb.AppendLine("問題は見つかりませんでした。");
                return sb.ToString();
            }

            for (int i = 0; i < Issues.Count; i++)
            {
                var issue = Issues[i];
                sb.AppendLine($"[{i + 1}] {issue.Severity} / {issue.Category}");
                sb.AppendLine($"対象: {issue.Target}");
                sb.AppendLine($"症状: {issue.Symptom}");
                sb.AppendLine($"原因: {issue.Cause}");
                sb.AppendLine($"推奨: {issue.Recommendation}");
                sb.AppendLine();
            }
            return sb.ToString();
        }

        private int CountSeverity(DiagnosticSeverity severity)
        {
            var count = 0;
            foreach (var issue in Issues)
            {
                if (issue.Severity == severity)
                    count++;
            }
            return count;
        }
    }

    public sealed class AvatarRecoveryDiagnosticOptions
    {
        public bool CheckAvatarDescriptor { get; set; } = true;
        public bool CheckBlueprintId { get; set; } = true;
        public bool CheckMissingScripts { get; set; } = true;
        public bool CheckMaterials { get; set; } = true;
        public bool CheckShaderCompileErrors { get; set; } = true;
        public bool CheckPoiyomiAutoLock { get; set; } = true;
        public bool CheckKnownShaderIssues { get; set; } = true;

        public static AvatarRecoveryDiagnosticOptions Default =>
            new AvatarRecoveryDiagnosticOptions();
    }

    public static class AvatarRecoveryDiagnostics
    {
        private const string TypeVRCAvatarDescriptor =
            "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor";
        private const string TypePipelineManager = "VRC.Core.PipelineManager";
        private const string KnownDopeShaderName =
            "Doppels shaders/ScreenFX/Dope Shader 2.3.1";

        private static readonly BindingFlags StaticFlags =
            BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static;
        private static readonly TimeSpan EditorLogCacheDuration = TimeSpan.FromSeconds(10);
        private static List<string> _recentEditorLogLines;
        private static DateTime _recentEditorLogReadTimeUtc;

        [MenuItem("AvatarRecovery/アップロード前診断", priority = 40)]
        private static void MenuDiagnoseSelection()
        {
            var target = Selection.activeGameObject;
            if (target == null)
            {
                EditorUtility.DisplayDialog(
                    "アップロード前診断",
                    "Hierarchy で診断対象のアバター GameObject を選択してください。",
                    "OK");
                return;
            }

            var report = DiagnoseGameObject(target, target.name);
            Debug.Log(report.ToDisplayText());
            EditorUtility.DisplayDialog(
                "アップロード前診断",
                $"Critical: {report.CriticalCount}\nWarning: {report.WarningCount}\nInfo: {report.InfoCount}\n\n詳細は Console を確認してください。",
                "OK");
        }

        public static AvatarRecoveryDiagnosticReport DiagnoseGameObject(
            GameObject root,
            string targetName = null,
            AvatarRecoveryDiagnosticOptions options = null)
        {
            options ??= AvatarRecoveryDiagnosticOptions.Default;
            var report = new AvatarRecoveryDiagnosticReport
            {
                TargetName = targetName ?? (root != null ? root.name : "(null)"),
            };

            if (root == null)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Tool,
                    "(null)", "診断対象が null です。",
                    "選択対象または Prefab の読み込みに失敗しています。",
                    "対象を選び直してから再実行してください。");
                return report;
            }

            var components = root.GetComponentsInChildren<Component>(true);

            if (options.CheckAvatarDescriptor)
                CheckAvatarDescriptor(root, components, report);

            if (options.CheckBlueprintId)
                CheckPipelineManagers(root, components, report);

            if (options.CheckMissingScripts)
                CheckMissingScripts(root, report);

            if (options.CheckMaterials)
                CheckRendererMaterials(root, report, options);

            return report;
        }

        public static AvatarRecoveryDiagnosticReport DiagnosePrefabAsset(
            string prefabAssetPath,
            AvatarRecoveryDiagnosticOptions options = null)
        {
            options ??= AvatarRecoveryDiagnosticOptions.Default;
            var report = new AvatarRecoveryDiagnosticReport
            {
                TargetName = Path.GetFileNameWithoutExtension(prefabAssetPath),
                TargetPath = prefabAssetPath,
            };

            if (string.IsNullOrEmpty(prefabAssetPath) ||
                !prefabAssetPath.Replace('\\', '/').StartsWith("Assets/", StringComparison.Ordinal) ||
                !File.Exists(AssetPathToAbsolutePath(prefabAssetPath)))
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Tool,
                    prefabAssetPath, "Prefab アセットを読み込めません。",
                    "Assets/ 配下の有効な Prefab パスではありません。",
                    "Project ウィンドウ上の Prefab を指定してください。");
                return report;
            }

            GameObject prefabRoot = null;
            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(prefabAssetPath);
                if (prefabRoot == null)
                {
                    report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Tool,
                        prefabAssetPath, "Prefab のロードに失敗しました。",
                        "PrefabUtility.LoadPrefabContents が null を返しました。",
                        "Prefab が破損していないか確認してください。");
                    return report;
                }

                report.Merge(DiagnoseGameObject(prefabRoot, prefabRoot.name, options));
            }
            catch (Exception ex)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Tool,
                    prefabAssetPath, "Prefab 診断中に例外が発生しました。",
                    ex.Message,
                    "Console のスタックトレースを確認し、Prefab を開ける状態にしてください。");
                Debug.LogWarning($"[AvatarRecovery] Prefab 診断失敗 '{prefabAssetPath}': {ex}");
            }
            finally
            {
                if (prefabRoot != null)
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return report;
        }

        public static AvatarRecoveryDiagnosticReport DiagnoseFolder(
            string folderAssetPath,
            AvatarRecoveryDiagnosticOptions options = null)
        {
            options ??= AvatarRecoveryDiagnosticOptions.Default;
            var report = new AvatarRecoveryDiagnosticReport
            {
                TargetName = Path.GetFileName(folderAssetPath),
                TargetPath = folderAssetPath,
            };

            if (string.IsNullOrEmpty(folderAssetPath) ||
                !AssetDatabase.IsValidFolder(folderAssetPath))
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Tool,
                    folderAssetPath, "フォルダを診断できません。",
                    "Assets/ 配下の有効なフォルダではありません。",
                    "復元結果フォルダを指定してください。");
                return report;
            }

            var prefabGuids = AssetDatabase.FindAssets("t:Prefab", new[] { folderAssetPath });
            if (prefabGuids == null || prefabGuids.Length == 0)
            {
                report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.Tool,
                    folderAssetPath, "Prefab が見つかりません。",
                    "復元結果フォルダではない、または復元に失敗した可能性があります。",
                    "復元ログと出力先フォルダを確認してください。");
            }
            else
            {
                foreach (var guid in prefabGuids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    if (!string.IsNullOrEmpty(path))
                        report.Merge(DiagnosePrefabAsset(path, options));
                }
            }

            if (options.CheckMaterials)
                CheckLooseMaterialsInFolder(folderAssetPath, report, options);

            return report;
        }

        private static void CheckAvatarDescriptor(
            GameObject root,
            Component[] components,
            AvatarRecoveryDiagnosticReport report)
        {
            var descriptorPaths = new List<string>();
            foreach (var component in components)
            {
                if (component == null) continue;
                if (string.Equals(component.GetType().FullName, TypeVRCAvatarDescriptor,
                        StringComparison.Ordinal))
                {
                    descriptorPaths.Add(GetObjectPath(root, component.gameObject));
                }
            }

            if (descriptorPaths.Count == 0)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.SDK,
                    root.name, "VRC_AvatarDescriptor が見つかりません。",
                    "SDK はアップロード対象の Avatar Descriptor を検出できません。",
                    "復元 Prefab の root に VRC_AvatarDescriptor があるか確認してください。",
                    "descriptor:none:" + root.GetInstanceID());
            }
            else if (descriptorPaths.Count > 1)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.SDK,
                    FormatTargetList(descriptorPaths, 20),
                    $"VRC_AvatarDescriptor が {descriptorPaths.Count} 件あります。",
                    "SDK がアップロード対象を一意に決められない可能性があります。",
                    "アバター root 以外の不要な Descriptor を削除または無効化してください。",
                    "descriptor:multi:" + root.GetInstanceID());
            }
        }

        private static void CheckPipelineManagers(
            GameObject root,
            Component[] components,
            AvatarRecoveryDiagnosticReport report)
        {
            foreach (var component in components)
            {
                if (component == null) continue;
                if (!string.Equals(component.GetType().FullName, TypePipelineManager,
                        StringComparison.Ordinal))
                    continue;

                try
                {
                    using (var so = new SerializedObject(component))
                    {
                        var blueprint = so.FindProperty("blueprintId");
                        if (blueprint == null ||
                            blueprint.propertyType != SerializedPropertyType.String)
                            continue;

                        var value = blueprint.stringValue;
                        if (string.IsNullOrWhiteSpace(value)) continue;

                        var target = GetObjectPath(root, component.gameObject);
                        if (IsBlueprintId(value))
                        {
                            report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.SDK,
                                target, $"PipelineManager.blueprintId に {value} が残っています。",
                                "SDK が既存アップロード済みアバター/ワールドとして所有者チェックを行います。",
                                "新規アップロードする場合は blueprintId を空にしてください。",
                                "blueprint:" + value);
                        }
                        else
                        {
                            report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.SDK,
                                target, $"PipelineManager.blueprintId に不明な値があります: {value}",
                                "SDK の所有者チェックや予約処理が想定外になる可能性があります。",
                                "値の由来を確認し、新規アップロードなら空にしてください。",
                                "blueprint:unknown:" + value);
                        }
                    }
                }
                catch (Exception ex)
                {
                    report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.SDK,
                        component.gameObject.name, "PipelineManager の読み取りに失敗しました。",
                        ex.Message,
                        "SDK コンポーネントが壊れていないか確認してください。");
                }
            }
        }

        private static void CheckMissingScripts(
            GameObject root,
            AvatarRecoveryDiagnosticReport report)
        {
            var missing = 0;
            var targets = new List<string>();
            CollectMissingScripts(root, root.transform, targets, ref missing);
            if (missing <= 0) return;

            report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.MissingScript,
                FormatTargetList(targets, 30),
                $"Missing Script が {missing} 件残っています。",
                "復元時に MonoScript 参照を解決できなかったコンポーネントがあります。",
                "MissingScriptSearch タブで対象を確認し、不要なら削除してください。",
                "missing:" + root.GetInstanceID() + ":" + missing);
        }

        private static void CollectMissingScripts(
            GameObject root,
            Transform transform,
            List<string> targets,
            ref int count)
        {
            if (transform == null) return;
            var localCount = GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(transform.gameObject);
            if (localCount > 0)
            {
                count += localCount;
                targets.Add($"{GetObjectPath(root, transform.gameObject)} ({localCount})");
            }
            foreach (Transform child in transform)
                CollectMissingScripts(root, child, targets, ref count);
        }

        private static void CheckRendererMaterials(
            GameObject root,
            AvatarRecoveryDiagnosticReport report,
            AvatarRecoveryDiagnosticOptions options)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            var checkedMaterials = new HashSet<Material>();

            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    var material = materials[i];
                    var target = $"{GetObjectPath(root, renderer.gameObject)} / {renderer.GetType().Name}[{i}]";
                    CheckMaterial(material, target, report, options, checkedMaterials);
                }
            }
        }

        private static void CheckLooseMaterialsInFolder(
            string folderAssetPath,
            AvatarRecoveryDiagnosticReport report,
            AvatarRecoveryDiagnosticOptions options)
        {
            var checkedMaterials = new HashSet<Material>();
            var guids = AssetDatabase.FindAssets("t:Material", new[] { folderAssetPath });
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path)) continue;
                var material = AssetDatabase.LoadAssetAtPath<Material>(path);
                CheckMaterial(material, path, report, options, checkedMaterials);
            }
        }

        private static void CheckMaterial(
            Material material,
            string target,
            AvatarRecoveryDiagnosticReport report,
            AvatarRecoveryDiagnosticOptions options,
            HashSet<Material> checkedMaterials)
        {
            if (material == null)
            {
                report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.Material,
                    target, "Material スロットが null です。",
                    "Renderer の sharedMaterials に空スロットがあります。",
                    "不要なスロットなら削除し、必要なら Material を割り当ててください。",
                    "mat:null:" + target);
                return;
            }

            if (!checkedMaterials.Add(material))
                return;

            var materialPath = AssetDatabase.GetAssetPath(material);
            var materialTarget = string.IsNullOrEmpty(materialPath) ? material.name : materialPath;
            var shader = material.shader;

            if (shader == null)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Material,
                    materialTarget, "Material の shader が null です。",
                    "復元時に shader 参照を解決できていません。",
                    "_ShaderReport を確認して適切な shader を割り当ててください。",
                    "shader:null:" + material.GetInstanceID());
                return;
            }

            if (shader.name == "Hidden/InternalErrorShader")
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Shader,
                    materialTarget, "InternalErrorShader が割り当たっています。",
                    "Unity が元 shader を読み込めず、ピンク表示になる状態です。",
                    "_ShaderReport を確認して正しい shader を導入または再割り当てしてください。",
                    "shader:internal:" + material.GetInstanceID());
            }
            else if (!shader.isSupported)
            {
                report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.Shader,
                    materialTarget, $"shader が現在環境で unsupported です: {shader.name}",
                    "Unity バージョン、Render Pipeline、プラットフォームが shader の想定と合っていない可能性があります。",
                    "shader の配布元バージョンと現在の Unity/VRChat SDK 対応状況を確認してください。",
                    "shader:unsupported:" + shader.name);
            }

            if (options.CheckShaderCompileErrors)
                CheckShaderCompileError(shader, materialTarget, report);

            if (options.CheckKnownShaderIssues)
                CheckKnownShaderIssues(shader, materialTarget, report);

            if (options.CheckPoiyomiAutoLock)
                CheckPoiyomiAutoLock(material, shader, materialTarget, report);
        }

        private static void CheckShaderCompileError(
            Shader shader,
            string materialTarget,
            AvatarRecoveryDiagnosticReport report)
        {
            if (shader == null) return;

            var hasCurrentShaderError = ShaderHasError(shader);
            if (hasCurrentShaderError)
            {
                report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Shader,
                    materialTarget, $"shader compile error があります: {shader.name}",
                    "Unity の ShaderUtil が shader エラーを検出しています。",
                    "Console の shader error を確認し、shader 本体の更新または差し替えを検討してください。",
                    "shader:compile:" + shader.name);
            }

            foreach (var line in FindRecentEditorLogShaderErrors(shader.name))
            {
                report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.Shader,
                    materialTarget, line,
                    "Editor.log 由来の参考検出です。現在状態は ShaderUtil の結果を優先してください。",
                    "再ビルド後も同じ shader error が出る場合は、shader の更新または差し替えを検討してください。",
                    "shader:log:" + shader.name + ":" + line);
            }
        }

        private static void CheckKnownShaderIssues(
            Shader shader,
            string materialTarget,
            AvatarRecoveryDiagnosticReport report)
        {
            if (shader == null ||
                !string.Equals(shader.name, KnownDopeShaderName, StringComparison.Ordinal))
                return;

            if (!HasKnownDopeInstanceIdIssue(shader))
                return;

            report.AddIssue(DiagnosticSeverity.Critical, DiagnosticCategory.Shader,
                materialTarget,
                "Dope Shader 2.3.1 の既知エラー: invalid subscript 'instanceID' が発生する構造です。",
                "instancing を有効化している一方で、各 Pass の v2f に instance ID 受け渡しフィールドがありません。",
                "shader 配布元の更新版へ差し替えるか、承認後に Dope Shader 側の instancing マクロを修正してください。",
                "shader:known-dope-instanceid");
        }

        private static void CheckPoiyomiAutoLock(
            Material material,
            Shader shader,
            string materialTarget,
            AvatarRecoveryDiagnosticReport report)
        {
            if (material == null || shader == null) return;
            if (!IsThryOptimizerShader(shader) || IsLockedShader(shader)) return;

            report.AddIssue(DiagnosticSeverity.Warning, DiagnosticCategory.Material,
                materialTarget, "Poiyomi/ThryEditor の未ロック Material です。",
                "shader property からの推定検出です。SDK アップロード直前に auto-lock ダイアログが出る場合があります。",
                "これは通常エラーではありません。フリーズに見える場合は処理完了まで待つか、事前に Lock All を実行してください。",
                "poiyomi:unlock:" + material.GetInstanceID());
        }

        private static bool ShaderHasError(Shader shader)
        {
            try
            {
                var shaderUtil = Type.GetType("UnityEditor.ShaderUtil,UnityEditor");
                var method = shaderUtil?.GetMethod("ShaderHasError", StaticFlags, null,
                    new[] { typeof(Shader) }, null);
                if (method == null) return false;
                return Convert.ToBoolean(method.Invoke(null, new object[] { shader }));
            }
            catch
            {
                return false;
            }
        }

        private static IEnumerable<string> FindRecentEditorLogShaderErrors(string shaderName)
        {
            if (string.IsNullOrEmpty(shaderName))
                yield break;

            var logPath = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Unity", "Editor", "Editor.log");
            if (!File.Exists(logPath))
                yield break;

            var marker = $"Shader error in '{shaderName}'";
            var emitted = 0;
            foreach (var line in GetRecentEditorLogLines(logPath))
            {
                if (line.IndexOf(marker, StringComparison.OrdinalIgnoreCase) < 0)
                    continue;
                yield return line.Trim();
                emitted++;
                if (emitted >= 3)
                    yield break;
            }
        }

        private static List<string> GetRecentEditorLogLines(string logPath)
        {
            var now = DateTime.UtcNow;
            if (_recentEditorLogLines != null &&
                now - _recentEditorLogReadTimeUtc < EditorLogCacheDuration)
            {
                return _recentEditorLogLines;
            }

            const int maxLines = 2500;
            var queue = new Queue<string>(maxLines);
            try
            {
                foreach (var line in File.ReadLines(logPath))
                {
                    if (queue.Count >= maxLines)
                        queue.Dequeue();
                    queue.Enqueue(line);
                }
            }
            catch
            {
                _recentEditorLogLines = new List<string>();
                _recentEditorLogReadTimeUtc = now;
                return _recentEditorLogLines;
            }

            _recentEditorLogLines = new List<string>(queue);
            _recentEditorLogReadTimeUtc = now;
            return _recentEditorLogLines;
        }

        private static bool HasKnownDopeInstanceIdIssue(Shader shader)
        {
            var shaderAssetPath = AssetDatabase.GetAssetPath(shader);
            if (string.IsNullOrEmpty(shaderAssetPath)) return false;

            var shaderAbsPath = AssetPathToAbsolutePath(shaderAssetPath);
            if (!File.Exists(shaderAbsPath)) return false;

            try
            {
                var shaderText = File.ReadAllText(shaderAbsPath);
                if (shaderText.IndexOf("#pragma multi_compile_instancing",
                        StringComparison.Ordinal) < 0)
                    return false;

                var versionFolder = Directory.GetParent(Path.GetDirectoryName(shaderAbsPath) ?? string.Empty);
                var includesFolder = versionFolder == null
                    ? null
                    : Path.Combine(versionFolder.FullName, "Includes");
                if (string.IsNullOrEmpty(includesFolder) || !Directory.Exists(includesFolder))
                    return false;

                var passFiles = new[]
                {
                    "DopeBlurPass.cginc",
                    "DopeFogPass.cginc",
                    "DopeGlitchPass.cginc",
                    "DopeImagePass.cginc",
                    "DopeMainPass.cginc",
                };

                foreach (var fileName in passFiles)
                {
                    var path = Path.Combine(includesFolder, fileName);
                    if (!File.Exists(path)) continue;
                    var text = File.ReadAllText(path);
                    if (text.IndexOf("UNITY_TRANSFER_INSTANCE_ID(v, o)",
                            StringComparison.Ordinal) >= 0 &&
                        text.IndexOf("UNITY_VERTEX_INPUT_INSTANCE_ID",
                            StringComparison.Ordinal) < 0)
                    {
                        return true;
                    }
                }
            }
            catch
            {
                return false;
            }

            return false;
        }

        private static bool IsThryOptimizerShader(Shader shader)
        {
            try
            {
                return shader.FindPropertyIndex("shader_is_using_thry_editor") >= 0 &&
                       shader.FindPropertyIndex("_ShaderOptimizerEnabled") >= 0;
            }
            catch
            {
                return false;
            }
        }

        private static bool IsLockedShader(Shader shader)
        {
            return shader != null &&
                   shader.name.StartsWith("Hidden/Locked/", StringComparison.Ordinal);
        }

        private static bool IsBlueprintId(string value)
        {
            return value.StartsWith("avtr_", StringComparison.OrdinalIgnoreCase) ||
                   value.StartsWith("wrld_", StringComparison.OrdinalIgnoreCase) ||
                   value.StartsWith("prop_", StringComparison.OrdinalIgnoreCase);
        }

        private static string GetObjectPath(GameObject root, GameObject target)
        {
            if (root == null || target == null) return target != null ? target.name : "(null)";
            var stack = new Stack<string>();
            var current = target.transform;
            while (current != null)
            {
                stack.Push(current.name);
                if (current.gameObject == root) break;
                current = current.parent;
            }
            return string.Join("/", stack.ToArray());
        }

        private static string FormatTargetList(List<string> targets, int maxItems)
        {
            if (targets == null || targets.Count == 0)
                return "(対象なし)";

            var sb = new StringBuilder();
            var count = Mathf.Min(targets.Count, maxItems);
            for (int i = 0; i < count; i++)
            {
                if (i > 0) sb.AppendLine();
                sb.Append(targets[i]);
            }

            if (targets.Count > count)
                sb.AppendLine().Append($"...他 {targets.Count - count} 件");

            return sb.ToString();
        }

        private static string AssetPathToAbsolutePath(string assetPath)
        {
            var normalized = assetPath.Replace('\\', '/');
            var projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrEmpty(projectRoot)) return normalized;
            return Path.Combine(projectRoot, normalized).Replace('\\', '/');
        }
    }
}
