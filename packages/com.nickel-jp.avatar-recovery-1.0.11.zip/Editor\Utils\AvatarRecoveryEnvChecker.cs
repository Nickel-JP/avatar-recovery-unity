









using System;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    public static class AvatarRecoveryEnvChecker
    {
        #region 定数

        private const string ExpectedUnityVersion = "2022.3.22f1";
        private const string ExpectedSdkVersionPrefix = "3.10.";
        private const int    RecommendedVramMb = 7500;
        private const string LogTag = "[SARS]";
        private const string AvatarDescriptorTypeName = "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor";
        private const string BaseSdkPackageId = "com.vrchat.base";
        private const string AvatarSdkPackageId = "com.vrchat.avatars";
        private const string WorldsSdkPackageId = "com.vrchat.worlds";

        #endregion

        #region 公開 API

        
        
        
        public static void Run()
        {
            try
            {
                CheckUnityVersion();
                CheckVrcSdkPackageConsistency();
                CheckVrcAvatarSdk();
                CheckVram();
                CheckAssetRipper();
            }
            catch (Exception ex)
            {
                
                Debug.LogWarning($"{LogTag} EnvChecker 内部例外: {ex.Message}");
            }
        }

        #endregion

        #region [1] Unity バージョン

        private static void CheckUnityVersion()
        {
            if (Application.unityVersion != ExpectedUnityVersion)
            {
                Debug.LogWarning(
                    $"{LogTag} Unity version mismatch: expected {ExpectedUnityVersion}, " +
                    $"got {Application.unityVersion}");
            }
        }

        #endregion

        #region [2] VRC SDK パッケージ整合性

        private static void CheckVrcSdkPackageConsistency()
        {
            var hasBase = TryReadVpmPackageVersion(BaseSdkPackageId, out var baseVersion);
            var hasAvatars = TryReadVpmPackageVersion(AvatarSdkPackageId, out var avatarsVersion);
            var hasWorlds = TryReadVpmPackageVersion(WorldsSdkPackageId, out var worldsVersion);

            if (!hasBase)
            {
                Debug.LogWarning($"{LogTag} VRC SDK Base バージョンを取得できませんでした。");
                return;
            }

            if (hasAvatars)
                WarnIfSdkVersionsDiffer("Avatar SDK", avatarsVersion, "Base SDK", baseVersion);

            if (hasWorlds)
                WarnIfSdkVersionsDiffer("World SDK", worldsVersion, "Base SDK", baseVersion);
        }

        private static void WarnIfSdkVersionsDiffer(
            string sdkLabel,
            string sdkVersion,
            string baseLabel,
            string baseVersion)
        {
            if (string.Equals(sdkVersion, baseVersion, StringComparison.Ordinal))
                return;

            Debug.LogWarning(
                $"{LogTag} VRC SDK バージョン不整合を検出: {sdkLabel} {sdkVersion}, " +
                $"{baseLabel} {baseVersion}。VCC で同じバージョンへ揃えてから Unity を開き直してください。");
        }

        #endregion

        #region [3] VRC Avatar SDK バージョン

        private static void CheckVrcAvatarSdk()
        {
            var descType = FindType(AvatarDescriptorTypeName);

            if (descType == null || descType.Assembly == null)
            {
                if (TryReadVpmPackageVersion(WorldsSdkPackageId, out var worldsVersion))
                {
                    Debug.Log(
                        $"{LogTag} VRC World SDK {worldsVersion} 検出。Avatar SDK 専用チェックをスキップします。");
                    return;
                }

                Debug.LogWarning(
                    $"{LogTag} VRC Avatar SDK が見つかりません。Avatar 専用の後処理はスキップされます。");
                return;
            }

            
            if (!TryReadVpmPackageVersion(AvatarSdkPackageId, out var detectedVersion))
            {
                
                Debug.LogWarning($"{LogTag} VRC Avatar SDK バージョンを取得できませんでした");
                return;
            }

            
            if (!detectedVersion.StartsWith(ExpectedSdkVersionPrefix, StringComparison.Ordinal))
            {
                Debug.LogWarning(
                    $"{LogTag} VRC Avatar SDK {detectedVersion} 検出 " +
                    $"(動作検証は {ExpectedSdkVersionPrefix}x で実施)");

                EditorUtility.DisplayDialog(
                    "SARS バージョン警告",
                    $"VRC Avatar SDK {detectedVersion} を検出しました。\n" +
                    "本ツールは SDK 3.10.x で動作検証されています。\n" +
                    "一部機能が正常に動作しない可能性があります。",
                    "OK");
            }
            else
            {
                Debug.Log($"{LogTag} VRC Avatar SDK {detectedVersion} 検出 (OK)");
            }
        }

        private static Type FindType(string fullName)
        {
            try
            {
                foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                {
                    var type = asm.GetType(fullName, false);
                    if (type != null) return type;
                }
            }
            catch
            {
            }

            return null;
        }

        private static bool TryReadVpmPackageVersion(string packageId, out string version)
        {
            version = null;

            try
            {
                var manifestPath = Path.Combine(
                    Application.dataPath, "..", "Packages", "vpm-manifest.json");
                if (!File.Exists(manifestPath)) return false;

                var content = File.ReadAllText(manifestPath);
                var escapedPackageId = Regex.Escape(packageId);

                var match = Regex.Match(content,
                    $@"""{escapedPackageId}""\s*:\s*\{{\s*""version""\s*:\s*""(\d+\.\d+\.\d+)""",
                    RegexOptions.Singleline);
                if (!match.Success)
                {
                    match = Regex.Match(content,
                        $@"""{escapedPackageId}""\s*:\s*""(\d+\.\d+\.\d+)""");
                }

                if (!match.Success) return false;

                version = match.Groups[1].Value;
                return true;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"{LogTag} vpm-manifest.json 読取失敗: {ex.Message}");
                return false;
            }
        }

        #endregion

        #region [4] VRAM 簡易チェック

        private static void CheckVram()
        {
            int vram = SystemInfo.graphicsMemorySize;
            if (vram < RecommendedVramMb)
            {
                Debug.LogWarning(
                    $"{LogTag} VRAM {vram}MB 検出。" +
                    "推奨は 8GB 以上です。大きなアバターの抽出でメモリ不足が発生する可能性があります。");
            }
            else
            {
                Debug.Log($"{LogTag} VRAM {vram}MB 検出 (OK)");
            }
        }

        #endregion

        #region [5] AssetRipper.exe 検出チェック

        private static void CheckAssetRipper()
        {
            var path = AssetRipperBridge.FindAssetRipperExe();
            if (!string.IsNullOrEmpty(path))
            {
                Debug.Log($"{LogTag} AssetRipper.exe 検出: {path}");
            }
            else
            {
                Debug.LogWarning(
                    $"{LogTag} AssetRipper.exe が見つかりません。設定タブでパスを指定してください。");
            }
        }

        #endregion
    }
}
