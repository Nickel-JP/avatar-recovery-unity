









using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public static class ShaderGuidFixer
    {
        #region 定数

        
        private static readonly string[] ShaderFolderNames = { ".Shader", "Shader" };

        
        private static readonly string[] FallbackShaderNames =
        {
            ".poiyomi/Poiyomi Toon",
            "Poiyomi/Poiyomi Toon",
            ".poiyomi/Poiyomi Pro",
            "Poiyomi/Poiyomi Pro",
            "lilToon",
            "VRChat/Mobile/Toon Lit",
            "Standard",
        };

        private const string BuiltinShaderGuid = "0000000000000000f000000000000000";

        private static Dictionary<long, string> _builtinShaderNamesByFileId;

        #endregion

        #region 公開 DTO

        
        public class ShaderMapping
        {
            public string OldKey       { get; set; } 
            public string NewYaml      { get; set; } 
            public string OriginalName { get; set; } 
            public Shader ResolvedShader { get; set; }
            public bool   Seen          { get; set; }
            public int    ReplaceCount  { get; set; }
            public int    MaterialUseCount { get; set; }
        }

        
        public class MaterialShaderUsage
        {
            public string MaterialName { get; set; }
            public string MaterialRelativePath { get; set; }
            public long   ShaderFileId { get; set; }
            public string ShaderGuid { get; set; }
            public string OriginalShaderName { get; set; }
            public bool   Resolved { get; set; }
            public string Status { get; set; }
        }

        
        public class FixResult
        {
            public int MappingCount        { get; set; }
            public int FixedFileCount      { get; set; }
            public int FixedReferenceCount { get; set; }
            public List<string> UnresolvedShaders { get; set; } = new List<string>();
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        public static Dictionary<string, ShaderMapping> CollectShaderMappings(string targetFolder)
        {
            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder))
                return new Dictionary<string, ShaderMapping>();

            var shaderFolders = FindShaderFolders(targetFolder);
            return BuildMappingsFromShaderFolders(shaderFolders);
        }

        
        
        
        
        
        
        
        public static void ResolveMappingsPublic(
            Dictionary<string, ShaderMapping> mappings, FixResult result)
        {
            ResolveMappings(mappings, result);
        }

        
        
        
        
        public static List<MaterialShaderUsage> CollectMaterialShaderUsages(
            string targetFolder,
            Dictionary<string, ShaderMapping> mappings)
        {
            var usages = new List<MaterialShaderUsage>();

            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder))
                return usages;

            string[] materialPaths;
            try
            {
                materialPaths = Directory.GetFiles(
                    targetFolder, "*.mat", SearchOption.AllDirectories);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] .mat 列挙失敗: {ex.Message}");
                return usages;
            }

            Array.Sort(materialPaths, StringComparer.OrdinalIgnoreCase);

            foreach (var materialPath in materialPaths)
            {
                var usage = ReadMaterialShaderUsage(materialPath, targetFolder, mappings);
                if (usage != null)
                    usages.Add(usage);
            }

            return usages;
        }

        
        
        
        
        
        
        
        public static void ApplyMappings(
            string targetFolder,
            Dictionary<string, ShaderMapping> mappings,
            FixResult result)
        {
            if (mappings == null || mappings.Count == 0) return;
            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder)) return;

            var matPaths = Directory.GetFiles(targetFolder, "*.mat", SearchOption.AllDirectories);

            int fileCount = 0;
            int refCount  = 0;

            foreach (var path in matPaths)
            {
                var (modified, replaces) = FixMaterialFile(path, mappings);
                if (modified) { fileCount++; refCount += replaces; }
            }

            result.FixedFileCount      = fileCount;
            result.FixedReferenceCount = refCount;
        }

        
        
        
        
        
        
        
        public static FixResult FixFolder(string targetFolder)
        {
            var result = new FixResult();

            var mappings = CollectShaderMappings(targetFolder);
            if (mappings.Count == 0)
            {
                Debug.Log("[AvatarRecovery] FixShaders: ダミーシェーダーが見つかりません（処理スキップ）");
                return result;
            }

            result.MappingCount = mappings.Count;

            ResolveMappings(mappings, result);
            ApplyMappings(targetFolder, mappings, result);

            Debug.Log(
                $"[AvatarRecovery] FixShaders 完了: " +
                $"{result.FixedFileCount} ファイル / {result.FixedReferenceCount} 参照を修正 " +
                $"(マッピング: {mappings.Count}, 未解決: {result.UnresolvedShaders.Count})");

            return result;
        }

        
        public static void DeleteShaderFolders(string targetFolder)
        {
            var folders = FindShaderFolders(targetFolder);
            foreach (var folder in folders)
            {
                try
                {
                    Directory.Delete(folder, recursive: true);
                    var metaPath = folder + ".meta";
                    if (File.Exists(metaPath)) File.Delete(metaPath);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] シェーダーフォルダー削除失敗 '{folder}': {ex.Message}");
                }
            }
        }

        #endregion

        #region 内部実装 - フォルダー検索とマッピング構築

        private static List<string> FindShaderFolders(string targetFolder)
        {
            var result = new List<string>();
            try
            {
                foreach (var name in ShaderFolderNames)
                {
                    var found = Directory.GetDirectories(
                        targetFolder, name, SearchOption.AllDirectories);
                    result.AddRange(found.Select(p => p.Replace('\\', '/')));
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] シェーダーフォルダー検索エラー: {ex.Message}");
            }
            return result;
        }

        
        
        
        
        
        private static Dictionary<string, ShaderMapping> BuildMappingsFromShaderFolders(
            List<string> shaderFolders)
        {
            var mappings = new Dictionary<string, ShaderMapping>();

            foreach (var folder in shaderFolders)
            {
                string[] metaPaths;
                try
                {
                    metaPaths = Directory.GetFiles(folder, "*.shader.meta", SearchOption.AllDirectories)
                        .Select(p => p.Replace('\\', '/')).ToArray();
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[AvatarRecovery] .shader.meta 列挙失敗: {ex.Message}");
                    continue;
                }

                foreach (var metaPath in metaPaths)
                {
                    try
                    {
                        
                        const string metaExt = ".meta";
                        if (!metaPath.EndsWith(metaExt, StringComparison.OrdinalIgnoreCase))
                            continue;
                        var shaderPath = metaPath.Substring(0, metaPath.Length - metaExt.Length);
                        if (!File.Exists(shaderPath)) continue;

                        var stubGuid = ReadGuidFromMeta(metaPath);
                        if (string.IsNullOrEmpty(stubGuid)) continue;

                        var origName = ReadShaderNameFromShaderFile(shaderPath);
                        if (string.IsNullOrEmpty(origName)) continue;

                        
                        
                        
                        var oldKey = "guid: " + stubGuid;
                        if (mappings.ContainsKey(oldKey)) continue;

                        mappings[oldKey] = new ShaderMapping
                        {
                            OldKey       = oldKey,
                            OriginalName = origName,
                        };
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] シェーダー .meta 解析失敗 '{metaPath}': {ex.Message}");
                    }
                }
            }

            return mappings;
        }

        private static string ReadGuidFromMeta(string metaPath)
        {
            try
            {
                
                using (var reader = LongPathIO.OpenReader(metaPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("guid:", StringComparison.Ordinal))
                            return line.Substring(5).Trim();
                    }
                }
            }
            catch {  }
            return null;
        }

        
        private static MaterialShaderUsage ReadMaterialShaderUsage(
            string materialPath,
            string rootFolder,
            Dictionary<string, ShaderMapping> mappings)
        {
            var usage = new MaterialShaderUsage
            {
                MaterialName = Path.GetFileNameWithoutExtension(materialPath),
                MaterialRelativePath = GetRelativePath(rootFolder, materialPath),
                Status = "m_Shader が見つかりません",
            };

            try
            {
                using (var reader = LongPathIO.OpenReader(materialPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("  m_Name: ", StringComparison.Ordinal))
                        {
                            var name = ReadYamlScalar(line.Substring("  m_Name: ".Length));
                            if (!string.IsNullOrEmpty(name))
                                usage.MaterialName = name;
                        }

                        if (line.StartsWith("  m_Shader: ", StringComparison.Ordinal))
                        {
                            usage.ShaderFileId = ExtractFileIdFromLine(line);
                            usage.ShaderGuid = ExtractGuidFromLine(line);
                            if (string.IsNullOrEmpty(usage.ShaderGuid))
                            {
                                usage.Status = "m_Shader に GUID がありません";
                                continue;
                            }

                            if (IsBuiltinShaderGuid(usage.ShaderGuid))
                            {
                                var builtinName = ResolveBuiltinShaderName(usage.ShaderFileId);
                                if (!string.IsNullOrEmpty(builtinName))
                                {
                                    usage.OriginalShaderName = builtinName;
                                    usage.Resolved = true;
                                    usage.Status = "OK (Unity built-in shader)";
                                }
                                else
                                {
                                    usage.Status = $"Unity built-in shader の fileID を解決できません: {usage.ShaderFileId}";
                                }
                                continue;
                            }

                            var key = "guid: " + usage.ShaderGuid;
                            if (mappings != null &&
                                mappings.TryGetValue(key, out var mapping) &&
                                !string.IsNullOrEmpty(mapping.OriginalName))
                            {
                                usage.OriginalShaderName = mapping.OriginalName;
                                usage.Resolved = true;
                                usage.Status = "OK";
                                mapping.MaterialUseCount++;
                            }
                            else
                            {
                                usage.Status = "対応する .shader.meta が見つかりません";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                usage.Status = $"読取失敗: {ex.Message}";
            }

            return usage;
        }

        
        private static string GetRelativePath(string rootFolder, string path)
        {
            if (string.IsNullOrEmpty(rootFolder) || string.IsNullOrEmpty(path))
                return path;

            try
            {
                var root = Path.GetFullPath(rootFolder)
                    .TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                var full = Path.GetFullPath(path);
                if (full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                {
                    var relative = full.Substring(root.Length)
                        .TrimStart(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
                    return relative.Replace('\\', '/');
                }
            }
            catch
            {
                
            }

            return path.Replace('\\', '/');
        }

        
        private static string ReadYamlScalar(string value)
        {
            if (value == null) return null;

            var trimmed = value.Trim();
            if (trimmed.Length >= 2 &&
                trimmed[0] == '"' &&
                trimmed[trimmed.Length - 1] == '"')
            {
                trimmed = trimmed.Substring(1, trimmed.Length - 2)
                    .Replace("\\\"", "\"")
                    .Replace("\\\\", "\\");
            }

            return trimmed;
        }

        
        private static string ReadShaderNameFromShaderFile(string shaderPath)
        {
            try
            {
                
                using (var reader = LongPathIO.OpenReader(shaderPath))
                {
                    
                    for (int i = 0; i < 5; i++)
                    {
                        var line = reader.ReadLine();
                        if (line == null) break;

                        var idx = line.IndexOf("Shader \"", StringComparison.Ordinal);
                        if (idx >= 0)
                        {
                            int from = idx + "Shader \"".Length;
                            int to   = line.LastIndexOf("\"");
                            if (to > from) return line.Substring(from, to - from);
                        }
                    }
                }
            }
            catch {  }
            return null;
        }

        #endregion

        #region 内部実装 - シェーダー解決

        
        
        
        
        private static void ResolveMappings(
            Dictionary<string, ShaderMapping> mappings, FixResult result)
        {
            foreach (var mapping in mappings.Values)
            {
                var shader = FindBestProjectShader(mapping.OriginalName);
                if (shader == null)
                {
                    result.UnresolvedShaders.Add(mapping.OriginalName);
                    
                    continue;
                }

                mapping.ResolvedShader = shader;

                if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(
                        shader, out var newGuid, out long newFileID))
                {
                    mapping.NewYaml = $"{{fileID: {newFileID}, guid: {newGuid}, type: 3}}";
                }
                else
                {
                    result.UnresolvedShaders.Add(mapping.OriginalName);
                }
            }
        }

        
        
        
        
        
        
        
        
        
        public static Shader FindBestProjectShader(string originalName)
        {
            if (string.IsNullOrEmpty(originalName)) return FindFallback();

            
            var exact = Shader.Find(originalName);
            if (exact != null) return exact;

            
            var alternatives = new List<string>();
            if (originalName.StartsWith("."))
                alternatives.Add(originalName.Substring(1));
            else
                alternatives.Add("." + originalName);

            
            if (originalName.Contains("Poiyomi"))
            {
                alternatives.Add(".poiyomi/Poiyomi Toon");
                alternatives.Add("Poiyomi/Poiyomi Toon");
            }
            
            if (originalName.Contains("lil"))
            {
                alternatives.Add("lilToon");
            }

            foreach (var alt in alternatives)
            {
                var found = Shader.Find(alt);
                if (found != null) return found;
            }

            
            int lastSlash = originalName.LastIndexOf('/');
            if (lastSlash >= 0 && lastSlash < originalName.Length - 1)
            {
                var baseName = originalName.Substring(lastSlash + 1);
                var foundByBase = Shader.Find(baseName);
                if (foundByBase != null) return foundByBase;
            }

            
            return FindFallback();
        }

        private static Shader FindFallback()
        {
            foreach (var name in FallbackShaderNames)
            {
                var s = Shader.Find(name);
                if (s != null) return s;
            }
            return null;
        }

        #endregion

        #region 内部実装 - YAML テキスト置換

        
        
        
        
        
        
        
        private static (bool modified, int replaces) FixMaterialFile(
            string filePath, Dictionary<string, ShaderMapping> mappings)
        {
            int replaces = 0;
            var tempPath = filePath + ".avatar_recovery_tmp";

            try
            {
                
                using (var reader = LongPathIO.OpenReader(filePath))
                using (var writer = LongPathIO.OpenWriter(tempPath, append: false))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("  m_Shader: ", StringComparison.Ordinal) &&
                            line.Contains("guid:"))
                        {
                            var guid = ExtractGuidFromLine(line);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                var key = "guid: " + guid;
                                if (mappings.TryGetValue(key, out var mapping))
                                {
                                    mapping.Seen = true;
                                    if (!string.IsNullOrEmpty(mapping.NewYaml))
                                    {
                                        line = $"  m_Shader: {mapping.NewYaml}";
                                        mapping.ReplaceCount++;
                                        replaces++;
                                    }
                                }
                            }
                        }
                        writer.WriteLine(line);
                    }
                }

                if (replaces > 0)
                {
                    AtomicReplace(filePath, tempPath);
                    return (true, replaces);
                }
                else
                {
                    File.Delete(tempPath);
                    return (false, 0);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] FixMaterialFile 失敗 '{Path.GetFileName(filePath)}': {ex.Message}");
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
                return (false, 0);
            }
        }

        
        private static string ExtractGuidFromLine(string line)
        {
            try
            {
                int g = line.IndexOf("guid: ", StringComparison.Ordinal);
                if (g < 0) return null;
                int start = g + "guid: ".Length;
                int end   = line.IndexOf(',', start);
                if (end < 0) end = line.IndexOf('}', start);
                if (end < 0) return null;
                return line.Substring(start, end - start).Trim();
            }
            catch
            {
                return null;
            }
        }

        private static long ExtractFileIdFromLine(string line)
        {
            try
            {
                int f = line.IndexOf("fileID: ", StringComparison.Ordinal);
                if (f < 0) return 0;
                int start = f + "fileID: ".Length;
                int end = line.IndexOf(',', start);
                if (end < 0) end = line.IndexOf('}', start);
                if (end < 0) return 0;

                var raw = line.Substring(start, end - start).Trim();
                return long.TryParse(raw, out var fileId) ? fileId : 0;
            }
            catch
            {
                return 0;
            }
        }

        private static bool IsBuiltinShaderGuid(string guid)
        {
            return string.Equals(guid, BuiltinShaderGuid, StringComparison.OrdinalIgnoreCase);
        }

        private static string ResolveBuiltinShaderName(long fileId)
        {
            if (fileId == 0) return null;

            var knownName = ResolveKnownBuiltinShaderName(fileId);
            if (!string.IsNullOrEmpty(knownName))
                return knownName;

            var map = GetBuiltinShaderFileIdMap();
            return map.TryGetValue(fileId, out var shaderName) ? shaderName : null;
        }

        private static string ResolveKnownBuiltinShaderName(long fileId)
        {
            switch (fileId)
            {
                case 200:
                    return "Legacy Shaders/Particles/Additive";
                case 203:
                    return "Legacy Shaders/Particles/Alpha Blended";
                case 211:
                    return "Particles/Standard Unlit";
                default:
                    return null;
            }
        }

        private static Dictionary<long, string> GetBuiltinShaderFileIdMap()
        {
            if (_builtinShaderNamesByFileId != null)
                return _builtinShaderNamesByFileId;

            var map = new Dictionary<long, string>();
            AddKnownBuiltinShaderFileIds(map);

            try
            {
                foreach (var shaderName in CollectKnownProjectShaderNames())
                {
                    var shader = Shader.Find(shaderName);
                    if (shader == null) continue;

                    if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(
                            shader, out var guid, out long localFileId) &&
                        IsBuiltinShaderGuid(guid) &&
                        localFileId != 0 &&
                        !map.ContainsKey(localFileId))
                    {
                        map[localFileId] = shaderName;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] Unity built-in shader fileID 収集失敗: {ex.Message}");
            }

            _builtinShaderNamesByFileId = map;
            return _builtinShaderNamesByFileId;
        }

        private static void AddKnownBuiltinShaderFileIds(Dictionary<long, string> map)
        {
            long[] knownFileIds = { 200, 203, 211 };
            foreach (var fileId in knownFileIds)
            {
                var shaderName = ResolveKnownBuiltinShaderName(fileId);
                if (!string.IsNullOrEmpty(shaderName) && !map.ContainsKey(fileId))
                    map[fileId] = shaderName;
            }
        }

        private static SortedSet<string> CollectKnownProjectShaderNames()
        {
            var names = new SortedSet<string>(StringComparer.Ordinal);
            AddBuiltinShaderNameCandidates(names);

            var shaderUtil = typeof(ShaderUtil);
            var method = shaderUtil.GetMethod(
                "GetAllShaderInfo",
                System.Reflection.BindingFlags.Static |
                System.Reflection.BindingFlags.Public |
                System.Reflection.BindingFlags.NonPublic);

            if (method == null)
                return names;

            var shaderInfos = method.Invoke(null, null) as Array;
            if (shaderInfos == null)
                return names;

            foreach (var info in shaderInfos)
            {
                if (info == null) continue;

                var type = info.GetType();
                var nameProperty = type.GetProperty(
                    "name",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.NonPublic);
                var nameField = type.GetField(
                    "name",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.Public |
                    System.Reflection.BindingFlags.NonPublic);

                var value = nameProperty != null
                    ? nameProperty.GetValue(info, null)
                    : nameField?.GetValue(info);

                if (value is string shaderName && !string.IsNullOrEmpty(shaderName))
                    names.Add(shaderName);
            }

            return names;
        }

        private static void AddBuiltinShaderNameCandidates(SortedSet<string> names)
        {
            string[] candidates =
            {
                "Standard",
                "Diffuse",
                "VertexLit",
                "Particles/Additive",
                "Particles/Alpha Blended",
                "Particles/Multiply",
                "Particles/Standard Surface",
                "Particles/Standard Unlit",
                "Legacy Shaders/Particles/Additive",
                "Legacy Shaders/Particles/Alpha Blended",
                "Legacy Shaders/Particles/Multiply",
                "Legacy Shaders/Particles/VertexLit Blended",
                "Mobile/Particles/Additive",
                "Mobile/Particles/Alpha Blended",
                "Mobile/Particles/Multiply",
            };

            foreach (var candidate in candidates)
                names.Add(candidate);
        }

        
        
        
        
        
        
        
        private static void AtomicReplace(string targetPath, string tempPath)
        {
            if (!LongPathIO.TryAtomicReplace(tempPath, targetPath))
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] AtomicReplace 失敗: " +
                    $"temp='{Path.GetFileName(tempPath)}' → target='{Path.GetFileName(targetPath)}'。" +
                    "ファイルが別プロセスでロックされている可能性があります。");
            }
        }

        #endregion
    }
}
