



using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public sealed class AvatarDiagnosticsPanel
    {
        private AvatarRecoveryDiagnosticReport _report;
        private Vector2 _scroll;
        private string _lastFolder = "Assets/AvatarRecovery/Restored Avatar data";

        public void Draw(EditorWindow owner)
        {
            GUILayout.Label("アップロード前診断", Styles.SectionHeader);
            EditorGUILayout.HelpBox(
                "復元 Prefab / シーン上アバター / 復元フォルダを読み取り専用で診断します。\n" +
                "外部 shader や Material は自動修正しません。原因と推奨対応だけを表示します。",
                MessageType.Info);

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("選択中のアバターを診断", GUILayout.Height(26)))
                DiagnoseSelection(owner);

            if (GUILayout.Button("Prefab を選択して診断", GUILayout.Height(26)))
                DiagnosePrefab(owner);

            if (GUILayout.Button("復元フォルダを診断", GUILayout.Height(26)))
                DiagnoseFolder(owner);
            EditorGUILayout.EndHorizontal();

            using (new EditorGUI.DisabledScope(_report == null))
            {
                EditorGUILayout.BeginHorizontal();
                if (GUILayout.Button("Console に詳細出力", GUILayout.Height(22)))
                    Debug.Log(_report.ToDisplayText());

                if (GUILayout.Button("レポートを保存...", GUILayout.Height(22)))
                    SaveReport();
                EditorGUILayout.EndHorizontal();
            }

            GUILayout.Space(6);
            DrawReport();
        }

        private void DiagnoseSelection(EditorWindow owner)
        {
            var target = Selection.activeGameObject;
            if (target == null)
            {
                EditorUtility.DisplayDialog(
                    "アップロード前診断",
                    "Hierarchy で診断対象のアバター GameObject を選択してください。",
                    "OK");
                return;
            }

            _report = AvatarRecoveryDiagnostics.DiagnoseGameObject(target, target.name);
            owner?.Repaint();
        }

        private void DiagnosePrefab(EditorWindow owner)
        {
            var picked = EditorUtility.OpenFilePanel(
                "診断する Prefab を選択",
                Application.dataPath,
                "prefab");
            if (string.IsNullOrEmpty(picked)) return;

            var assetPath = AbsolutePathToAssetPath(picked);
            if (string.IsNullOrEmpty(assetPath))
            {
                EditorUtility.DisplayDialog(
                    "アップロード前診断",
                    "Assets/ 配下の Prefab を選択してください。",
                    "OK");
                return;
            }

            _report = AvatarRecoveryDiagnostics.DiagnosePrefabAsset(assetPath);
            owner?.Repaint();
        }

        private void DiagnoseFolder(EditorWindow owner)
        {
            var picked = EditorUtility.OpenFolderPanel(
                "診断する復元フォルダを選択",
                _lastFolder,
                string.Empty);
            if (string.IsNullOrEmpty(picked)) return;

            var assetPath = AbsolutePathToAssetPath(picked);
            if (string.IsNullOrEmpty(assetPath) || !AssetDatabase.IsValidFolder(assetPath))
            {
                EditorUtility.DisplayDialog(
                    "アップロード前診断",
                    "Assets/ 配下の有効なフォルダを選択してください。",
                    "OK");
                return;
            }

            _lastFolder = assetPath;
            _report = AvatarRecoveryDiagnostics.DiagnoseFolder(assetPath);
            owner?.Repaint();
        }

        private void DrawReport()
        {
            if (_report == null)
            {
                EditorGUILayout.HelpBox(
                    "まだ診断結果がありません。上のボタンから対象を診断してください。",
                    MessageType.None);
                return;
            }

            var messageType = _report.CriticalCount > 0
                ? MessageType.Error
                : _report.WarningCount > 0
                    ? MessageType.Warning
                    : MessageType.Info;
            EditorGUILayout.HelpBox(
                $"対象: {_report.TargetName}\n" +
                $"Critical: {_report.CriticalCount} / Warning: {_report.WarningCount} / Info: {_report.InfoCount}",
                messageType);

            if (_report.Issues.Count == 0)
            {
                EditorGUILayout.HelpBox("問題は見つかりませんでした。", MessageType.Info);
                return;
            }

            _scroll = EditorGUILayout.BeginScrollView(_scroll);
            foreach (var issue in _report.Issues)
                DrawIssue(issue);
            EditorGUILayout.EndScrollView();
        }

        private static void DrawIssue(AvatarRecoveryDiagnosticIssue issue)
        {
            var type = issue.Severity == DiagnosticSeverity.Critical
                ? MessageType.Error
                : issue.Severity == DiagnosticSeverity.Warning
                    ? MessageType.Warning
                    : MessageType.Info;

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.HelpBox($"{issue.Severity} / {issue.Category}", type);
            DrawLabel("対象", issue.Target);
            DrawLabel("症状", issue.Symptom);
            DrawLabel("原因", issue.Cause);
            DrawLabel("推奨", issue.Recommendation);
            EditorGUILayout.EndVertical();
            GUILayout.Space(4);
        }

        private static void DrawLabel(string label, string value)
        {
            EditorGUILayout.LabelField(label, EditorStyles.boldLabel);
            EditorGUILayout.LabelField(value ?? string.Empty, Styles.WrappedLabel);
        }

        private void SaveReport()
        {
            if (_report == null) return;

            var defaultName = $"AvatarRecovery_Diagnostics_{DateTime.Now:yyyyMMdd_HHmmss}.txt";
            var path = EditorUtility.SaveFilePanel(
                "診断レポートを保存",
                Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                defaultName,
                "txt");
            if (string.IsNullOrEmpty(path)) return;

            File.WriteAllText(path, _report.ToDisplayText());
            Debug.Log($"[AvatarRecovery] 診断レポートを保存: {path}");
        }

        private static string AbsolutePathToAssetPath(string path)
        {
            if (string.IsNullOrEmpty(path)) return null;

            var normalized = path.Replace('\\', '/').TrimEnd('/');
            if (normalized == "Assets" || normalized.StartsWith("Assets/", StringComparison.Ordinal))
                return normalized;

            var dataPath = Application.dataPath.Replace('\\', '/').TrimEnd('/');
            var projectRootInfo = Directory.GetParent(dataPath);
            var projectRoot = projectRootInfo != null
                ? projectRootInfo.FullName.Replace('\\', '/').TrimEnd('/')
                : null;
            if (string.IsNullOrEmpty(projectRoot)) return null;

            if (normalized.Equals(dataPath, StringComparison.OrdinalIgnoreCase))
                return "Assets";
            if (normalized.StartsWith(projectRoot + "/", StringComparison.OrdinalIgnoreCase))
                return normalized.Substring(projectRoot.Length + 1);

            return null;
        }
    }
}
