














using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public static class AssetRipperBridge
    {
        #region 定数

        
        
        
        
        
        private static readonly string[] DefaultSearchPaths =
        {
            
            @"%USERPROFILE%\Tools\AssetRipper\AssetRipper.exe",
            @"%USERPROFILE%\Downloads\AssetRipper\AssetRipper.exe",
            @"%USERPROFILE%\Desktop\AssetRipper\AssetRipper.exe",
            @"%LOCALAPPDATA%\AssetRipper\AssetRipper.exe",
            @"%PROGRAMFILES%\AssetRipper\AssetRipper.exe",
            @"%PROGRAMFILES(X86)%\AssetRipper\AssetRipper.exe",

            
            @"C:\Tools\AssetRipper\AssetRipper.exe",
            @"D:\Tools\AssetRipper\AssetRipper.exe",
            @"E:\Tools\AssetRipper\AssetRipper.exe",

            
            @"C:\Tools\ARC\Assets\AssetRipper\AssetRipper.exe",
        };

        
        
        
        
        
        
        private static readonly string[] ExportedAssetsPathCandidates =
        {
            "ExportedProject/Assets",
            "Assets",
            "Exported/Assets",
            "ExportedProject",
        };

        
        
        
        
        
        private static readonly HashSet<string> ExcludedFolders = new HashSet<string>(
            StringComparer.OrdinalIgnoreCase)
        {
            "Scripts",      
            ".Scripts",
            "Shader",       
            ".Shader",
            "Packages",
            "ProjectSettings",
        };

        
        private const int TimeoutMs = 120_000; 

        private const string RawPoseBackupFolderName = "RawPoseBackups";
        private const string PoseCandidateFolderName = "PoseResetCandidates";
        private const string LegacyRawPoseBackupFolderSuffix = "_RawPoseBackups";
        private const string LegacyPoseCandidateFolderSuffix = "_PoseResetCandidates";
        private const float PoseSafetyZeroScaleThreshold = 1e-6f;
        private const float PoseSafetyTinyScaleThreshold = 0.001f;
        private const float PoseSafetyExtremeScaleThreshold = 100f;
        private const float PoseSafetyMinBoundsDimension = 0.01f;
        private const float PoseSafetyBoundsGrowthRejectRatio = 8f;
        private const float PoseSafetyBoundsAbsoluteRejectSize = 20f;
        private const float PoseSafetyBoundsCenterRejectDistance = 20f;
        private const float PoseSafetyBoundsCenterRejectRatio = 10f;
        private const int PoseSafetyScaleCountRejectIncrease = 20;
        private const float PoseSafetyExtremeScaleCountRejectRatio = 1.25f;
        private const float PoseSafetyTinyScaleCountRejectRatio = 1.5f;

        #endregion

        #region 展開結果 DTO

        
        public class BridgeResult
        {
            
            public bool Success { get; set; }

            
            public string ErrorMessage { get; set; }

            
            public List<string> ImportedPaths { get; set; } = new List<string>();

            
            public string PrefabPath { get; set; }

            
            public ScriptGuidFixer.FixResult ScriptFixResult { get; set; }

            
            public ShaderGuidFixer.FixResult ShaderFixResult { get; set; }

            
            public int RemovedMissingScripts { get; set; }

            
            public int PoseResetCount { get; set; }

            
            public bool PoseResetApplied { get; set; }

            
            public bool PoseResetSkipped { get; set; }

            
            public string PoseResetSkipReason { get; set; }

            
            public string RawPrefabBackupPath { get; set; }

            
            public int GestureLayerMaskFixCount { get; set; }

            
            public string ShaderListOutputPath { get; set; }

            
            public int DetectedShaderCount { get; set; }

            
            public bool ShadersWereApplied { get; set; }

            
            
            
            
            public bool Cancelled { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        public static bool IsAvailable()
            => FindAssetRipperExe() != null;

        
        
        
        
        
        
        
        public static string FindAssetRipperExe()
        {
            
            var userPath = EditorPrefsHelper.LoadAssetRipperExePath();
            if (!string.IsNullOrEmpty(userPath))
            {
                var expanded = Environment.ExpandEnvironmentVariables(userPath);
                if (File.Exists(expanded)) return expanded;
            }

            
            foreach (var rawPath in DefaultSearchPaths)
            {
                try
                {
                    var expanded = Environment.ExpandEnvironmentVariables(rawPath);
                    if (File.Exists(expanded)) return expanded;
                }
                catch
                {
                    
                }
            }
            return null;
        }

        
        
        
        
        
        
        
        
        public static BridgeResult Extract(
            VrcaFileInfo info,
            string targetFolder,
            string exePath = null,
            MissingScriptDeletePolicy missingScriptPolicy = MissingScriptDeletePolicy.Always,
            bool autoReassignShaders = false)
        {
            
            var _sw_ = System.Diagnostics.Stopwatch.StartNew();
            try
            {
            
            var result = new BridgeResult();

            
            var exe = exePath ?? FindAssetRipperExe();
            if (exe == null)
            {
                result.ErrorMessage =
                    "AssetRipper.exe が見つかりません。\n" +
                    "以下のいずれかの方法で AssetRipper を配置してください:\n" +
                    "  ① 設定タブの「AssetRipper.exe パス」欄でファイルを直接指定\n" +
                    "  ② 以下のいずれかのデフォルトパスに配置:\n" +
                    "     - %USERPROFILE%\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                    "     - C:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                    "     - D:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                    "AssetRipper のダウンロード: https://assetripper.github.io/";
                return result;
            }

            if (info == null || !File.Exists(info.FilePath))
            {
                result.ErrorMessage = "入力ファイルが存在しません。";
                return result;
            }

            
            var tempDir = Path.Combine(
                Path.GetTempPath(),
                $"AvatarRecovery_{Guid.NewGuid():N}");

            try
            {
                Directory.CreateDirectory(tempDir);

                if (DisplayCancelableProgress(
                        "AssetRipper を実行中...", 0.2f, result)) return result;

                
                if (!RunAssetRipper(exe, info.FilePath, tempDir, out var stderr, out var cancelledByUser))
                {
                    if (cancelledByUser)
                    {
                        result.Cancelled   = true;
                        result.ErrorMessage = "ユーザーによりキャンセルされました (AssetRipper 実行中)";
                    }
                    else
                    {
                        result.ErrorMessage =
                            $"AssetRipper の実行に失敗しました。\n{stderr}";
                    }
                    return result;
                }

                
                
                
                var exportedAssets = FindExportedAssetsDir(tempDir);
                if (exportedAssets == null)
                {
                    var tree = DumpDirectoryTree(tempDir, maxDepth: 4);
                    UnityEngine.Debug.LogError(
                        $"[AvatarRecovery] AssetRipper 出力解析失敗 — 実際の出力構造:\n" +
                        $"<ROOT> {tempDir}\n{tree}");

                    result.ErrorMessage =
                        "AssetRipper の出力 Assets フォルダが見つかりません。\n" +
                        "AssetRipper のバージョンが古い/新しい可能性があります。\n" +
                        $"出力ディレクトリ: {tempDir}\n" +
                        "(詳細は Console の [AvatarRecovery] ログを参照)";
                    return result;
                }

                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] AssetRipper 出力 Assets を検出: {exportedAssets}");

                
                
                
                
                if (DisplayCancelableProgress(
                        "FixScripts: スクリプト参照を修正中...", 0.4f, result)) return result;

                var scriptFixResult = ScriptGuidFixer.FixFolder(exportedAssets);
                result.ScriptFixResult = scriptFixResult;

                
                
                
                
                
                
                if (DisplayCancelableProgress(
                        "FixShaders: 元シェーダー一覧を収集中...", 0.55f, result)) return result;

                var shaderMappings  = ShaderGuidFixer.CollectShaderMappings(exportedAssets);
                var shaderFixResult = new ShaderGuidFixer.FixResult
                {
                    MappingCount = shaderMappings.Count,
                };
                ShaderGuidFixer.ResolveMappingsPublic(shaderMappings, shaderFixResult);

                if (autoReassignShaders)
                {
                    if (DisplayCancelableProgress(
                            "FixShaders: マテリアルの m_Shader を書き換え中...", 0.6f, result)) return result;
                    ShaderGuidFixer.ApplyMappings(exportedAssets, shaderMappings, shaderFixResult);

                    UnityEngine.Debug.Log(
                        $"[AvatarRecovery] FixShaders (自動置換 ON): " +
                        $"{shaderFixResult.FixedFileCount} ファイル / " +
                        $"{shaderFixResult.FixedReferenceCount} 参照を修正");
                }
                else
                {
                    UnityEngine.Debug.Log(
                        $"[AvatarRecovery] FixShaders (自動置換 OFF): " +
                        $"{shaderMappings.Count} 件のシェーダーを検出 — " +
                        $"マテリアルは書き換えません。List of Shaders/Shaders.txt を参照してください。");
                }

                result.ShaderFixResult      = shaderFixResult;
                result.DetectedShaderCount  = shaderMappings.Count;
                result.ShadersWereApplied   = autoReassignShaders;

                
                
                
                
                
                ScriptGuidFixer.DeleteScriptFolders(exportedAssets);
                ShaderGuidFixer.DeleteShaderFolders(exportedAssets);

                if (DisplayCancelableProgress(
                        "アセットをインポート中...", 0.7f, result)) return result;

                
                EnsureUnityFolder(targetFolder);

                
                
                
                
                
                
                
                
                
                var guidConflicts = DetectGuidConflicts(exportedAssets, targetFolder);
                if (guidConflicts.Count > 0)
                {
                    result.ErrorMessage =
                        $"GUID衝突 {guidConflicts.Count} 件を検出したため、インポートを中止しました。\n" +
                        "既存アセットの参照破損を避けるため、詳細を Console で確認してください。";
                    UnityEngine.Debug.LogError("[SARS] " + result.ErrorMessage);
                    return result;
                }

                CleanStalePrefabsBeforeCopy(targetFolder);

                CopyExportedAssets(exportedAssets, targetFolder, result);

                AssetDatabase.Refresh();

                
                
                
                if (shaderMappings.Count > 0)
                {
                    if (DisplayCancelableProgress(
                            "List of Shaders を出力中...", 0.88f, result)) return result;

                    var listResult = ShaderListWriter.WriteList(
                        targetFolder,
                        shaderMappings,
                        info,
                        wasApplied: autoReassignShaders);

                    if (listResult.Success)
                        result.ShaderListOutputPath = listResult.OutputAssetPath;
                }

                if (DisplayCancelableProgress(
                        "Prefab を検索中...", 0.9f, result)) return result;

                
                result.PrefabPath = FindBestPrefabPath(targetFolder, info);

                
                
                
                
                if (!string.IsNullOrEmpty(result.PrefabPath))
                {
                    if (DisplayCancelableProgress(
                            "Blueprint ID をクリア中...", 0.92f, result)) return result;
                    ClearPipelineManagerBlueprintId(result.PrefabPath);
                }

                
                
                
                if (!string.IsNullOrEmpty(result.PrefabPath) &&
                    missingScriptPolicy == MissingScriptDeletePolicy.Always)
                {
                    if (DisplayCancelableProgress(
                            "Missing Script のクリーンアップ...", 0.93f, result)) return result;
                    var cleanResult = MissingScriptCleaner.CleanPrefabAsset(result.PrefabPath);
                    result.RemovedMissingScripts = cleanResult.RemovedScripts;
                }

                
                
                
                
                
                if (!string.IsNullOrEmpty(result.PrefabPath))
                {
                    if (DisplayCancelableProgress(
                            "ボーンリセット候補を安全判定中...", 0.97f, result)) return result;
                    TryApplyPoseResetterSafely(result.PrefabPath, targetFolder, result);
                }

                
                
                
                if (!string.IsNullOrEmpty(result.PrefabPath))
                {
                    if (DisplayCancelableProgress(
                            "Gesture Layer マスクを修正中...", 0.98f, result)) return result;
                    var gestureResult = GestureLayerMaskFixer.FixPrefab(result.PrefabPath, targetFolder);
                    if (gestureResult.Fixed)
                        result.GestureLayerMaskFixCount = 1;
                }

                
                
                
                
                if (!string.IsNullOrEmpty(result.PrefabPath))
                {
                    if (DisplayCancelableProgress(
                            "Prefab をリネーム中...", 0.99f, result)) return result;
                    var renamedPath = TryRenamePrefabToOriginalName(result.PrefabPath, info);
                    if (!string.IsNullOrEmpty(renamedPath))
                        result.PrefabPath = renamedPath;
                }

                result.Success = true;

                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] AssetRipper + SARS 展開完了:\n" +
                    $"  アセット数: {result.ImportedPaths.Count}\n" +
                    $"  FixScripts: {scriptFixResult.FixedFileCount} ファイル / " +
                    $"{scriptFixResult.FixedReferenceCount} 参照\n" +
                    $"  FixShaders: {(autoReassignShaders ? $"自動置換 ON — {shaderFixResult.FixedFileCount} ファイル / {shaderFixResult.FixedReferenceCount} 参照" : "自動置換 OFF (スキップ)")}\n" +
                    $"  検出シェーダー数: {result.DetectedShaderCount}\n" +
                    $"  シェーダー一覧: {result.ShaderListOutputPath ?? "(出力なし)"}\n" +
                    $"  Missing Script 削除: {result.RemovedMissingScripts}\n" +
                    $"  ボーン リセット: {FormatPoseResetSummary(result)}\n" +
                    $"  Raw Prefab バックアップ: {result.RawPrefabBackupPath ?? "(なし)"}\n" +
                    $"  Gesture Layer Mask 修正: {(result.GestureLayerMaskFixCount > 0 ? "実施" : "スキップ")}\n" +
                    $"  Prefab: {result.PrefabPath}");
            }
            catch (Exception ex)
            {
                result.ErrorMessage = $"AssetRipper 展開中にエラーが発生しました: {ex.Message}";
                UnityEngine.Debug.LogError($"[AvatarRecovery] AssetRipperBridge エラー: {ex}");
            }
            finally
            {
                
                
                TryDeleteDirectoryWithRetry(tempDir, maxAttempts: 5, delayMs: 200);

                EditorUtility.ClearProgressBar();
            }

            return result;
            
            }
            finally
            {
                
                _sw_.Stop();
                UnityEngine.Debug.Log(
                    $"[SARS][計測] AssetRipperBridge.Extract: {_sw_.ElapsedMilliseconds}ms " +
                    $"({info?.FileName ?? "(unknown)"})");
            }
        }

        #endregion

        #region 内部実装

        
        
        
        
        
        private static bool DisplayCancelableProgress(
            string message, float progress, BridgeResult result)
        {
            bool cancelled = EditorUtility.DisplayCancelableProgressBar(
                "AvatarRecovery (AssetRipper)", message, progress);
            if (cancelled)
            {
                result.Cancelled   = true;
                result.ErrorMessage = $"ユーザーによりキャンセルされました ({message})";
                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] ユーザーキャンセル検出: {message}");
            }
            return cancelled;
        }

        
        
        
        
        
        
        
        
        
        
        
        private static string FindExportedAssetsDir(string tempDir)
        {
            if (string.IsNullOrEmpty(tempDir) || !Directory.Exists(tempDir)) return null;

            
            foreach (var rel in ExportedAssetsPathCandidates)
            {
                var candidate = Path.Combine(tempDir,
                    rel.Replace('/', Path.DirectorySeparatorChar));
                if (Directory.Exists(candidate))
                    return candidate;
            }

            
            var found = SearchAssetsFolderRecursive(tempDir, maxDepth: 5);
            return found;
        }

        
        
        
        
        private static string SearchAssetsFolderRecursive(string root, int maxDepth)
        {
            var queue = new Queue<(string path, int depth)>();
            queue.Enqueue((root, 0));

            while (queue.Count > 0)
            {
                var (dir, depth) = queue.Dequeue();
                if (depth > maxDepth) continue;

                string[] subs;
                try { subs = Directory.GetDirectories(dir); }
                catch { continue; }

                
                foreach (var sub in subs)
                {
                    if (Path.GetFileName(sub).Equals("Assets", StringComparison.OrdinalIgnoreCase))
                        return sub;
                }

                
                foreach (var sub in subs)
                    queue.Enqueue((sub, depth + 1));
            }
            return null;
        }

        
        
        
        
        private static string DumpDirectoryTree(string root, int maxDepth)
        {
            var sb = new System.Text.StringBuilder();
            DumpDirectoryTreeRecursive(root, indent: "  ", depth: 0, maxDepth, sb);
            return sb.ToString();
        }

        private static void DumpDirectoryTreeRecursive(
            string dir, string indent, int depth, int maxDepth,
            System.Text.StringBuilder sb)
        {
            if (depth > maxDepth)
            {
                sb.AppendLine($"{indent}... (深さ {maxDepth} で省略)");
                return;
            }

            string[] subs;
            try { subs = Directory.GetDirectories(dir); }
            catch (Exception ex)
            {
                sb.AppendLine($"{indent}[読取エラー: {ex.Message}]");
                return;
            }

            foreach (var sub in subs)
            {
                sb.AppendLine($"{indent}[DIR] {Path.GetFileName(sub)}/");
                DumpDirectoryTreeRecursive(sub, indent + "  ", depth + 1, maxDepth, sb);
            }

            try
            {
                var files = Directory.GetFiles(dir);
                int shown = 0;
                foreach (var f in files)
                {
                    if (shown++ < 5)
                        sb.AppendLine($"{indent}{Path.GetFileName(f)}");
                    else
                    {
                        sb.AppendLine($"{indent}... (+{files.Length - 5} files)");
                        break;
                    }
                }
            }
            catch {  }
        }

        
        
        
        
        
        
        
        private static bool RunAssetRipper(
            string exePath,
            string inputPath,
            string outputDir,
            out string stderr,
            out bool cancelledByUser)
        {
            stderr = string.Empty;
            cancelledByUser = false;

            try
            {
                
                inputPath = Path.GetFullPath(inputPath);
                outputDir = Path.GetFullPath(outputDir);

                var psi = new ProcessStartInfo
                {
                    FileName               = exePath,
                    Arguments              = $"\"{inputPath}\" -o \"{outputDir}\"",
                    UseShellExecute        = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError  = true,
                    CreateNoWindow         = true,
                };

                using (var proc = Process.Start(psi))
                {
                    if (proc == null)
                    {
                        stderr = "プロセスを起動できませんでした。";
                        return false;
                    }

                    var stdoutTask = proc.StandardOutput.ReadToEndAsync();
                    var stderrTask = proc.StandardError.ReadToEndAsync();

                    
                    const int pollIntervalMs = 200;
                    int       elapsedMs      = 0;
                    bool      exited         = false;

                    while (elapsedMs < TimeoutMs)
                    {
                        if (proc.WaitForExit(pollIntervalMs))
                        {
                            exited = true;
                            break;
                        }
                        elapsedMs += pollIntervalMs;

                        
                        
                        float subProgress = Mathf.Min(0.4f,
                            0.2f + (float)elapsedMs / TimeoutMs * 0.2f);
                        bool cancelled = EditorUtility.DisplayCancelableProgressBar(
                            "AvatarRecovery (AssetRipper)",
                            $"AssetRipper 実行中... ({elapsedMs / 1000}s)",
                            subProgress);

                        if (cancelled)
                        {
                            
                            try { if (!proc.HasExited) proc.Kill(); } catch { }
                            cancelledByUser = true;
                            stderr = "ユーザーによりキャンセルされました";
                            UnityEngine.Debug.Log(
                                "[AvatarRecovery] AssetRipper をユーザーキャンセルで強制終了");
                            return false;
                        }
                    }

                    if (!exited)
                    {
                        try { if (!proc.HasExited) proc.Kill(); } catch { }
                        stderr = $"AssetRipper がタイムアウトしました（{TimeoutMs / 1000} 秒）。";
                        return false;
                    }

                    stderr = stderrTask.Result;
                    var stdout = stdoutTask.Result;

                    if (proc.ExitCode != 0)
                    {
                        stderr = $"終了コード {proc.ExitCode}\nstdout: {stdout}\nstderr: {stderr}";
                        return false;
                    }

                    UnityEngine.Debug.Log(
                        $"[AvatarRecovery] AssetRipper 完了 (exit={proc.ExitCode})\n{stdout}");
                    return true;
                }
            }
            catch (Exception ex)
            {
                stderr = ex.Message;
                return false;
            }
        }

        
        
        
        
        
        
        
        
        private static void CopyExportedAssets(
            string srcAssetsDir,
            string dstUnityFolder,
            BridgeResult result)
        {
            var dstAbsRoot = Path.GetFullPath(GetAbsolutePath(dstUnityFolder));

            var entries = Directory.GetFileSystemEntries(srcAssetsDir);
            foreach (var entry in entries)
            {
                var name = Path.GetFileName(entry);

                
                if (!IsSafeName(name)) continue;

                
                if (IsReparsePoint(entry))
                {
                    UnityEngine.Debug.LogWarning(
                        $"[AvatarRecovery] symlink/junction をスキップ: {entry}");
                    continue;
                }

                
                if (Directory.Exists(entry) && ExcludedFolders.Contains(name))
                {
                    UnityEngine.Debug.Log(
                        $"[AvatarRecovery] AssetRipper: フォルダーをスキップ: {name}");
                    continue;
                }

                if (Directory.Exists(entry))
                {
                    var dstSubDir = Path.Combine(dstAbsRoot, name);
                    if (!IsPathInside(dstSubDir, dstAbsRoot)) continue;
                    CopyDirectory(entry, dstSubDir, dstAbsRoot, result);
                }
                else
                {
                    
                    var dstFile = Path.Combine(dstAbsRoot, name);
                    if (!IsPathInside(dstFile, dstAbsRoot)) continue;
                    CopySingleFile(entry, dstFile, dstUnityFolder + "/" + name, result);
                }
            }
        }

        
        private static void CopyDirectory(
            string srcDir, string dstDir, string dstAbsRoot, BridgeResult result)
        {
            if (!Directory.Exists(dstDir))
                Directory.CreateDirectory(dstDir);

            foreach (var file in Directory.GetFiles(srcDir))
            {
                if (IsReparsePoint(file)) continue; 

                var fileName = Path.GetFileName(file);
                if (!IsSafeName(fileName)) continue;

                var dstFile = Path.Combine(dstDir, fileName);
                if (!IsPathInside(dstFile, dstAbsRoot)) continue; 

                var unityPath = GetUnityPath(dstFile);
                CopySingleFile(file, dstFile, unityPath, result);
            }

            foreach (var subDir in Directory.GetDirectories(srcDir))
            {
                if (IsReparsePoint(subDir)) continue; 

                var dirName = Path.GetFileName(subDir);
                if (!IsSafeName(dirName)) continue;

                var dstSubDir = Path.Combine(dstDir, dirName);
                if (!IsPathInside(dstSubDir, dstAbsRoot)) continue;

                CopyDirectory(subDir, dstSubDir, dstAbsRoot, result);
            }
        }

        
        
        
        private static bool IsSafeName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            if (name == "." || name == "..") return false;
            
            if (name.IndexOfAny(new[] { '\\', '/', ':' }) >= 0) return false;
            return true;
        }

        
        
        
        
        private static bool IsPathInside(string path, string root)
        {
            try
            {
                var fullPath = Path.GetFullPath(path);
                var fullRoot = Path.GetFullPath(root);
                if (!fullRoot.EndsWith(Path.DirectorySeparatorChar.ToString()))
                    fullRoot += Path.DirectorySeparatorChar;
                return fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase);
            }
            catch
            {
                return false;
            }
        }

        
        
        
        
        private static bool IsReparsePoint(string path)
        {
            try
            {
                var attrs = File.GetAttributes(path);
                return (attrs & FileAttributes.ReparsePoint) == FileAttributes.ReparsePoint;
            }
            catch
            {
                return false;
            }
        }

        
        
        
        
        private static void CopySingleFile(
            string srcFile, string dstFile, string unityPath, BridgeResult result)
        {
            try
            {
                var dir = Path.GetDirectoryName(dstFile);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    Directory.CreateDirectory(LongPath(dir));

                File.Copy(LongPath(srcFile), LongPath(dstFile), overwrite: true);
                result.ImportedPaths.Add(unityPath);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] ファイルコピー失敗 {Path.GetFileName(srcFile)}: {ex.Message}");
            }
        }

        
        
        
        
        private static string LongPath(string path)
        {
            if (string.IsNullOrEmpty(path)) return path;

            
            if (Path.DirectorySeparatorChar != '\\') return path;
            if (path.StartsWith(@"\\?\", StringComparison.Ordinal)) return path;
            if (path.StartsWith(@"\\", StringComparison.Ordinal))
                return @"\\?\UNC\" + path.Substring(2);

            
            if (path.Length < 248) return path;

            try
            {
                return @"\\?\" + Path.GetFullPath(path);
            }
            catch
            {
                return path;
            }
        }

        
        
        
        
        
        
        
        private static void EnsureUnityFolder(string unityPath)
        {
            if (string.IsNullOrEmpty(unityPath)) return;

            var parts = unityPath.Replace('\\', '/').Split('/');
            if (parts.Length == 0 || !string.Equals(parts[0], "Assets", StringComparison.Ordinal))
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] EnsureUnityFolder: Assets 相対パスではありません: {unityPath}");
                return;
            }

            var current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                if (string.IsNullOrEmpty(parts[i])) continue;
                var next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    var newGuid = AssetDatabase.CreateFolder(current, parts[i]);
                    if (string.IsNullOrEmpty(newGuid))
                    {
                        UnityEngine.Debug.LogWarning(
                            $"[AvatarRecovery] フォルダ作成失敗: {next} (親: {current})");
                        return;
                    }
                }
                current = next;
            }
        }

        
        private static string GetAbsolutePath(string unityPath)
        {
            
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(Path.Combine(projectRoot, unityPath.Replace('/', Path.DirectorySeparatorChar)));
        }

        
        private static string GetUnityPath(string absolutePath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath)
                              ?.Replace('\\', '/') ?? "";
            var normalized  = absolutePath.Replace('\\', '/');
            if (normalized.StartsWith(projectRoot))
                return normalized.Substring(projectRoot.Length).TrimStart('/');
            return absolutePath;
        }

        private sealed class PoseSafetySnapshot
        {
            public bool Success { get; set; }
            public string ErrorMessage { get; set; }
            public int TransformCount { get; set; }
            public int RendererCount { get; set; }
            public int SkinnedMeshRendererCount { get; set; }
            public int ZeroScaleTransformCount { get; set; }
            public int TinyScaleTransformCount { get; set; }
            public int ExtremeScaleTransformCount { get; set; }
            public int NonFiniteTransformCount { get; set; }
            public int NonFiniteRendererBoundsCount { get; set; }
            public float MaxAbsLocalScale { get; set; }
            public float MaxAbsWorldScale { get; set; }
            public bool HasCombinedRendererBounds { get; set; }
            public Bounds CombinedRendererBounds { get; set; }
            public float CombinedRendererBoundsMaxDimension { get; set; }
        }

        private static void TryApplyPoseResetterSafely(
            string prefabPath,
            string targetFolder,
            BridgeResult result)
        {
            if (string.IsNullOrEmpty(prefabPath) || result == null)
                return;

            var rawSnapshot = CapturePoseSafetySnapshot(prefabPath);
            if (!rawSnapshot.Success)
            {
                MarkPoseResetSkipped(
                    result,
                    $"Raw Prefab の安全判定に失敗: {rawSnapshot.ErrorMessage}");
                return;
            }

            var rawBackupPath = CreatePoseResetWorkingCopy(
                prefabPath, targetFolder, RawPoseBackupFolderName, "Raw");
            if (string.IsNullOrEmpty(rawBackupPath))
            {
                MarkPoseResetSkipped(
                    result,
                    "Raw Prefab バックアップを作成できないため PoseResetter をスキップ");
                return;
            }
            result.RawPrefabBackupPath = rawBackupPath;

            var candidatePath = CreatePoseResetWorkingCopy(
                prefabPath, targetFolder, PoseCandidateFolderName, "Candidate");
            if (string.IsNullOrEmpty(candidatePath))
            {
                MarkPoseResetSkipped(
                    result,
                    "PoseResetter 候補 Prefab を作成できないためスキップ");
                return;
            }

            try
            {
                var poseResult = PoseResetter.ResetPrefabPose(candidatePath);
                var candidateSnapshot = CapturePoseSafetySnapshot(candidatePath);

                if (!IsPoseResetCandidateSafe(
                        rawSnapshot, candidateSnapshot, poseResult, out var safetyMessage))
                {
                    MarkPoseResetSkipped(result, safetyMessage);
                    UnityEngine.Debug.LogWarning(
                        $"[AvatarRecovery] PoseResetter 候補を破棄しました: {candidatePath}\n" +
                        $"  理由: {safetyMessage}\n" +
                        $"  Raw: {FormatPoseSafetySnapshot(rawSnapshot)}\n" +
                        $"  Candidate: {FormatPoseSafetySnapshot(candidateSnapshot)}\n" +
                        $"  Raw Prefab: {rawBackupPath}");
                    return;
                }

                if (!ReplacePrefabAssetFile(candidatePath, prefabPath, out var replaceError))
                {
                    MarkPoseResetSkipped(
                        result,
                        $"PoseResetter 候補の採用に失敗: {replaceError}");
                    return;
                }

                result.PoseResetApplied = true;
                result.PoseResetSkipped = false;
                result.PoseResetSkipReason = null;
                result.PoseResetCount = poseResult != null ? poseResult.ResetBoneCount : 0;

                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] PoseResetter 候補を採用しました: {prefabPath}\n" +
                    $"  {safetyMessage}\n" +
                    $"  Raw Prefab: {rawBackupPath}");
            }
            finally
            {
                DeletePoseResetCandidate(candidatePath);
            }
        }

        private static PoseSafetySnapshot CapturePoseSafetySnapshot(string prefabPath)
        {
            var snapshot = new PoseSafetySnapshot();
            if (string.IsNullOrEmpty(prefabPath))
            {
                snapshot.ErrorMessage = "prefabPath が空です。";
                return snapshot;
            }

            GameObject prefabRoot = null;
            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(prefabPath);
                if (prefabRoot == null)
                {
                    snapshot.ErrorMessage = $"Prefab を読み込めません: {prefabPath}";
                    return snapshot;
                }

                CaptureTransformSafety(prefabRoot, snapshot);
                CaptureRendererSafety(prefabRoot, snapshot);
                snapshot.Success = true;
            }
            catch (Exception ex)
            {
                snapshot.ErrorMessage = ex.Message;
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] PoseResetter 安全判定スナップショット作成失敗 '{prefabPath}': {ex}");
            }
            finally
            {
                if (prefabRoot != null)
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return snapshot;
        }

        private static void CaptureTransformSafety(GameObject root, PoseSafetySnapshot snapshot)
        {
            var transforms = root.GetComponentsInChildren<Transform>(true);
            foreach (var transform in transforms)
            {
                if (transform == null) continue;

                snapshot.TransformCount++;

                var localScale = transform.localScale;
                var worldScale = transform.lossyScale;
                if (!IsFinite(localScale) || !IsFinite(worldScale))
                {
                    snapshot.NonFiniteTransformCount++;
                    continue;
                }

                var minAbsLocal = MinAbsComponent(localScale);
                var maxAbsLocal = MaxAbsComponent(localScale);
                var maxAbsWorld = MaxAbsComponent(worldScale);

                if (minAbsLocal < PoseSafetyZeroScaleThreshold)
                    snapshot.ZeroScaleTransformCount++;

                if (minAbsLocal < PoseSafetyTinyScaleThreshold)
                    snapshot.TinyScaleTransformCount++;

                if (maxAbsLocal > PoseSafetyExtremeScaleThreshold ||
                    maxAbsWorld > PoseSafetyExtremeScaleThreshold ||
                    (minAbsLocal > PoseSafetyZeroScaleThreshold &&
                     minAbsLocal < PoseSafetyZeroScaleThreshold * 100f))
                {
                    snapshot.ExtremeScaleTransformCount++;
                }

                if (maxAbsLocal > snapshot.MaxAbsLocalScale)
                    snapshot.MaxAbsLocalScale = maxAbsLocal;
                if (maxAbsWorld > snapshot.MaxAbsWorldScale)
                    snapshot.MaxAbsWorldScale = maxAbsWorld;
            }
        }

        private static void CaptureRendererSafety(GameObject root, PoseSafetySnapshot snapshot)
        {
            var renderers = root.GetComponentsInChildren<Renderer>(true);
            foreach (var renderer in renderers)
            {
                if (renderer == null) continue;

                snapshot.RendererCount++;
                if (renderer is SkinnedMeshRenderer)
                    snapshot.SkinnedMeshRendererCount++;

                try
                {
                    var bounds = renderer.bounds;
                    if (!IsFinite(bounds.center) || !IsFinite(bounds.size))
                    {
                        snapshot.NonFiniteRendererBoundsCount++;
                        continue;
                    }

                    if (!snapshot.HasCombinedRendererBounds)
                    {
                        snapshot.CombinedRendererBounds = bounds;
                        snapshot.HasCombinedRendererBounds = true;
                    }
                    else
                    {
                        snapshot.CombinedRendererBounds.Encapsulate(bounds);
                    }
                }
                catch
                {
                    snapshot.NonFiniteRendererBoundsCount++;
                }
            }

            if (snapshot.HasCombinedRendererBounds)
            {
                var size = snapshot.CombinedRendererBounds.size;
                snapshot.CombinedRendererBoundsMaxDimension =
                    Mathf.Max(size.x, Mathf.Max(size.y, size.z));
            }
        }

        private static bool IsPoseResetCandidateSafe(
            PoseSafetySnapshot raw,
            PoseSafetySnapshot candidate,
            PoseResetter.ResetResult poseResult,
            out string message)
        {
            var reasons = new List<string>();

            if (raw == null || !raw.Success)
                reasons.Add("Raw Prefab の安全判定情報がありません");

            if (candidate == null || !candidate.Success)
            {
                reasons.Add(
                    $"候補 Prefab の安全判定に失敗: {candidate?.ErrorMessage ?? "(不明)"}");
            }

            if (poseResult != null && !string.IsNullOrEmpty(poseResult.ErrorMessage))
                reasons.Add($"PoseResetter がエラーを返しました: {poseResult.ErrorMessage}");

            if (raw == null || candidate == null || !raw.Success || !candidate.Success)
            {
                message = string.Join(" / ", reasons.ToArray());
                return false;
            }

            if (candidate.NonFiniteTransformCount > raw.NonFiniteTransformCount)
            {
                reasons.Add(
                    $"非有限Transformが増加 ({raw.NonFiniteTransformCount}→{candidate.NonFiniteTransformCount})");
            }

            if (candidate.NonFiniteRendererBoundsCount > raw.NonFiniteRendererBoundsCount)
            {
                reasons.Add(
                    $"非有限Renderer Boundsが増加 ({raw.NonFiniteRendererBoundsCount}→{candidate.NonFiniteRendererBoundsCount})");
            }

            if (candidate.ZeroScaleTransformCount > raw.ZeroScaleTransformCount)
            {
                reasons.Add(
                    $"0 scale Transformが増加 ({raw.ZeroScaleTransformCount}→{candidate.ZeroScaleTransformCount})");
            }

            if (raw.HasCombinedRendererBounds && candidate.HasCombinedRendererBounds)
            {
                var rawMax = Mathf.Max(
                    raw.CombinedRendererBoundsMaxDimension,
                    PoseSafetyMinBoundsDimension);
                var candidateMax = candidate.CombinedRendererBoundsMaxDimension;

                if (candidateMax > rawMax * PoseSafetyBoundsGrowthRejectRatio &&
                    candidateMax > PoseSafetyBoundsAbsoluteRejectSize)
                {
                    reasons.Add(
                        $"Renderer Boundsが異常拡大 ({rawMax:0.###}→{candidateMax:0.###})");
                }

                var centerDistance = Vector3.Distance(
                    raw.CombinedRendererBounds.center,
                    candidate.CombinedRendererBounds.center);
                var centerLimit = Mathf.Max(
                    PoseSafetyBoundsCenterRejectDistance,
                    rawMax * PoseSafetyBoundsCenterRejectRatio);
                if (centerDistance > centerLimit)
                {
                    reasons.Add(
                        $"Renderer Bounds中心が大きく移動 ({centerDistance:0.###} > {centerLimit:0.###})");
                }
            }

            if (candidate.ExtremeScaleTransformCount >=
                    raw.ExtremeScaleTransformCount + PoseSafetyScaleCountRejectIncrease &&
                candidate.ExtremeScaleTransformCount >
                    raw.ExtremeScaleTransformCount * PoseSafetyExtremeScaleCountRejectRatio)
            {
                reasons.Add(
                    $"極端scale Transformが増加 ({raw.ExtremeScaleTransformCount}→{candidate.ExtremeScaleTransformCount})");
            }

            if (candidate.TinyScaleTransformCount >=
                    raw.TinyScaleTransformCount + PoseSafetyScaleCountRejectIncrease &&
                candidate.TinyScaleTransformCount >
                    raw.TinyScaleTransformCount * PoseSafetyTinyScaleCountRejectRatio)
            {
                reasons.Add(
                    $"微小scale Transformが増加 ({raw.TinyScaleTransformCount}→{candidate.TinyScaleTransformCount})");
            }

            if (reasons.Count > 0)
            {
                message = string.Join(" / ", reasons.ToArray());
                return false;
            }

            message =
                $"安全判定OK: {FormatPoseSafetySnapshot(raw)} → {FormatPoseSafetySnapshot(candidate)}";
            return true;
        }

        private static string CreatePoseResetWorkingCopy(
            string prefabPath,
            string targetFolder,
            string folderName,
            string fileSuffix)
        {
            try
            {
                var folder = BuildPoseResetWorkingFolder(targetFolder, folderName);
                EnsureUnityFolder(folder);
                if (!AssetDatabase.IsValidFolder(folder))
                    return null;

                var baseName = SanitizeFileNameForUnity(
                    Path.GetFileNameWithoutExtension(prefabPath));
                if (string.IsNullOrEmpty(baseName))
                    baseName = "Prefab";

                var path = AssetDatabase.GenerateUniqueAssetPath(
                    $"{folder}/{baseName}_{fileSuffix}.prefab");
                if (!AssetDatabase.CopyAsset(prefabPath, path))
                    return null;

                AssetDatabase.ImportAsset(
                    path,
                    ImportAssetOptions.ForceSynchronousImport |
                    ImportAssetOptions.ForceUpdate);
                return path;
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] PoseResetter 作業コピー作成失敗 '{prefabPath}': {ex.Message}");
                return null;
            }
        }

        private static string BuildPoseResetWorkingFolder(string targetFolder, string folderName)
        {
            var normalized = (targetFolder ?? string.Empty)
                .Replace('\\', '/')
                .TrimEnd('/');
            if (string.IsNullOrEmpty(normalized))
                return $"Assets/AvatarRecovery/{folderName}";

            return $"{normalized}/{folderName}";
        }

        private static bool ReplacePrefabAssetFile(
            string sourcePrefabPath,
            string destinationPrefabPath,
            out string error)
        {
            error = null;
            try
            {
                var sourceAbs = GetAbsolutePath(sourcePrefabPath);
                var destinationAbs = GetAbsolutePath(destinationPrefabPath);
                if (!File.Exists(sourceAbs))
                {
                    error = $"候補ファイルが存在しません: {sourcePrefabPath}";
                    return false;
                }

                File.Copy(
                    LongPath(sourceAbs),
                    LongPath(destinationAbs),
                    overwrite: true);
                AssetDatabase.ImportAsset(
                    destinationPrefabPath,
                    ImportAssetOptions.ForceSynchronousImport |
                    ImportAssetOptions.ForceUpdate);
                AssetDatabase.SaveAssets();
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private static void DeletePoseResetCandidate(string candidatePath)
        {
            if (string.IsNullOrEmpty(candidatePath)) return;
            var candidateFolder = (Path.GetDirectoryName(candidatePath) ?? string.Empty)
                .Replace('\\', '/')
                .TrimEnd('/');

            try
            {
                AssetDatabase.DeleteAsset(candidatePath);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] PoseResetter 候補 Prefab の削除失敗 '{candidatePath}': {ex.Message}");
            }

            DeleteEmptyPoseResetCandidateFolder(candidateFolder);
        }

        private static void DeleteEmptyPoseResetCandidateFolder(string candidateFolder)
        {
            if (string.IsNullOrEmpty(candidateFolder) ||
                !IsPoseResetCandidateFolder(candidateFolder) ||
                !AssetDatabase.IsValidFolder(candidateFolder))
                return;

            try
            {
                var candidateFolderAbs = GetAbsolutePath(candidateFolder);
                if (!Directory.Exists(candidateFolderAbs))
                    return;

                using (var entries = Directory.EnumerateFileSystemEntries(candidateFolderAbs).GetEnumerator())
                {
                    if (entries.MoveNext())
                        return;
                }

                AssetDatabase.DeleteAsset(candidateFolder);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] 空の PoseResetter 候補フォルダ削除失敗 '{candidateFolder}': {ex.Message}");
            }
        }

        private static bool IsPoseResetCandidateFolder(string folderPath)
        {
            if (string.IsNullOrEmpty(folderPath))
                return false;

            var folderName = Path.GetFileName(folderPath.Replace('\\', '/').TrimEnd('/'));
            return string.Equals(folderName, PoseCandidateFolderName, StringComparison.OrdinalIgnoreCase) ||
                   string.Equals(folderName, LegacyPoseCandidateFolderSuffix, StringComparison.OrdinalIgnoreCase);
        }

        private static void MarkPoseResetSkipped(BridgeResult result, string reason)
        {
            if (result == null) return;

            result.PoseResetApplied = false;
            result.PoseResetSkipped = true;
            result.PoseResetCount = 0;
            result.PoseResetSkipReason = string.IsNullOrEmpty(reason)
                ? "安全判定によりスキップ"
                : reason;
        }

        private static string FormatPoseResetSummary(BridgeResult result)
        {
            if (result == null)
                return "(結果なし)";

            if (result.PoseResetApplied)
                return $"{result.PoseResetCount} 個 (安全判定OK)";

            if (result.PoseResetSkipped)
                return $"スキップ ({result.PoseResetSkipReason})";

            return $"{result.PoseResetCount} 個";
        }

        private static string FormatPoseSafetySnapshot(PoseSafetySnapshot snapshot)
        {
            if (snapshot == null)
                return "(null)";

            if (!snapshot.Success)
                return $"取得失敗: {snapshot.ErrorMessage}";

            var bounds = snapshot.HasCombinedRendererBounds
                ? snapshot.CombinedRendererBoundsMaxDimension.ToString("0.###")
                : "(なし)";

            return
                $"BoundsMax={bounds}, " +
                $"Renderer={snapshot.RendererCount}, SMR={snapshot.SkinnedMeshRendererCount}, " +
                $"ZeroScale={snapshot.ZeroScaleTransformCount}, " +
                $"TinyScale={snapshot.TinyScaleTransformCount}, " +
                $"ExtremeScale={snapshot.ExtremeScaleTransformCount}, " +
                $"MaxLocalScale={snapshot.MaxAbsLocalScale:0.###}, " +
                $"MaxWorldScale={snapshot.MaxAbsWorldScale:0.###}";
        }

        private static bool IsFinite(Vector3 value)
        {
            return IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z);
        }

        private static bool IsFinite(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        private static float MaxAbsComponent(Vector3 value)
        {
            return Mathf.Max(
                Mathf.Abs(value.x),
                Mathf.Max(Mathf.Abs(value.y), Mathf.Abs(value.z)));
        }

        private static float MinAbsComponent(Vector3 value)
        {
            return Mathf.Min(
                Mathf.Abs(value.x),
                Mathf.Min(Mathf.Abs(value.y), Mathf.Abs(value.z)));
        }

        
        
        
        private static string FindBestPrefabPath(string targetFolder, VrcaFileInfo info)
        {
            if (string.IsNullOrEmpty(targetFolder)) return null;

            var prefabPaths = FindPrefabCandidatePaths(targetFolder);
            if (prefabPaths.Count == 0) return null;

            string bestPath = null;
            var bestScore = int.MinValue;

            foreach (var path in prefabPaths)
            {
                if (string.IsNullOrEmpty(path)) continue;

                var score = ScorePrefabCandidate(path, targetFolder, info);
                if (score > bestScore)
                {
                    bestScore = score;
                    bestPath = path;
                }
            }

            if (prefabPaths.Count > 1 && !string.IsNullOrEmpty(bestPath))
            {
                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] メイン Prefab 候補を選定: {bestPath} " +
                    $"(候補 {prefabPaths.Count} 件, score={bestScore})");
            }

            return bestPath;
        }

        private static List<string> FindPrefabCandidatePaths(string targetFolder)
        {
            var paths = new List<string>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            var prefabGuids = AssetDatabase.FindAssets("t:Prefab", new[] { targetFolder });
            if (prefabGuids != null)
            {
                foreach (var guid in prefabGuids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    if (!string.IsNullOrEmpty(path) &&
                        !IsPoseResetWorkingAssetPath(path) &&
                        seen.Add(path))
                    {
                        paths.Add(path);
                    }
                }
            }

            try
            {
                var absoluteTarget = GetAbsolutePath(targetFolder);
                if (!Directory.Exists(absoluteTarget))
                    return paths;

                var prefabFiles = Directory.GetFiles(
                    absoluteTarget,
                    "*.prefab",
                    SearchOption.AllDirectories);
                foreach (var prefabFile in prefabFiles)
                {
                    var unityPath = GetUnityPath(prefabFile).Replace('\\', '/');
                    if (string.IsNullOrEmpty(unityPath) ||
                        IsPoseResetWorkingAssetPath(unityPath) ||
                        !seen.Add(unityPath))
                    {
                        continue;
                    }

                    AssetDatabase.ImportAsset(
                        unityPath,
                        ImportAssetOptions.ForceSynchronousImport |
                        ImportAssetOptions.ForceUpdate);
                    paths.Add(unityPath);
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] Prefab ファイルシステム検索失敗 '{targetFolder}': {ex.Message}");
            }

            return paths;
        }

        private static bool IsPoseResetWorkingAssetPath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return false;

            var normalized = assetPath.Replace('\\', '/');
            return HasAssetPathSegment(normalized, RawPoseBackupFolderName) ||
                   HasAssetPathSegment(normalized, PoseCandidateFolderName) ||
                   HasAssetPathSegment(normalized, LegacyRawPoseBackupFolderSuffix) ||
                   HasAssetPathSegment(normalized, LegacyPoseCandidateFolderSuffix);
        }

        private static bool HasAssetPathSegment(string assetPath, string segment)
        {
            if (string.IsNullOrEmpty(assetPath) || string.IsNullOrEmpty(segment))
                return false;

            var normalized = assetPath.Replace('\\', '/').Trim('/');
            var parts = normalized.Split('/');
            foreach (var part in parts)
            {
                if (string.Equals(part, segment, StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }

        private static int ScorePrefabCandidate(
            string prefabPath,
            string targetFolder,
            VrcaFileInfo info)
        {
            var score = 0;
            var normalizedTarget = targetFolder.Replace('\\', '/').TrimEnd('/');
            var parent = Path.GetDirectoryName(prefabPath)?.Replace('\\', '/').TrimEnd('/');
            if (string.Equals(parent, normalizedTarget, StringComparison.OrdinalIgnoreCase))
                score += 50;

            var fileName = Path.GetFileNameWithoutExtension(prefabPath) ?? string.Empty;
            var desiredName = info != null && !string.IsNullOrEmpty(info.AvatarName)
                ? info.AvatarName
                : info != null && !string.IsNullOrEmpty(info.FileName)
                    ? Path.GetFileNameWithoutExtension(info.FileName)
                    : null;

            desiredName = SanitizeFileNameForUnity(desiredName);
            if (!string.IsNullOrEmpty(desiredName) &&
                fileName.IndexOf(desiredName, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                score += 120;
            }

            if (info != null && !string.IsNullOrEmpty(info.BlueprintId) &&
                fileName.IndexOf(info.BlueprintId, StringComparison.OrdinalIgnoreCase) >= 0)
            {
                score += 80;
            }

            GameObject prefabRoot = null;
            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(prefabPath);
                if (prefabRoot == null) return score;

                var components = prefabRoot.GetComponentsInChildren<Component>(true);
                var hasAvatarDescriptor = false;
                var hasPipelineManager = false;
                foreach (var component in components)
                {
                    if (component == null) continue;
                    var typeName = component.GetType().FullName;
                    if (string.Equals(typeName,
                            "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor",
                            StringComparison.Ordinal))
                    {
                        hasAvatarDescriptor = true;
                    }
                    else if (string.Equals(typeName, "VRC.Core.PipelineManager",
                                 StringComparison.Ordinal))
                    {
                        hasPipelineManager = true;
                    }
                }

                if (hasAvatarDescriptor) score += 1000;
                if (hasPipelineManager) score += 400;

                var rendererCount = prefabRoot.GetComponentsInChildren<Renderer>(true).Length;
                score += Math.Min(rendererCount, 100);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] Prefab 候補スコア算出失敗 '{prefabPath}': {ex.Message}");
            }
            finally
            {
                if (prefabRoot != null)
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return score;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        private static string TryRenamePrefabToOriginalName(
            string currentPrefabPath, VrcaFileInfo info)
        {
            if (string.IsNullOrEmpty(currentPrefabPath) || info == null) return null;

            try
            {
                
                string desiredName;
                var fileNameNoExt = Path.GetFileNameWithoutExtension(info.FileName ?? string.Empty);

                if (!string.IsNullOrEmpty(fileNameNoExt) &&
                    !fileNameNoExt.Equals("__data", StringComparison.OrdinalIgnoreCase))
                {
                    desiredName = fileNameNoExt;
                }
                else if (!string.IsNullOrEmpty(info.BlueprintId))
                {
                    desiredName = info.BlueprintId;
                }
                else
                {
                    return null; 
                }

                desiredName = SanitizeFileNameForUnity(desiredName);
                if (string.IsNullOrEmpty(desiredName)) return null;

                var currentName = Path.GetFileNameWithoutExtension(currentPrefabPath);
                if (string.Equals(currentName, desiredName, StringComparison.Ordinal))
                {
                    return currentPrefabPath; 
                }

                var folder = Path.GetDirectoryName(currentPrefabPath)?.Replace('\\', '/');
                if (string.IsNullOrEmpty(folder)) return null;

                
                var finalName = desiredName;
                int counter = 2;
                while (AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(
                    $"{folder}/{finalName}.prefab") != null)
                {
                    finalName = $"{desiredName} ({counter})";
                    counter++;
                    if (counter > 100) return null; 
                }

                
                var error = AssetDatabase.RenameAsset(currentPrefabPath, finalName);
                if (!string.IsNullOrEmpty(error))
                {
                    UnityEngine.Debug.LogWarning(
                        $"[AvatarRecovery] Prefab リネーム失敗 '{currentPrefabPath}': {error}");
                    return null;
                }

                var newPath = $"{folder}/{finalName}.prefab";
                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] Prefab リネーム: {currentName}.prefab → {finalName}.prefab");
                return newPath;
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] Prefab リネーム例外: {ex.Message}");
                return null;
            }
        }

        
        private static string SanitizeFileNameForUnity(string name)
        {
            if (string.IsNullOrEmpty(name)) return string.Empty;
            var invalid = Path.GetInvalidFileNameChars();
            var sb = new System.Text.StringBuilder();
            foreach (var c in name)
            {
                if (Array.IndexOf(invalid, c) < 0)
                    sb.Append(c);
                else
                    sb.Append('_');
            }
            return sb.ToString().Trim();
        }

        
        
        
        
        
        
        private static int ClearPipelineManagerBlueprintId(string prefabAssetPath)
        {
            if (string.IsNullOrEmpty(prefabAssetPath)) return 0;

            GameObject prefabRoot = null;
            var clearedCount = 0;

            try
            {
                prefabRoot = PrefabUtility.LoadPrefabContents(prefabAssetPath);
                if (prefabRoot == null) return 0;

                var components = prefabRoot.GetComponentsInChildren<Component>(true);
                foreach (var component in components)
                {
                    if (component == null) continue;

                    var componentType = component.GetType();
                    var typeName = componentType.FullName ?? componentType.Name;
                    if (!string.Equals(typeName, "VRC.Core.PipelineManager", StringComparison.Ordinal))
                        continue;

                    using (var serializedObject = new SerializedObject(component))
                    {
                        var blueprintIdProperty = serializedObject.FindProperty("blueprintId");
                        if (blueprintIdProperty == null ||
                            blueprintIdProperty.propertyType != SerializedPropertyType.String ||
                            string.IsNullOrWhiteSpace(blueprintIdProperty.stringValue))
                        {
                            continue;
                        }

                        blueprintIdProperty.stringValue = string.Empty;
                        serializedObject.ApplyModifiedPropertiesWithoutUndo();
                        EditorUtility.SetDirty(component);
                        clearedCount++;
                    }
                }

                if (clearedCount > 0)
                {
                    PrefabUtility.SaveAsPrefabAsset(prefabRoot, prefabAssetPath);
                    UnityEngine.Debug.Log(
                        $"[AvatarRecovery] PipelineManager の Blueprint ID をクリアしました: {prefabAssetPath} ({clearedCount} 件)");
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] Blueprint ID のクリアに失敗しました '{prefabAssetPath}': {ex.Message}");
            }
            finally
            {
                if (prefabRoot != null)
                    PrefabUtility.UnloadPrefabContents(prefabRoot);
            }

            return clearedCount;
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        private static void CleanStalePrefabsBeforeCopy(string targetFolder)
        {
            if (string.IsNullOrEmpty(targetFolder)) return;
            if (!AssetDatabase.IsValidFolder(targetFolder)) return;

            try
            {
                
                
                var guids = AssetDatabase.FindAssets("t:Prefab", new[] { targetFolder });
                if (guids == null || guids.Length == 0) return;

                
                var targetFolderNormalized = targetFolder.Replace('\\', '/').TrimEnd('/');
                var toMove = new List<string>();
                foreach (var guid in guids)
                {
                    var path = AssetDatabase.GUIDToAssetPath(guid);
                    if (string.IsNullOrEmpty(path)) continue;

                    var parentDir = Path.GetDirectoryName(path);
                    if (parentDir == null) continue;
                    parentDir = parentDir.Replace('\\', '/').TrimEnd('/');

                    if (string.Equals(parentDir, targetFolderNormalized,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        toMove.Add(path);
                    }
                }

                if (toMove.Count == 0) return;

                var backupFolder = CreatePreviousPrefabBackupFolder(targetFolderNormalized);
                if (string.IsNullOrEmpty(backupFolder))
                {
                    UnityEngine.Debug.LogWarning(
                        $"[AvatarRecovery] 既存 Prefab の退避先を作成できませんでした: {targetFolder}");
                    return;
                }

                UnityEngine.Debug.Log(
                    $"[AvatarRecovery] 再抽出検出 — 既存 Prefab {toMove.Count} 件を退避します: {backupFolder}");

                foreach (var p in toMove)
                {
                    var destination = AssetDatabase.GenerateUniqueAssetPath(
                        $"{backupFolder}/{Path.GetFileName(p)}");
                    var error = AssetDatabase.MoveAsset(p, destination);
                    if (string.IsNullOrEmpty(error))
                    {
                        UnityEngine.Debug.Log($"[AvatarRecovery]   退避: {p} → {destination}");
                    }
                    else
                    {
                        UnityEngine.Debug.LogWarning(
                            $"[AvatarRecovery] 既存 Prefab 退避失敗 '{p}': {error}");
                    }
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning(
                    $"[AvatarRecovery] スタール Prefab 掃除失敗: {ex.Message}");
            }
        }

        private static string CreatePreviousPrefabBackupFolder(string targetFolder)
        {
            var parent = Path.GetDirectoryName(targetFolder)?.Replace('\\', '/');
            var folderName = Path.GetFileName(targetFolder);
            if (string.IsNullOrEmpty(parent) ||
                string.IsNullOrEmpty(folderName) ||
                !AssetDatabase.IsValidFolder(parent))
            {
                return null;
            }

            var backupRoot = $"{parent}/{folderName}_PreviousPrefabs";
            EnsureUnityFolder(backupRoot);
            if (!AssetDatabase.IsValidFolder(backupRoot))
                return null;

            var backupFolder = $"{backupRoot}/{DateTime.Now:yyyyMMdd_HHmmss}";
            EnsureUnityFolder(backupFolder);
            return AssetDatabase.IsValidFolder(backupFolder) ? backupFolder : backupRoot;
        }

        
        
        
        
        
        
        
        
        
        
        private static List<string> DetectGuidConflicts(string srcFolder, string dstFolder)
        {
            var conflicts = new List<string>();
            if (string.IsNullOrEmpty(srcFolder) || !System.IO.Directory.Exists(srcFolder))
                return conflicts;

            var normalizedSrcFolder = srcFolder.Replace('\\', '/').TrimEnd('/');
            var normalizedDstFolder = (dstFolder ?? string.Empty).Replace('\\', '/').TrimEnd('/');

            string[] metaFiles;
            try
            {
                metaFiles = System.IO.Directory.GetFiles(
                    srcFolder, "*.meta", System.IO.SearchOption.AllDirectories);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogWarning($"[SARS] meta 列挙失敗: {ex.Message}");
                return conflicts;
            }

            foreach (var metaFile in metaFiles)
            {
                try
                {
                    var lines = System.IO.File.ReadAllLines(metaFile);
                    foreach (var line in lines)
                    {
                        if (!line.StartsWith("guid:", StringComparison.Ordinal)) continue;
                        var guid = line.Substring(5).Trim();
                        if (string.IsNullOrEmpty(guid)) break;

                        var existingPath = AssetDatabase.GUIDToAssetPath(guid);
                        if (!string.IsNullOrEmpty(existingPath))
                        {
                            var relativeMeta = metaFile.Replace('\\', '/');
                            if (relativeMeta.StartsWith(normalizedSrcFolder, StringComparison.OrdinalIgnoreCase))
                            {
                                relativeMeta = relativeMeta
                                    .Substring(normalizedSrcFolder.Length)
                                    .TrimStart('/', '\\');
                            }

                            var destinationAssetPath = BuildDestinationAssetPath(
                                normalizedDstFolder, relativeMeta);
                            if (IsSameAssetPath(existingPath, destinationAssetPath))
                                break;

                            var msg = $"[SARS] GUID衝突: {guid} → 既存: {existingPath} / " +
                                      $"新規: {relativeMeta}";
                            UnityEngine.Debug.LogError(msg);
                            conflicts.Add(msg);
                        }
                        break; 
                    }
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogWarning($"[SARS] meta 読取失敗: {metaFile}: {ex.Message}");
                }
            }
            return conflicts;
        }

        private static string BuildDestinationAssetPath(string dstFolder, string relativeMeta)
        {
            if (string.IsNullOrEmpty(relativeMeta)) return dstFolder;

            var relative = relativeMeta.Replace('\\', '/').TrimStart('/');
            const string metaExt = ".meta";
            if (relative.EndsWith(metaExt, StringComparison.OrdinalIgnoreCase))
                relative = relative.Substring(0, relative.Length - metaExt.Length);

            if (string.IsNullOrEmpty(dstFolder)) return relative;
            return $"{dstFolder}/{relative}".Replace('\\', '/');
        }

        private static bool IsSameAssetPath(string a, string b)
        {
            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b)) return false;
            return string.Equals(
                a.Replace('\\', '/').TrimEnd('/'),
                b.Replace('\\', '/').TrimEnd('/'),
                StringComparison.OrdinalIgnoreCase);
        }

        
        
        
        
        
        private static void TryDeleteDirectoryWithRetry(string path, int maxAttempts, int delayMs)
        {
            if (string.IsNullOrEmpty(path) || !Directory.Exists(path)) return;

            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                try
                {
                    Directory.Delete(path, recursive: true);
                    return; 
                }
                catch (Exception ex)
                {
                    if (attempt == maxAttempts)
                    {
                        UnityEngine.Debug.LogWarning(
                            $"[AvatarRecovery] 一時ディレクトリ削除失敗 ({attempt}/{maxAttempts}): " +
                            $"{path}\n{ex.Message}\n" +
                            "(このディレクトリは後で手動削除してください)");
                        return;
                    }
                    System.Threading.Thread.Sleep(delayMs);
                }
            }
        }

        #endregion
    }
}
