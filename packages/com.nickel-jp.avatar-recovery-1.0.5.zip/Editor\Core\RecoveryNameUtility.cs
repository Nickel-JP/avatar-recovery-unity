using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    internal static class RecoveryNameUtility
    {
        public const int RecommendedRestoredNameLength = 80;
        public const int RecommendedFullPathLength = 240;

        private static readonly Regex BlueprintIdRegex = new Regex(
            @"\b(?<id>(?:avtr|wrld)_[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12})\b",
            RegexOptions.Compiled);

        public static string BuildRestoredAssetName(VrcaFileInfo info, bool logWarning)
        {
            var parsed = ParseFileName(info?.FileName);
            var sourceId = !string.IsNullOrWhiteSpace(info?.BlueprintId)
                ? info.BlueprintId
                : parsed.BlueprintId;

            var avatarName = FirstUsefulName(info?.AvatarName, parsed.AvatarName);
            var authorName = NormalizeHumanToken(parsed.AuthorName);
            var shortId = BuildShortBlueprintId(sourceId);

            string displayName;
            if (!IsWeakName(avatarName) && !string.IsNullOrEmpty(authorName))
            {
                displayName = $"{avatarName} by {authorName}";
            }
            else if (!string.IsNullOrEmpty(authorName))
            {
                displayName = authorName;
            }
            else if (!IsWeakName(avatarName))
            {
                displayName = avatarName;
            }
            else
            {
                displayName = "Unknown";
            }

            if (!string.IsNullOrEmpty(shortId))
                displayName = $"{displayName} [{shortId}]";

            displayName = SanitizeFileName(displayName);
            if (string.IsNullOrWhiteSpace(displayName))
                displayName = !string.IsNullOrEmpty(shortId) ? shortId : "Unknown";

            if (logWarning && displayName.Length > RecommendedRestoredNameLength)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] 復元名が推奨文字数を超えています " +
                    $"({displayName.Length}/{RecommendedRestoredNameLength})。処理は続行します: {displayName}");
            }

            return displayName;
        }

        public static void WarnIfFullPathIsLong(string absolutePath, string context)
        {
            if (string.IsNullOrEmpty(absolutePath)) return;
            if (absolutePath.Length <= RecommendedFullPathLength) return;

            Debug.LogWarning(
                $"[AvatarRecovery] {context} のパスが長くなっています " +
                $"({absolutePath.Length}/{RecommendedFullPathLength})。長パス対応で書き込みを続行します: {absolutePath}");
        }

        private static ParsedName ParseFileName(string fileName)
        {
            var result = new ParsedName();
            var baseName = Path.GetFileNameWithoutExtension(fileName ?? string.Empty);
            if (string.IsNullOrWhiteSpace(baseName))
                return result;

            var idMatch = BlueprintIdRegex.Match(baseName);
            if (idMatch.Success)
                result.BlueprintId = idMatch.Groups["id"].Value;

            var withoutId = BlueprintIdRegex.Replace(baseName, string.Empty).Trim();
            var byIndex = withoutId.LastIndexOf(" by ", StringComparison.OrdinalIgnoreCase);
            if (byIndex >= 0)
            {
                result.AvatarName = NormalizeHumanToken(withoutId.Substring(0, byIndex));
                result.AuthorName = NormalizeHumanToken(withoutId.Substring(byIndex + 4));
            }
            else
            {
                result.AvatarName = NormalizeHumanToken(withoutId);
            }

            return result;
        }

        private static string FirstUsefulName(params string[] names)
        {
            if (names == null) return null;
            foreach (var name in names)
            {
                var normalized = NormalizeHumanToken(name);
                if (!IsWeakName(normalized))
                    return normalized;
            }
            return null;
        }

        private static string BuildShortBlueprintId(string blueprintId)
        {
            if (string.IsNullOrWhiteSpace(blueprintId))
                return null;

            var match = BlueprintIdRegex.Match(blueprintId);
            var normalized = match.Success ? match.Groups["id"].Value : blueprintId.Trim();

            var underscore = normalized.IndexOf('_');
            if (underscore > 0 && underscore < normalized.Length - 1)
            {
                var prefix = normalized.Substring(0, underscore + 1);
                var body = normalized.Substring(underscore + 1);
                var dash = body.IndexOf('-');
                if (dash >= 0)
                    body = body.Substring(0, dash);
                if (body.Length > 8)
                    body = body.Substring(0, 8);
                return prefix + body;
            }

            return normalized.Length > 12 ? normalized.Substring(0, 12) : normalized;
        }

        private static bool IsWeakName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return true;

            var compact = name.Trim().Trim('_', '-', '.', ' ');
            if (string.IsNullOrEmpty(compact))
                return true;

            return compact.Equals("__data", StringComparison.OrdinalIgnoreCase) ||
                   compact.Equals("unknown", StringComparison.OrdinalIgnoreCase) ||
                   compact.Equals("avatar", StringComparison.OrdinalIgnoreCase);
        }

        private static string NormalizeHumanToken(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            var normalized = BlueprintIdRegex.Replace(value, string.Empty)
                .Replace('\t', ' ')
                .Trim()
                .Trim('_', '-', '.', ' ');

            while (normalized.Contains("  "))
                normalized = normalized.Replace("  ", " ");

            return string.IsNullOrWhiteSpace(normalized) ? null : normalized;
        }

        private static string SanitizeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return string.Empty;

            var invalid = Path.GetInvalidFileNameChars();
            var sb = new StringBuilder(name.Length);
            foreach (var c in name)
            {
                if (Array.IndexOf(invalid, c) < 0)
                    sb.Append(c);
                else
                    sb.Append('_');
            }

            return sb.ToString().Trim().TrimEnd('.');
        }

        private struct ParsedName
        {
            public string AvatarName;
            public string AuthorName;
            public string BlueprintId;
        }
    }
}
