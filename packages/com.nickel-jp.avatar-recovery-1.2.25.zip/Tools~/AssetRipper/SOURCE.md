# AssetRipper source and license

- Bundled version: AssetRipper 1.3.14
- Product version: 1.3.14+cd07b6abbe8602f418630ff0e1b87f3527ff8d56
- Corresponding source: https://github.com/AssetRipper/AssetRipper/tree/cd07b6abbe8602f418630ff0e1b87f3527ff8d56
- Corresponding source archive: https://github.com/AssetRipper/AssetRipper/archive/cd07b6abbe8602f418630ff0e1b87f3527ff8d56.zip
- License: GNU General Public License v3.0 (AssetRipper.GPL-3.0.txt)

AvatarRecovery includes only AssetRipper.exe and the related files required for
it to run. These AssetRipper-related files remain governed by their included
third-party licenses and are not subject to the AvatarRecovery Custom License.
