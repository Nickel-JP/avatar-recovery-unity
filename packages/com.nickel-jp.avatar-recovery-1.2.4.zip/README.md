# AvatarRecovery

AvatarRecovery は、VRChat の `.vrca` / `.vrcw` / `.vrcp` AssetBundle を Unity Editor 内で確認し、許可された範囲で Unity プロジェクトへ復元するための Editor 拡張です。

AssetRipper.exe を外部プロセスとして呼び出し、その後に AvatarRecovery 独自の C# 後処理で Script GUID、Shader GUID、Missing Script、Prefab 選択、Pose Reset の安全確認を補助します。AssetRipper 本体と SARS ソースコードは同梱していません。

## 対象環境

| 項目 | 内容 |
|---|---|
| Unity | 2022.3.x (VCC 推奨) |
| OS | Windows 10 / 11 |
| VRChat SDK | `com.vrchat.base >=3.7.0 <3.11.0` |
| 外部ツール | AssetRipper.exe。Dean2k/SARS の Release.zip からユーザーが別途取得 |
| 推奨 Shader | Poiyomi Toon Shader または lilToon |

Avatar プロジェクトでは `VRChat SDK - Avatars`、World プロジェクトでは `VRChat SDK - Worlds` を VCC から導入してください。Base / Avatars / Worlds は同じ SDK 系列に揃えることを推奨します。

## インストール

VCC から利用する場合は、以下の VPM リポジトリを追加します。

```text
https://nickel-jp.github.io/avatar-recovery-unity/index.json
```

GitHub Pages の追加ページ:

```text
https://nickel-jp.github.io/avatar-recovery-unity/add/
```

インストール後、Unity メニューの `AvatarRecovery → Open Window` からウィンドウを開きます。互換用に `Tools → AvatarRecovery` も残しています。

## AssetRipper.exe の設定

`Settings` タブの `AssetRipper.exe Path` に AssetRipper.exe の場所を指定してください。未指定の場合、以下のような候補パスから自動検出します。

```text
%USERPROFILE%\Tools\AssetRipper\AssetRipper.exe
%SystemDrive%\Tools\AssetRipper\AssetRipper.exe
<any drive>\Tools\AssetRipper\AssetRipper.exe
<any drive>\Tools\ARC\Assets\AssetRipper\AssetRipper.exe
```

AssetRipper が見つからない場合、AssetRipper + SARS パイプラインは無効表示になります。

## 基本操作

1. `File Select` タブで `.vrca` / `.vrcw` / `.vrcp` を追加します。
2. ファイル一覧は Avatar / World / Prop の種類別に常時見出し表示され、必要な種類だけ展開できます。
3. `復元履歴` では成功した復元をプロジェクトごとに最大 20 件まで保持し、復元順、容量順、拡張子順で確認できます。
4. `File Preview` ボタンで、展開せず AssetBundle 内の情報や GameObject プレビューを確認できます。
5. `Run` または `Run N Files` で解析・展開を実行します。
6. 復元物は種類ごとの既定フォルダーへ出力されます。

既定出力先:

```text
Assets/AvatarRecovery/Restored Avatar data
Assets/AvatarRecovery/Restored World data
Assets/AvatarRecovery/Restored Prop data
```

## 主なタブ

| タブ | 内容 |
|---|---|
| File Select | 対象ファイル追加、種類別一覧、復元履歴、View Assets Info、解析・展開 |
| MissingScriptSearch | Hierarchy / Prefab の Missing Script 検出と Undo 対応削除。Add 欄から対象を追加 |
| Backup | VRChat SDK ビルド時の `.vrca` 自動バックアップ |
| Settings | 出力先、AssetRipper、Shader Error Fix、Missing Script 削除ポリシーなど |
| Logs | 直近の一括実行結果を TXT / Markdown / CSV で出力 |
| License | AvatarRecovery、SARS、AssetRipper のライセンス情報 |
| GitHub | リリースノート、最新バージョン、導入・利用案内へのリンク |

v1.1.0 では旧診断タブと自動診断処理を削除し、実行結果の保存は `Logs` タブへ移しました。

## View Assets Info

`View Assets Info` は `.vrca` / `.vrcw` / `.vrcp` を展開せずに確認するためのウィンドウです。

- GameObject がある AssetBundle は `PreviewRenderUtility` で隔離プレビューします。
- Scene-only の `.vrcw` など、GameObject プレビューがない AssetBundle は Scene パスと Asset 名を表示します。
- Camera は近距離に寄りすぎないよう、対象 Bounds に基づいて最小距離を制限します。
- Preview 中の Shader fallback は表示用の一時 Material にのみ適用され、展開時設定とは独立しています。

## Shader Lists

`AvatarRecovery → Open Shader Lists` から `_ShaderReport` を開けます。

- `MaterialShaderMap.csv` を使った `Material → Shader` 表示
- `Shaders.txt` 表示
- Material 行の選択と、元 Shader 名に完全一致する `Shader.Find` 結果だけを使う再割り当て
- 表示中 Material 行の全選択 / 全解除
- Match / Mismatch フィルターと、Match 先頭 / Mismatch 先頭ソート
- 複数の `_ShaderReport` フォルダー追加と表示切り替え

`MaterialShaderMap.txt` は互換用に生成されることがありますが、v1.1.0 のビューアでは専用タブを表示しません。

## 出力される主なファイル

```text
Restored .../
  _ShaderReport/
    Shaders.txt
    MaterialShaderMap.csv
    MaterialShaderMap.txt
  RawPoseBackup/
  PoseResetCandidate/
```

## ライセンス

AvatarRecovery v1.1.0 以降は AvatarRecovery Custom License で配布します。詳細は同梱の `LICENSE` を確認してください。

過去に MIT License で公開済みの AvatarRecovery 版は、公開時点で同梱されていたライセンス条件に従います。v1.1.0 以降の配布物には、この README と同梱 `LICENSE` の条件が適用されます。

AssetRipper と SARS は別プロジェクトです。AvatarRecovery は AssetRipper バイナリおよび SARS ソースコードを同梱しません。

## 利用上の注意

このツールは、自分のアセット、正当に購入したアセット、または明示的に許可を得たアセットの保守・復旧・検証を目的としています。

第三者の作品を無断で抽出、複製、再配布、販売、再アップロード、なりすまし利用する目的では使用しないでください。VRChat の利用規約、各アセットのライセンス、適用される法律を必ず守ってください。

## v1.2.4 の主な変更

- Unity の AvatarRecovery メニューに、表示言語に関係なく `Language` と表示される言語切り替えを追加
- `Language` 配下の `Japanese` / `English` から言語を選択でき、ツール内の言語切り替えと双方向に連動して保存
- ツール内に `GitHub` 案内タブを追加し、リリースノート、最新バージョン、導入・利用案内を確認できる公式ページへのリンクを日英で表示
- Unity メニューの説明書を `AvatarRecovery > Manual` へ英語化
- 説明書のウィンドウ名と全文を日英対応し、ツールおよびメニューの言語設定へ即時連動

## v1.2.3 の主な変更

- Unity の AvatarRecovery メニューに表示する項目を整理
- PhysBone・Contact 参照チェックと Scene の旧復元配置クリーンアップ機能は内部に保持したまま、メニューから非表示化

## v1.2.2 の主な変更

- AssetRipper の反映用一時ファイルを、元のファイル名へ接尾辞を追加せず、同じディレクトリ内の短い一時名で作成
- 250 文字の AnimationClip・Material と 255 文字の meta ファイルを含む長いパスの処理を修正
- Script・Shader GUID 修正と GUID 衝突検査でも長いパスを一貫して処理

## v1.2.1 の主な変更

- 配布パッケージのセキュリティ保証範囲と制限を明確化
- 意図した安全性に寄与しない保護動作を整理
- リリース検証と回帰テストを強化

## セキュリティモデルと限界

公開検証情報は配布物の完全性確認を支援します。期待値は独立して信頼できる経路から取得してください。同じ配布元だけから取得した情報は、それ単独では信頼の起点になりません。

クライアントへ配布されるコードは、機密性や改変不能性を保証しません。真に秘密である必要がある処理は、管理されたサーバー側へ置いてください。
## v1.2.0 の主な変更

- 既存の復元機能を維持したまま、主要な復元工程の安定性を改善
- 抽出、復元、自動バックアップ処理が継続できない場合に、失敗理由と推奨する解決方法をポップアップ表示
- Unity 起動時に誤って AvatarRecovery が利用できなくなる問題を修正

## v1.1.20 の主な変更

- Shader Lists の `Material → Shader` 表示で、表示中 Material 行を全選択 / 全解除できるように変更
- Match / Mismatch フィルターを追加。どちらも未選択の場合は両方を表示
- 元の順、Match 先頭、Mismatch 先頭のソートを追加

## v1.1.19 の主な変更

- 復元履歴を Unity プロジェクト単位で保存するよう変更
- Unity プロジェクトを閉じて開き直しても、同じプロジェクトの復元履歴が残るよう改善
- 復元履歴の保存件数を最新 20 件までに制限

## v1.1.18 の主な変更

- 復元履歴を読み込む際に Unity Console へ `The same field name is serialized multiple times` が出る問題を修正
- 復元後に File Select タブの復元履歴を開いても、履歴読み込みが止まらないよう改善

## v1.1.17 の主な変更

- Unity のドメインリロード時に古いログ handler が残らないよう、Editor 再読み込み前にログ handler を復元
- Unity 起動直後に package DLL の場所が一時的に取得できない場合、警告を固定せず遅延再確認するよう改善

## v1.1.16 の主な変更

- File Select に `復元履歴` 折り畳みメニューを追加
- 復元履歴を復元順、容量順、拡張子順 `.vrca` / `.vrcw` / `.vrcp` でソート可能に変更
- 履歴行を `復元名 [.vrca]` のように表示し、クリックで復元先へ移動できるよう改善

## v1.1.8 の主な変更

- File Select の各ファイル行にあるプレビューボタン表記を `File Preview` に変更

## v1.1.7 の主な変更

- `View Assets Info` で scene-only の `.vrcw` を開いた時に、Unity の GameObject 読み込み API を呼ばないよう修正
- scene-only AssetBundle は Scene パスと Asset 名を表示し、`This method cannot be used on a streamed scene AssetBundle` 例外を出さないよう改善
- 直接 AssetBundle 解析経路でも streamed scene AssetBundle への `LoadAllAssets` 呼び出しを回避

## v1.1.2 の主な変更

- VPM package と repository metadata を v1.1.2 向けに更新
- Unity メッセージ、VRC SDK callback、package metadata、VPM index fields の互換性を維持

## v1.1.1 の主な変更

- MissingScriptSearch の対象追加 UI を大きな D&D 欄から Add 式の ObjectField 行へ変更
- MissingScriptSearch は Add 欄へのドラッグまたは選択で GameObject / Prefab を追加し、複数対象の追加式スキャンを維持
- File Select の Avatar / World / Prop 折り畳み見出しは常時表示のまま、初期状態を閉じる形へ変更

## v1.1.0 の主な変更

- UI 名称を `AvatarRecovery` / `View Assets Info` / `Run` 系へ整理
- File Select の未選択時ヘルプを簡素化
- Avatar / World / Prop 折り畳みを追加
- `Shader Error Fix` 表記へ変更
- `MaterialShaderMap.txt` タブを削除
- 旧診断タブと自動診断処理を削除
- `Logs` タブを追加し、実行結果の TXT / Markdown / CSV 出力に対応
- 初回利用時の同意画面を追加。同意しない場合もファイル削除は行いません
- `View Assets Info` の scene-only `.vrcw` 情報表示とカメラ距離制御を改善
- MissingScriptSearch の D&D を追加式に変更
- ライセンスを AvatarRecovery Custom License へ変更
