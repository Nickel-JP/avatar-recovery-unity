




using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    internal static class Styles
    {
        #region フラグ

        private static bool _initialized;

        #endregion

        #region スタイル定義

        

        
        public static GUIStyle Title { get; private set; }

        
        public static GUIStyle SectionHeader { get; private set; }

        

        
        public static GUIStyle RowEven { get; private set; }

        
        public static GUIStyle RowOdd { get; private set; }

        
        public static GUIStyle RowSelected { get; private set; }

        

        
        public static GUIStyle WrappedLabel { get; private set; }

        
        public static GUIStyle WarningLabel { get; private set; }

        
        public static GUIStyle ErrorLabel { get; private set; }

        
        public static GUIStyle SuccessLabel { get; private set; }

        
        public static GUIStyle EncryptionWarningBox { get; private set; }

        

        
        public static GUIStyle PrimaryButton { get; private set; }

        
        public static GUIStyle LinkButton { get; private set; }

        

        
        private static Texture2D _rowEvenTexture;

        
        private static Texture2D _rowSelectedTexture;

        
        private static Texture2D _warningBoxTexture;

        #endregion

        #region 初期化

        
        public static void EnsureInitialized()
        {
            if (_initialized) return;
            Initialize();
            _initialized = true;
        }

        private static void Initialize()
        {
            
            Title = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize  = 16,
                alignment = TextAnchor.MiddleLeft,
                margin    = new RectOffset(4, 4, 6, 4)
            };

            
            SectionHeader = new GUIStyle(EditorStyles.boldLabel)
            {
                fontSize = 12,
                margin   = new RectOffset(2, 2, 8, 4)
            };

            
            _rowEvenTexture = MakeSolidTexture(
                EditorGUIUtility.isProSkin
                    ? new Color(0.22f, 0.22f, 0.22f)
                    : new Color(0.88f, 0.88f, 0.88f));

            _rowSelectedTexture = MakeSolidTexture(
                EditorGUIUtility.isProSkin
                    ? new Color(0.17f, 0.36f, 0.53f)
                    : new Color(0.24f, 0.49f, 0.91f));

            
            RowEven = new GUIStyle(GUIStyle.none)
            {
                normal    = { background = _rowEvenTexture },
                padding   = new RectOffset(4, 4, 2, 2),
                fixedHeight = 20
            };

            RowOdd = new GUIStyle(GUIStyle.none)
            {
                padding   = new RectOffset(4, 4, 2, 2),
                fixedHeight = 20
            };

            RowSelected = new GUIStyle(GUIStyle.none)
            {
                normal    = { background = _rowSelectedTexture },
                padding   = new RectOffset(4, 4, 2, 2),
                fixedHeight = 20
            };

            
            WrappedLabel = new GUIStyle(EditorStyles.label)
            {
                wordWrap = true
            };

            WarningLabel = new GUIStyle(EditorStyles.label)
            {
                wordWrap = true,
                normal   = { textColor = new Color(1f, 0.75f, 0f) }
            };

            ErrorLabel = new GUIStyle(EditorStyles.label)
            {
                wordWrap = true,
                normal   = { textColor = new Color(0.9f, 0.2f, 0.2f) }
            };

            SuccessLabel = new GUIStyle(EditorStyles.label)
            {
                wordWrap = true,
                normal   = { textColor = new Color(0.2f, 0.8f, 0.2f) }
            };

            
            _warningBoxTexture = MakeSolidTexture(new Color(0.5f, 0.4f, 0f, 0.3f));
            EncryptionWarningBox = new GUIStyle(EditorStyles.helpBox)
            {
                wordWrap = true,
                normal   = { background = _warningBoxTexture }
            };

            
            PrimaryButton = new GUIStyle(GUI.skin.button)
            {
                fontSize   = 13,
                fontStyle  = FontStyle.Bold,
                fixedHeight = 32
            };

            
            var linkColor = EditorGUIUtility.isProSkin
                ? new Color(0.4f, 0.7f, 1f)
                : new Color(0.1f, 0.35f, 0.8f);
            var linkHover = EditorGUIUtility.isProSkin
                ? new Color(0.6f, 0.85f, 1f)
                : new Color(0.0f, 0.2f, 0.7f);
            LinkButton = new GUIStyle(EditorStyles.label)
            {
                normal  = { textColor = linkColor },
                hover   = { textColor = linkHover },
                active  = { textColor = linkHover },
                wordWrap = false,
            };
        }

        #endregion

        #region ユーティリティ

        
        
        
        
        
        
        private static Texture2D MakeSolidTexture(Color color)
        {
            var tex = new Texture2D(1, 1, TextureFormat.RGBA32, mipChain: false)
            {
                hideFlags = HideFlags.HideAndDontSave,
            };
            tex.SetPixel(0, 0, color);
            tex.Apply();
            return tex;
        }

        
        public static GUIStyle GetRowStyle(int rowIndex, int selectedIndex)
        {
            if (rowIndex == selectedIndex) return RowSelected;
            return rowIndex % 2 == 0 ? RowEven : RowOdd;
        }

        #endregion
    }
}
