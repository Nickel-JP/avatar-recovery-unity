







using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using UnityEditor;
using UnityEngine;
using VRC.SDKBase.Editor.BuildPipeline;

namespace EditorTools.AvatarRecovery
{
    
    public sealed class VrcaAutoBackupPreprocess : IVRCSDKPreprocessAvatarCallback
    {
        public int callbackOrder => -99999; 

        public bool OnPreprocessAvatar(GameObject avatarGameObject)
        {
            if (!EditorPrefsHelper.LoadAutoBackupEnabled()) return true;

            VrcaAutoBackup.SetPendingAvatarName(
                avatarGameObject != null ? avatarGameObject.name : string.Empty);

            VrcaAutoBackup.TakeSnapshot();
            return true;
        }
    }

    
    public sealed class VrcaAutoBackupPostprocess : IVRCSDKPostprocessAvatarCallback
    {
        public int callbackOrder => 99999; 

        public void OnPostprocessAvatar()
        {
            if (!EditorPrefsHelper.LoadAutoBackupEnabled()) return;

            var destFolder = EditorPrefsHelper.LoadBackupDestPath();
            if (string.IsNullOrEmpty(destFolder)) return;

            
            EditorApplication.delayCall += () =>
                VrcaAutoBackup.DetectAndCopy(destFolder);
        }
    }

    
    public static class VrcaAutoBackup
    {
        #region 状態

        private static volatile string _pendingAvatarName = string.Empty;

        
        private static HashSet<string> _preSnapshot = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        #endregion

        #region 公開 API

        public static string AvatarsFolder => GetAvatarsFolder();
        public static void RefreshWatcher() {  }

        public static void SetPendingAvatarName(string name)
            => _pendingAvatarName = string.IsNullOrWhiteSpace(name) ? string.Empty : name.Trim();

        
        public static void TakeSnapshot()
        {
            _preSnapshot = new HashSet<string>(
                ScanVrcaFiles(), StringComparer.OrdinalIgnoreCase);
        }

        
        public static void DetectAndCopy(string destFolder)
        {
            var postFiles = ScanVrcaFiles();
            var newFiles  = postFiles.Except(_preSnapshot).ToList();

            if (newFiles.Count == 0)
            {
                Debug.LogWarning("[AvatarRecovery] ビルド後に新規 vrca が見つかりませんでした。");
                return;
            }

            var avatarName = _pendingAvatarName;

            foreach (var srcPath in newFiles)
            {
                var destFileName = MakeDestFileName(srcPath, avatarName);
                var destPath     = Path.Combine(destFolder, destFileName);

                
                var src  = srcPath;
                var dest = destPath;
                ThreadPool.QueueUserWorkItem(_ => CopyVrca(src, dest));
            }
        }

        #endregion

        #region スキャン

        
        
        
        
        private static List<string> ScanVrcaFiles()
        {
            var result  = new List<string>();
            var folders = GetScanFolders();

            foreach (var folder in folders)
            {
                if (!Directory.Exists(folder)) continue;
                try
                {
                    result.AddRange(
                        Directory.GetFiles(folder, "*.vrca", SearchOption.AllDirectories));
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[AvatarRecovery] スキャン中にエラー: {folder}\n{ex.Message}");
                }
            }

            return result;
        }

        private static string[] GetScanFolders()
        {
            
            var projectRoot = Path.GetFullPath(Path.Combine(Application.dataPath, ".."));
            return new[]
            {
                Path.Combine(projectRoot,    "Temp"),                           
                Application.temporaryCachePath,                                 
                Path.Combine(Path.GetTempPath(), "VRChat"),                     
                GetAvatarsFolder(),                                             
            };
        }

        private static string GetAvatarsFolder()
        {
            var localAppData = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var localLow     = Path.Combine(localAppData, "..", "LocalLow");
            return Path.GetFullPath(Path.Combine(localLow, @"VRChat\VRChat\Avatars"));
        }

        #endregion

        #region コピー処理（スレッドプール）

        private static void CopyVrca(string srcPath, string destPath)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(destPath));

                WaitUntilFileReady(srcPath, timeoutMs: 15000);

                if (!File.Exists(srcPath))
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] コピー元 vrca が消失しました（Upload 後に削除された可能性）:\n{srcPath}");
                    return;
                }

                bool existed = File.Exists(destPath);
                if (existed)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] 同名バックアップが既に存在するため上書きします。\n" +
                        $"ファイル: {Path.GetFileName(destPath)}\n保存先: {destPath}");
                }

                File.Copy(srcPath, destPath, overwrite: true);
                Debug.Log($"[AvatarRecovery] 自動バックアップ完了: {Path.GetFileName(destPath)}\n→ {destPath}");
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AvatarRecovery] 自動バックアップ失敗: {srcPath}\n{ex.Message}");
            }
        }

        private static void WaitUntilFileReady(string path, int timeoutMs)
        {
            var deadline = DateTime.UtcNow.AddMilliseconds(timeoutMs);
            while (DateTime.UtcNow < deadline)
            {
                if (!File.Exists(path)) { Thread.Sleep(200); continue; }
                try
                {
                    using (File.Open(path, FileMode.Open, FileAccess.Read, FileShare.None)) { }
                    return;
                }
                catch (IOException) { Thread.Sleep(200); }
            }
        }

        #endregion

        #region ユーティリティ

        private static string MakeDestFileName(string srcPath, string avatarName)
        {
            if (!string.IsNullOrEmpty(avatarName))
            {
                foreach (var c in Path.GetInvalidFileNameChars())
                    avatarName = avatarName.Replace(c, '_');
                return avatarName + ".vrca";
            }
            return Path.GetFileName(srcPath);
        }

        #endregion
    }

    
    
    
    
    public sealed class VrcaAutoBackupSdkCallback : IVRCSDKBuildRequestedCallback
    {
        public int callbackOrder => 9999;

        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (requestedBuildType != VRCSDKRequestedBuildType.Avatar)
                return true;

            var descriptor = UnityEngine.Object.FindObjectOfType
                <VRC.SDK3.Avatars.Components.VRCAvatarDescriptor>();
            if (descriptor != null)
            {
                VrcaAutoBackup.SetPendingAvatarName(descriptor.gameObject.name);
                Debug.Log($"[AvatarRecovery] バックアップ用アバター名を記録: {descriptor.gameObject.name}");
            }

            return true;
        }
    }
}
