









using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public static class ShaderGuidFixer
    {
        #region 定数

        
        private static readonly string[] ShaderFolderNames = { ".Shader", "Shader" };

        
        private static readonly string[] FallbackShaderNames =
        {
            ".poiyomi/Poiyomi Toon",
            "Poiyomi/Poiyomi Toon",
            ".poiyomi/Poiyomi Pro",
            "Poiyomi/Poiyomi Pro",
            "lilToon",
            "VRChat/Mobile/Toon Lit",
            "Standard",
        };

        #endregion

        #region 公開 DTO

        
        public class ShaderMapping
        {
            public string OldKey       { get; set; } 
            public string NewYaml      { get; set; } 
            public string OriginalName { get; set; } 
            public Shader ResolvedShader { get; set; }
            public bool   Seen          { get; set; }
            public int    ReplaceCount  { get; set; }
        }

        
        public class FixResult
        {
            public int MappingCount        { get; set; }
            public int FixedFileCount      { get; set; }
            public int FixedReferenceCount { get; set; }
            public List<string> UnresolvedShaders { get; set; } = new List<string>();
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        public static Dictionary<string, ShaderMapping> CollectShaderMappings(string targetFolder)
        {
            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder))
                return new Dictionary<string, ShaderMapping>();

            var shaderFolders = FindShaderFolders(targetFolder);
            return BuildMappingsFromShaderFolders(shaderFolders);
        }

        
        
        
        
        
        
        
        public static void ResolveMappingsPublic(
            Dictionary<string, ShaderMapping> mappings, FixResult result)
        {
            ResolveMappings(mappings, result);
        }

        
        
        
        
        
        
        
        public static void ApplyMappings(
            string targetFolder,
            Dictionary<string, ShaderMapping> mappings,
            FixResult result)
        {
            if (mappings == null || mappings.Count == 0) return;
            if (string.IsNullOrEmpty(targetFolder) || !Directory.Exists(targetFolder)) return;

            var matPaths = Directory.GetFiles(targetFolder, "*.mat", SearchOption.AllDirectories);

            int fileCount = 0;
            int refCount  = 0;

            foreach (var path in matPaths)
            {
                var (modified, replaces) = FixMaterialFile(path, mappings);
                if (modified) { fileCount++; refCount += replaces; }
            }

            result.FixedFileCount      = fileCount;
            result.FixedReferenceCount = refCount;
        }

        
        
        
        
        
        
        
        public static FixResult FixFolder(string targetFolder)
        {
            var result = new FixResult();

            var mappings = CollectShaderMappings(targetFolder);
            if (mappings.Count == 0)
            {
                Debug.Log("[AvatarRecovery] FixShaders: ダミーシェーダーが見つかりません（処理スキップ）");
                return result;
            }

            result.MappingCount = mappings.Count;

            ResolveMappings(mappings, result);
            ApplyMappings(targetFolder, mappings, result);

            Debug.Log(
                $"[AvatarRecovery] FixShaders 完了: " +
                $"{result.FixedFileCount} ファイル / {result.FixedReferenceCount} 参照を修正 " +
                $"(マッピング: {mappings.Count}, 未解決: {result.UnresolvedShaders.Count})");

            return result;
        }

        
        public static void DeleteShaderFolders(string targetFolder)
        {
            var folders = FindShaderFolders(targetFolder);
            foreach (var folder in folders)
            {
                try
                {
                    Directory.Delete(folder, recursive: true);
                    var metaPath = folder + ".meta";
                    if (File.Exists(metaPath)) File.Delete(metaPath);
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] シェーダーフォルダー削除失敗 '{folder}': {ex.Message}");
                }
            }
        }

        #endregion

        #region 内部実装 - フォルダー検索とマッピング構築

        private static List<string> FindShaderFolders(string targetFolder)
        {
            var result = new List<string>();
            try
            {
                foreach (var name in ShaderFolderNames)
                {
                    var found = Directory.GetDirectories(
                        targetFolder, name, SearchOption.AllDirectories);
                    result.AddRange(found.Select(p => p.Replace('\\', '/')));
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] シェーダーフォルダー検索エラー: {ex.Message}");
            }
            return result;
        }

        
        
        
        
        
        private static Dictionary<string, ShaderMapping> BuildMappingsFromShaderFolders(
            List<string> shaderFolders)
        {
            var mappings = new Dictionary<string, ShaderMapping>();

            foreach (var folder in shaderFolders)
            {
                string[] metaPaths;
                try
                {
                    metaPaths = Directory.GetFiles(folder, "*.shader.meta", SearchOption.AllDirectories)
                        .Select(p => p.Replace('\\', '/')).ToArray();
                }
                catch (Exception ex)
                {
                    Debug.LogWarning($"[AvatarRecovery] .shader.meta 列挙失敗: {ex.Message}");
                    continue;
                }

                foreach (var metaPath in metaPaths)
                {
                    try
                    {
                        
                        const string metaExt = ".meta";
                        if (!metaPath.EndsWith(metaExt, StringComparison.OrdinalIgnoreCase))
                            continue;
                        var shaderPath = metaPath.Substring(0, metaPath.Length - metaExt.Length);
                        if (!File.Exists(shaderPath)) continue;

                        var stubGuid = ReadGuidFromMeta(metaPath);
                        if (string.IsNullOrEmpty(stubGuid)) continue;

                        var origName = ReadShaderNameFromShaderFile(shaderPath);
                        if (string.IsNullOrEmpty(origName)) continue;

                        
                        
                        
                        var oldKey = "guid: " + stubGuid;
                        if (mappings.ContainsKey(oldKey)) continue;

                        mappings[oldKey] = new ShaderMapping
                        {
                            OldKey       = oldKey,
                            OriginalName = origName,
                        };
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] シェーダー .meta 解析失敗 '{metaPath}': {ex.Message}");
                    }
                }
            }

            return mappings;
        }

        private static string ReadGuidFromMeta(string metaPath)
        {
            try
            {
                
                using (var reader = LongPathIO.OpenReader(metaPath))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("guid:", StringComparison.Ordinal))
                            return line.Substring(5).Trim();
                    }
                }
            }
            catch {  }
            return null;
        }

        
        private static string ReadShaderNameFromShaderFile(string shaderPath)
        {
            try
            {
                
                using (var reader = LongPathIO.OpenReader(shaderPath))
                {
                    
                    for (int i = 0; i < 5; i++)
                    {
                        var line = reader.ReadLine();
                        if (line == null) break;

                        var idx = line.IndexOf("Shader \"", StringComparison.Ordinal);
                        if (idx >= 0)
                        {
                            int from = idx + "Shader \"".Length;
                            int to   = line.LastIndexOf("\"");
                            if (to > from) return line.Substring(from, to - from);
                        }
                    }
                }
            }
            catch {  }
            return null;
        }

        #endregion

        #region 内部実装 - シェーダー解決

        
        
        
        
        private static void ResolveMappings(
            Dictionary<string, ShaderMapping> mappings, FixResult result)
        {
            foreach (var mapping in mappings.Values)
            {
                var shader = FindBestProjectShader(mapping.OriginalName);
                if (shader == null)
                {
                    result.UnresolvedShaders.Add(mapping.OriginalName);
                    
                    continue;
                }

                mapping.ResolvedShader = shader;

                if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(
                        shader, out var newGuid, out long newFileID))
                {
                    mapping.NewYaml = $"{{fileID: {newFileID}, guid: {newGuid}, type: 3}}";
                }
                else
                {
                    result.UnresolvedShaders.Add(mapping.OriginalName);
                }
            }
        }

        
        
        
        
        
        
        
        
        
        public static Shader FindBestProjectShader(string originalName)
        {
            if (string.IsNullOrEmpty(originalName)) return FindFallback();

            
            var exact = Shader.Find(originalName);
            if (exact != null) return exact;

            
            var alternatives = new List<string>();
            if (originalName.StartsWith("."))
                alternatives.Add(originalName.Substring(1));
            else
                alternatives.Add("." + originalName);

            
            if (originalName.Contains("Poiyomi"))
            {
                alternatives.Add(".poiyomi/Poiyomi Toon");
                alternatives.Add("Poiyomi/Poiyomi Toon");
            }
            
            if (originalName.Contains("lil"))
            {
                alternatives.Add("lilToon");
            }

            foreach (var alt in alternatives)
            {
                var found = Shader.Find(alt);
                if (found != null) return found;
            }

            
            int lastSlash = originalName.LastIndexOf('/');
            if (lastSlash >= 0 && lastSlash < originalName.Length - 1)
            {
                var baseName = originalName.Substring(lastSlash + 1);
                var foundByBase = Shader.Find(baseName);
                if (foundByBase != null) return foundByBase;
            }

            
            return FindFallback();
        }

        private static Shader FindFallback()
        {
            foreach (var name in FallbackShaderNames)
            {
                var s = Shader.Find(name);
                if (s != null) return s;
            }
            return null;
        }

        #endregion

        #region 内部実装 - YAML テキスト置換

        
        
        
        
        
        
        
        private static (bool modified, int replaces) FixMaterialFile(
            string filePath, Dictionary<string, ShaderMapping> mappings)
        {
            int replaces = 0;
            var tempPath = filePath + ".avatar_recovery_tmp";

            try
            {
                
                using (var reader = LongPathIO.OpenReader(filePath))
                using (var writer = LongPathIO.OpenWriter(tempPath, append: false))
                {
                    string line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        if (line.StartsWith("  m_Shader: ", StringComparison.Ordinal) &&
                            line.Contains("guid:"))
                        {
                            var guid = ExtractGuidFromLine(line);
                            if (!string.IsNullOrEmpty(guid))
                            {
                                var key = "guid: " + guid;
                                if (mappings.TryGetValue(key, out var mapping))
                                {
                                    mapping.Seen = true;
                                    if (!string.IsNullOrEmpty(mapping.NewYaml))
                                    {
                                        line = $"  m_Shader: {mapping.NewYaml}";
                                        mapping.ReplaceCount++;
                                        replaces++;
                                    }
                                }
                            }
                        }
                        writer.WriteLine(line);
                    }
                }

                if (replaces > 0)
                {
                    AtomicReplace(filePath, tempPath);
                    return (true, replaces);
                }
                else
                {
                    File.Delete(tempPath);
                    return (false, 0);
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] FixMaterialFile 失敗 '{Path.GetFileName(filePath)}': {ex.Message}");
                try { if (File.Exists(tempPath)) File.Delete(tempPath); } catch { }
                return (false, 0);
            }
        }

        
        private static string ExtractGuidFromLine(string line)
        {
            try
            {
                int g = line.IndexOf("guid: ", StringComparison.Ordinal);
                if (g < 0) return null;
                int start = g + "guid: ".Length;
                int end   = line.IndexOf(',', start);
                if (end < 0) end = line.IndexOf('}', start);
                if (end < 0) return null;
                return line.Substring(start, end - start).Trim();
            }
            catch
            {
                return null;
            }
        }

        
        
        
        
        
        
        
        private static void AtomicReplace(string targetPath, string tempPath)
        {
            if (!LongPathIO.TryAtomicReplace(tempPath, targetPath))
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] AtomicReplace 失敗: " +
                    $"temp='{Path.GetFileName(tempPath)}' → target='{Path.GetFileName(targetPath)}'。" +
                    "ファイルが別プロセスでロックされている可能性があります。");
            }
        }

        #endregion
    }
}
