










using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class ShaderListWriter
    {
        #region 定数

        
        public const string SubFolderName = "List of Shaders";

        
        public const string FileName = "Shaders.txt";

        #endregion

        #region 結果 DTO

        
        public class WriteResult
        {
            
            public bool Success { get; set; }

            
            public string OutputAssetPath { get; set; }

            
            public int ShaderCount { get; set; }

            
            public string ErrorMessage { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        public static WriteResult WriteList(
            string targetFolder,
            Dictionary<string, ShaderGuidFixer.ShaderMapping> mappings,
            VrcaFileInfo info,
            bool wasApplied)
        {
            var result = new WriteResult();

            if (mappings == null || mappings.Count == 0)
            {
                result.Success = true; 
                return result;
            }

            if (string.IsNullOrEmpty(targetFolder))
            {
                result.ErrorMessage = "targetFolder が空です。";
                return result;
            }

            
            
            
            
            var normalizedTarget = targetFolder.Replace('\\', '/').TrimEnd('/');
            if (normalizedTarget != "Assets" && !normalizedTarget.StartsWith("Assets/"))
            {
                result.ErrorMessage =
                    $"targetFolder が Assets/ 相対パスではありません: {targetFolder}";
                Debug.LogWarning($"[AvatarRecovery] {result.ErrorMessage}");
                return result;
            }

            try
            {
                
                var subFolderAssetPath = $"{normalizedTarget}/{SubFolderName}";
                EnsureUnityFolder(subFolderAssetPath);

                
                var content = BuildText(mappings, info, wasApplied);

                
                var absolutePath = GetAbsolutePath($"{subFolderAssetPath}/{FileName}");
                var utf8NoBom = new UTF8Encoding(encoderShouldEmitUTF8Identifier: false);
                File.WriteAllText(absolutePath, content, utf8NoBom);

                
                var unityAssetPath = $"{subFolderAssetPath}/{FileName}";
                AssetDatabase.ImportAsset(unityAssetPath, ImportAssetOptions.ForceUpdate);

                result.Success         = true;
                result.OutputAssetPath = unityAssetPath;
                result.ShaderCount     = mappings.Count;

                Debug.Log(
                    $"[AvatarRecovery] List of Shaders を出力: " +
                    $"{unityAssetPath} ({mappings.Count} 件)");
            }
            catch (Exception ex)
            {
                result.ErrorMessage = $"書き込みエラー: {ex.Message}";
                Debug.LogError($"[AvatarRecovery] ShaderListWriter 例外: {ex}");
            }

            return result;
        }

        #endregion

        #region テキスト構築

        
        
        
        
        private static string BuildText(
            Dictionary<string, ShaderGuidFixer.ShaderMapping> mappings,
            VrcaFileInfo info,
            bool wasApplied)
        {
            var sb = new StringBuilder();

            
            sb.AppendLine("================================================================");
            sb.AppendLine("  AvatarRecovery — 元バンドルに含まれていたシェーダー一覧");
            sb.AppendLine("================================================================");
            sb.AppendLine();
            sb.AppendLine($"復元元ファイル     : {info?.FileName ?? "(不明)"}");
            if (!string.IsNullOrEmpty(info?.BlueprintId))
                sb.AppendLine($"Blueprint ID       : {info.BlueprintId}");
            if (!string.IsNullOrEmpty(info?.UnityVersionString))
                sb.AppendLine($"Unity バージョン   : {info.UnityVersionString}");
            sb.AppendLine($"生成日時           : {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
            sb.AppendLine($"検出シェーダー数   : {mappings.Count}");
            sb.AppendLine($"自動置換モード     : {(wasApplied ? "実行済み (マテリアルを書き換え済み)" : "スキップ (設定で OFF)")}" );
            sb.AppendLine();

            
            int resolved   = 0;
            int unresolved = 0;
            foreach (var m in mappings.Values)
            {
                if (m.ResolvedShader != null) resolved++;
                else                          unresolved++;
            }
            sb.AppendLine("── 解決状況 ─────────────────────────────────────────────");
            sb.AppendLine($"  ✓ プロジェクト内で解決: {resolved} 件");
            sb.AppendLine($"  ⚠ 未解決 (フォールバック): {unresolved} 件");
            sb.AppendLine();

            
            sb.AppendLine("── シェーダー明細 ───────────────────────────────────────");
            sb.AppendLine();

            int index = 1;
            
            var sorted = new List<ShaderGuidFixer.ShaderMapping>(mappings.Values);
            sorted.Sort((a, b) =>
                string.Compare(a.OriginalName ?? "", b.OriginalName ?? "",
                    StringComparison.OrdinalIgnoreCase));

            foreach (var m in sorted)
            {
                var status = m.ResolvedShader != null ? "✓ 解決済み" : "⚠ 未解決";

                sb.AppendLine($"[{index:00}] {status}");
                sb.AppendLine($"      元シェーダー名 : {m.OriginalName ?? "(不明)"}");

                
                var stubGuid = ExtractGuid(m.OldKey);
                if (!string.IsNullOrEmpty(stubGuid))
                    sb.AppendLine($"      stub GUID      : {stubGuid}");

                if (m.ResolvedShader != null)
                {
                    sb.AppendLine($"      置換先         : {m.ResolvedShader.name}");

                    
                    var newGuid = ExtractGuidFromYaml(m.NewYaml);
                    if (!string.IsNullOrEmpty(newGuid))
                        sb.AppendLine($"      置換先 GUID    : {newGuid}");
                }
                else
                {
                    sb.AppendLine($"      置換先         : (プロジェクト内に見つからず)");
                    sb.AppendLine($"      ヒント         : 対応するシェーダーをインポートしてください");
                }

                if (wasApplied && m.ReplaceCount > 0)
                    sb.AppendLine($"      書き換え回数   : {m.ReplaceCount} 箇所 (.mat 内)");

                sb.AppendLine();
                index++;
            }

            
            sb.AppendLine("── 使い方 ───────────────────────────────────────────────");
            sb.AppendLine("  ・自動置換 ON: マテリアルの m_Shader は置換済みなので追加作業不要");
            sb.AppendLine("  ・自動置換 OFF: マテリアルはピンクのまま。この一覧を参考に");
            sb.AppendLine("                  手動でシェーダーを割り当て直してください。");
            sb.AppendLine("  ・未解決シェーダー: プロジェクトに該当シェーダーをインポートしてから");
            sb.AppendLine("                      再展開、または手動で代替シェーダーを選択。");
            sb.AppendLine();
            sb.AppendLine("================================================================");
            sb.AppendLine(" generated by AvatarRecovery");
            sb.AppendLine("================================================================");

            return sb.ToString();
        }

        
        private static string ExtractGuid(string key)
        {
            if (string.IsNullOrEmpty(key)) return null;
            const string marker = "guid: ";
            int idx = key.IndexOf(marker, StringComparison.Ordinal);
            if (idx < 0) return null;
            return key.Substring(idx + marker.Length).Trim();
        }

        
        private static string ExtractGuidFromYaml(string yaml)
        {
            if (string.IsNullOrEmpty(yaml)) return null;
            const string marker = "guid: ";
            int start = yaml.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return null;
            start += marker.Length;

            int end = yaml.IndexOf(',', start);
            if (end < 0) end = yaml.IndexOf('}', start);
            if (end < 0) return null;

            return yaml.Substring(start, end - start).Trim();
        }

        #endregion

        #region Unity フォルダ操作

        
        private static void EnsureUnityFolder(string unityPath)
        {
            var parts   = unityPath.Replace('\\', '/').Split('/');
            var current = parts[0]; 

            for (int i = 1; i < parts.Length; i++)
            {
                if (string.IsNullOrEmpty(parts[i])) continue;
                var next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                    AssetDatabase.CreateFolder(current, parts[i]);
                current = next;
            }
        }

        
        private static string GetAbsolutePath(string unityPath)
        {
            var projectRoot = Path.GetDirectoryName(Application.dataPath);
            return Path.GetFullPath(
                Path.Combine(projectRoot,
                    unityPath.Replace('/', Path.DirectorySeparatorChar)));
        }

        #endregion
    }
}
