









using System;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    
    public static class AvatarRecoveryEnvChecker
    {
        #region 定数

        private const string ExpectedUnityVersion = "2022.3.22f1";
        private const string ExpectedSdkVersionPrefix = "3.10.";
        private const int    RecommendedVramMb = 7500;
        private const string LogTag = "[SARS]";

        #endregion

        #region 公開 API

        
        
        
        public static void Run()
        {
            try
            {
                CheckUnityVersion();
                CheckVrcAvatarSdk();
                CheckVram();
                CheckAssetRipper();
            }
            catch (Exception ex)
            {
                
                Debug.LogWarning($"{LogTag} EnvChecker 内部例外: {ex.Message}");
            }
        }

        #endregion

        #region [1] Unity バージョン

        private static void CheckUnityVersion()
        {
            if (Application.unityVersion != ExpectedUnityVersion)
            {
                Debug.LogWarning(
                    $"{LogTag} Unity version mismatch: expected {ExpectedUnityVersion}, " +
                    $"got {Application.unityVersion}");
            }
        }

        #endregion

        #region [2] VRC Avatar SDK バージョン

        private static void CheckVrcAvatarSdk()
        {
            
            
            Type descType = null;
            try
            {
                descType = Type.GetType(
                    "VRC.SDK3.Avatars.Components.VRCAvatarDescriptor, VRC.SDK3A",
                    throwOnError: false);
                if (descType == null)
                {
                    
                    foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
                    {
                        descType = asm.GetType("VRC.SDK3.Avatars.Components.VRCAvatarDescriptor", false);
                        if (descType != null) break;
                    }
                }
            }
            catch {  }

            if (descType == null || descType.Assembly == null)
            {
                Debug.LogError($"{LogTag} VRC Avatar SDK が見つかりません");
                return; 
            }

            
            string detectedVersion = null;
            try
            {
                var manifestPath = Path.Combine(
                    Application.dataPath, "..", "Packages", "vpm-manifest.json");
                if (File.Exists(manifestPath))
                {
                    var content = File.ReadAllText(manifestPath);
                    
                    var match = Regex.Match(content,
                        @"""com\.vrchat\.avatars""\s*:\s*\{\s*""version""\s*:\s*""(\d+\.\d+\.\d+)""",
                        RegexOptions.Singleline);
                    if (!match.Success)
                    {
                        
                        match = Regex.Match(content,
                            @"""com\.vrchat\.avatars""\s*:\s*""(\d+\.\d+\.\d+)""");
                    }
                    if (match.Success)
                        detectedVersion = match.Groups[1].Value;
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"{LogTag} vpm-manifest.json 読取失敗: {ex.Message}");
            }

            if (string.IsNullOrEmpty(detectedVersion))
            {
                
                Debug.LogWarning($"{LogTag} VRC Avatar SDK バージョンを取得できませんでした");
                return;
            }

            
            if (!detectedVersion.StartsWith(ExpectedSdkVersionPrefix, StringComparison.Ordinal))
            {
                Debug.LogWarning(
                    $"{LogTag} VRC Avatar SDK {detectedVersion} 検出 " +
                    $"(動作検証は {ExpectedSdkVersionPrefix}x で実施)");

                EditorUtility.DisplayDialog(
                    "SARS バージョン警告",
                    $"VRC Avatar SDK {detectedVersion} を検出しました。\n" +
                    "本ツールは SDK 3.10.x で動作検証されています。\n" +
                    "一部機能が正常に動作しない可能性があります。",
                    "OK");
            }
            else
            {
                Debug.Log($"{LogTag} VRC Avatar SDK {detectedVersion} 検出 (OK)");
            }
        }

        #endregion

        #region [3] VRAM 簡易チェック

        private static void CheckVram()
        {
            int vram = SystemInfo.graphicsMemorySize;
            if (vram < RecommendedVramMb)
            {
                Debug.LogWarning(
                    $"{LogTag} VRAM {vram}MB 検出。" +
                    "推奨は 8GB 以上です。大きなアバターの抽出でメモリ不足が発生する可能性があります。");
            }
            else
            {
                Debug.Log($"{LogTag} VRAM {vram}MB 検出 (OK)");
            }
        }

        #endregion

        #region [4] AssetRipper.exe 検出チェック

        private static void CheckAssetRipper()
        {
            var path = AssetRipperBridge.FindAssetRipperExe();
            if (!string.IsNullOrEmpty(path))
            {
                Debug.Log($"{LogTag} AssetRipper.exe 検出: {path}");
            }
            else
            {
                Debug.LogWarning(
                    $"{LogTag} AssetRipper.exe が見つかりません。設定タブでパスを指定してください。");
            }
        }

        #endregion
    }
}
