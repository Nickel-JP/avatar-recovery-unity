using System;

using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    [InitializeOnLoad]
    internal sealed class AvatarRecoveryConsoleLogColorizer : ILogHandler
    {
        private const string AvatarRecoveryTag = "[AvatarRecovery]";
        private const string SarsTag = "[SARS]";
        private const string AvatarRecoveryColor = "#5ECFFF";
        private const string SarsColor = "#4CD964";
        private const string ToolNoticeColor = "#FFD84D";
        private const string ErrorColor = "#FF5A5A";

        private static readonly object SyncRoot = new object();

        private readonly ILogHandler _innerHandler;

        static AvatarRecoveryConsoleLogColorizer()
        {
            Install();
        }

        private AvatarRecoveryConsoleLogColorizer(ILogHandler innerHandler)
        {
            _innerHandler = innerHandler;
        }

        public void LogFormat(
            LogType logType,
            UnityEngine.Object context,
            string format,
            params object[] args)
        {
            if (_innerHandler == null) return;

            var colorizedFormat = ColorizeMessage(format, logType);
            var colorizedArgs = ColorizeArgs(args, logType) ?? Array.Empty<object>();
            _innerHandler.LogFormat(logType, context, colorizedFormat, colorizedArgs);
        }

        public void LogException(Exception exception, UnityEngine.Object context)
        {
            _innerHandler?.LogException(exception, context);
        }

        private static void Install()
        {
            lock (SyncRoot)
            {
                if (Debug.unityLogger.logHandler is AvatarRecoveryConsoleLogColorizer)
                    return;

                Debug.unityLogger.logHandler =
                    new AvatarRecoveryConsoleLogColorizer(Debug.unityLogger.logHandler);
            }
        }

        private static object[] ColorizeArgs(object[] args, LogType logType)
        {
            if (args == null || args.Length == 0) return args;

            object[] colorized = null;
            for (int i = 0; i < args.Length; i++)
            {
                if (!(args[i] is string text)) continue;

                var next = ColorizeMessage(text, logType);
                if (string.Equals(next, text, StringComparison.Ordinal)) continue;

                if (colorized == null)
                {
                    colorized = new object[args.Length];
                    Array.Copy(args, colorized, args.Length);
                }

                colorized[i] = next;
            }

            return colorized ?? args;
        }

        private static string ColorizeMessage(string message, LogType logType)
        {
            if (string.IsNullOrEmpty(message)) return message;
            if (IsAlreadyColorized(message)) return message;

            if (IsError(logType) && IsAvatarRecoveryMessage(message))
                return WrapColor(message, ErrorColor);

            if (IsToolNotice(message))
                return WrapColor(ColorizeTags(message), ToolNoticeColor);

            return ColorizeTags(message);
        }

        private static bool IsError(LogType logType)
        {
            return logType == LogType.Error ||
                   logType == LogType.Assert ||
                   logType == LogType.Exception;
        }

        private static bool IsAvatarRecoveryMessage(string message)
        {
            return message.IndexOf(AvatarRecoveryTag, StringComparison.Ordinal) >= 0 ||
                   message.IndexOf(SarsTag, StringComparison.Ordinal) >= 0 ||
                   message.IndexOf("AssetRipper", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool IsToolNotice(string message)
        {
            if (!IsAvatarRecoveryMessage(message)) return false;

            return Contains(message, "AssetRipper.exe") ||
                   Contains(message, "AssetRipper 出力 Assets を検出") ||
                   Contains(message, "AssetRipper + SARS 展開完了") ||
                   Contains(message, "VRC Avatar SDK") && Contains(message, "検出") ||
                   Contains(message, "VRAM") && Contains(message, "検出") ||
                   Contains(message, "FixShaders (自動置換") ||
                   Contains(message, "List of Shaders");
        }

        private static bool Contains(string message, string value)
        {
            return message.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool IsAlreadyColorized(string message)
        {
            return message.IndexOf("<color=", StringComparison.OrdinalIgnoreCase) >= 0 &&
                   (Contains(message, AvatarRecoveryColor) ||
                    Contains(message, SarsColor) ||
                    Contains(message, ToolNoticeColor) ||
                    Contains(message, ErrorColor));
        }

        private static string ColorizeTags(string message)
        {
            return message
                .Replace(SarsTag, WrapColor(SarsTag, SarsColor))
                .Replace(AvatarRecoveryTag, WrapColor(AvatarRecoveryTag, AvatarRecoveryColor));
        }

        private static string WrapColor(string text, string color)
        {
            return $"<color={color}>{text}</color>";
        }
    }
}
