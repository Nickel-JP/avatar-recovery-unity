







using System;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public static class VrcaExtractor
    {
        #region 定数

        
        
        
        
        
        
        private const string DefaultOutputFolder = "Assets/AvatarRecovery/Restored Avatar data";

        
        private const string DefaultPackageFolder = "AvatarRecovery_Packages";

        #endregion

        #region 展開結果 DTO

        
        public class ExtractionResult
        {
            
            public bool Success { get; set; }

            
            public string ErrorMessage { get; set; }

            
            public string PrefabAssetPath { get; set; }

            
            public string UnityPackagePath { get; set; }

            
            public GameObject ExtractedRoot { get; set; }

            
            public AssetRipperBridge.BridgeResult SarsBridgeResult { get; set; }

            
            public int RemovedMissingScenePrefabs { get; set; }

            
            
            
            
            public bool Cancelled { get; set; }
        }

        #endregion

        #region 公開 API

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        public static ExtractionResult Extract(
            VrcaFileInfo info,
            string outputFolder       = null,
            bool   placeInScene       = true,
            bool   exportPackage      = false,
            string packageOutputDir   = null,
            bool   remapShaders       = false,
            bool   useAssetRipper     = false,
            MissingScriptDeletePolicy missingScriptPolicy = MissingScriptDeletePolicy.Always,
            bool   autoReassignShaders = false)
        {
            
            var _sw_ = System.Diagnostics.Stopwatch.StartNew();
            try
            {
            
            var result = new ExtractionResult();

            
            if (useAssetRipper && AssetRipperBridge.IsAvailable())
            {
                return ExtractViaAssetRipper(
                    info, outputFolder, placeInScene, exportPackage,
                    packageOutputDir, remapShaders, missingScriptPolicy, autoReassignShaders);
            }

            if (info == null)
            {
                result.ErrorMessage = "VrcaFileInfo が null です。";
                return result;
            }

            if (!File.Exists(info.FilePath))
            {
                result.ErrorMessage = $"ファイルが存在しません: {info.FilePath}";
                return result;
            }

            
            if (!info.IsParsed)
                VrcaLoader.ParseHeader(info);

            if (!string.IsNullOrEmpty(info.ParseError))
            {
                result.ErrorMessage = info.ParseError;
                return result;
            }

            
            if (DisplayCancelableProgress(result,
                    "Step 1: AssetBundle を読み込み中...", 0.1f)) return result;

            AssetBundle bundle = null;
            try
            {
                if (!VrcaLoader.TryLoadBundle(info, out bundle) || bundle == null)
                {
                    result.ErrorMessage =
                        $"AssetBundle のロードに失敗しました。\n" +
                        $"検出バージョン: {info.UnityVersionString}\n" +
                        $"現在の Unity バージョンと一致しているか確認してください。";
                    return result;
                }

                
                if (DisplayCancelableProgress(result,
                        "Step 2: 出力フォルダーを準備中...", 0.2f)) return result;

                var targetFolder = BuildOutputFolder(info, outputFolder);
                EnsureFolderExists(targetFolder);

                
                if (DisplayCancelableProgress(result,
                        "Step 3: GameObject を展開中...", 0.4f)) return result;

                var prefabPath = ExtractGameObjects(bundle, info, targetFolder);
                result.PrefabAssetPath = prefabPath;

                
                if (remapShaders && !string.IsNullOrEmpty(prefabPath))
                {
                    if (DisplayCancelableProgress(result,
                            "Step 4: シェーダーを再割り当て中...", 0.65f)) return result;
                    ShaderRemapper.RemapInFolder(targetFolder);
                }

                
                if (placeInScene && !string.IsNullOrEmpty(prefabPath))
                {
                    if (DisplayCancelableProgress(result,
                            "Step 5: シーンへ配置中...", 0.75f)) return result;
                    result.RemovedMissingScenePrefabs =
                        CleanupMissingPrefabSceneInstances(info, prefabPath);
                    result.ExtractedRoot = PlaceInScene(prefabPath, info);
                }

                
                if (exportPackage && !string.IsNullOrEmpty(prefabPath))
                {
                    if (DisplayCancelableProgress(result,
                            "Step 6: UnityPackage を出力中...", 0.85f)) return result;
                    result.UnityPackagePath = ExportAsPackage(
                        targetFolder, info, packageOutputDir);
                }

                AssetDatabase.Refresh();
                result.Success = true;

                Debug.Log(
                    $"[AvatarRecovery] 展開完了: {info.DisplayName}\n" +
                    $"  出力先: {targetFolder}\n" +
                    $"  Prefab: {prefabPath}");
            }
            catch (Exception ex)
            {
                result.ErrorMessage = $"展開中にエラーが発生しました: {ex.Message}";
                Debug.LogError($"[AvatarRecovery] 展開エラー: {ex}");
            }
            finally
            {
                
                bundle?.Unload(false);
                EditorUtility.ClearProgressBar();
            }

            return result;
            
            }
            finally
            {
                
                _sw_.Stop();
                UnityEngine.Debug.Log(
                    $"[SARS][計測] VrcaExtractor.Extract: {_sw_.ElapsedMilliseconds}ms " +
                    $"({info?.FileName ?? "(unknown)"})");
            }
        }

        
        
        
        
        private static ExtractionResult ExtractViaAssetRipper(
            VrcaFileInfo info,
            string outputFolder,
            bool   placeInScene,
            bool   exportPackage,
            string packageOutputDir,
            bool   remapShaders,
            MissingScriptDeletePolicy missingScriptPolicy,
            bool   autoReassignShaders)
        {
            var result = new ExtractionResult();

            if (info == null || !File.Exists(info.FilePath))
            {
                result.ErrorMessage = "ファイルが存在しません。";
                return result;
            }

            var targetFolder = BuildOutputFolder(info, outputFolder);
            EnsureFolderExists(targetFolder);

            var bridgeResult = AssetRipperBridge.Extract(
                info, targetFolder,
                exePath: null,
                missingScriptPolicy: missingScriptPolicy,
                autoReassignShaders: autoReassignShaders);
            result.SarsBridgeResult = bridgeResult;

            
            if (bridgeResult.Cancelled)
            {
                result.Cancelled   = true;
                result.ErrorMessage = bridgeResult.ErrorMessage;
                return result;
            }

            if (!bridgeResult.Success)
            {
                result.ErrorMessage =
                    $"AssetRipper 展開失敗: {bridgeResult.ErrorMessage}";
                return result;
            }

            result.PrefabAssetPath = bridgeResult.PrefabPath;

            
            if (remapShaders)
                ShaderRemapper.RemapInFolder(targetFolder);

            
            if (!string.IsNullOrEmpty(result.PrefabAssetPath))
            {
                result.RemovedMissingScenePrefabs =
                    CleanupMissingPrefabSceneInstances(info, result.PrefabAssetPath);
            }

            
            if (placeInScene && !string.IsNullOrEmpty(result.PrefabAssetPath))
            {
                Debug.Log(
                    "[AvatarRecovery] AssetRipper + SARS パイプラインでは復元直後の Scene 自動配置をスキップしました。" +
                    "Project ウィンドウから Prefab を手動配置してください。");
            }

            
            if (exportPackage)
                result.UnityPackagePath = ExportAsPackage(targetFolder, info, packageOutputDir);

            AssetDatabase.Refresh();
            result.Success = true;
            return result;
        }

        
        
        
        
        
        
        
        private static int CleanupMissingPrefabSceneInstances(
            VrcaFileInfo info,
            string prefabAssetPath)
        {
            var targetNames = BuildSceneCleanupTargetNames(info, prefabAssetPath);
            if (targetNames.Count == 0)
                return 0;

            var targets = new List<GameObject>();
            var seenInstanceIds = new HashSet<int>();

            for (int sceneIndex = 0; sceneIndex < SceneManager.sceneCount; sceneIndex++)
            {
                var scene = SceneManager.GetSceneAt(sceneIndex);
                if (!scene.IsValid() || !scene.isLoaded)
                    continue;

                var roots = scene.GetRootGameObjects();
                foreach (var root in roots)
                    CollectMissingPrefabSceneInstances(
                        root,
                        targetNames,
                        targets,
                        seenInstanceIds);
            }

            foreach (var target in targets)
            {
                if (target == null)
                    continue;

                var sceneName = target.scene.IsValid() ? target.scene.name : "(Sceneなし)";
                var objectName = target.name;
                UnityEngine.Object.DestroyImmediate(target);
                Debug.Log(
                    $"[AvatarRecovery] Missing Prefab 化した旧Scene配置を削除: {objectName} ({sceneName})");
            }

            return targets.Count;
        }

        private static void CollectMissingPrefabSceneInstances(
            GameObject current,
            HashSet<string> targetNames,
            List<GameObject> targets,
            HashSet<int> seenInstanceIds)
        {
            if (current == null)
                return;

            if (IsMissingPrefabSceneInstance(current) &&
                IsRecoverySceneObjectName(current.name, targetNames))
            {
                var root = PrefabUtility.GetOutermostPrefabInstanceRoot(current) ?? current;
                if (root != null &&
                    IsRecoverySceneObjectName(root.name, targetNames) &&
                    seenInstanceIds.Add(root.GetInstanceID()))
                {
                    targets.Add(root);
                    return;
                }
            }

            var transform = current.transform;
            for (int i = 0; i < transform.childCount; i++)
                CollectMissingPrefabSceneInstances(
                    transform.GetChild(i).gameObject,
                    targetNames,
                    targets,
                    seenInstanceIds);
        }

        private static bool IsMissingPrefabSceneInstance(GameObject go)
        {
            if (go == null)
                return false;

            try
            {
                return PrefabUtility.GetPrefabInstanceStatus(go) ==
                       PrefabInstanceStatus.MissingAsset ||
                       PrefabUtility.GetPrefabAssetType(go) ==
                       PrefabAssetType.MissingAsset;
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] Prefab 接続状態の確認に失敗: {go.name} ({ex.Message})");
                return false;
            }
        }

        private static HashSet<string> BuildSceneCleanupTargetNames(
            VrcaFileInfo info,
            string prefabAssetPath)
        {
            var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            AddSceneCleanupTargetName(names, info?.DisplayName);
            AddSceneCleanupTargetName(names, info?.AvatarName);
            AddSceneCleanupTargetName(names, info?.BlueprintId);
            AddSceneCleanupTargetName(
                names,
                Path.GetFileNameWithoutExtension(info?.FileName ?? string.Empty));
            AddSceneCleanupTargetName(
                names,
                Path.GetFileNameWithoutExtension(prefabAssetPath ?? string.Empty));
            return names;
        }

        private static void AddSceneCleanupTargetName(HashSet<string> names, string name)
        {
            if (names == null || string.IsNullOrWhiteSpace(name))
                return;

            var normalized = NormalizeSceneObjectName(name);
            if (!string.IsNullOrEmpty(normalized))
                names.Add(normalized);
        }

        private static bool IsRecoverySceneObjectName(
            string objectName,
            HashSet<string> targetNames)
        {
            if (targetNames == null || targetNames.Count == 0)
                return false;

            var normalized = NormalizeSceneObjectName(objectName);
            return !string.IsNullOrEmpty(normalized) && targetNames.Contains(normalized);
        }

        private static string NormalizeSceneObjectName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return string.Empty;

            var normalized = name.Trim();
            var suffixStart = normalized.LastIndexOf(" (", StringComparison.Ordinal);
            if (suffixStart < 0 || !normalized.EndsWith(")", StringComparison.Ordinal))
                return normalized;

            var numberText = normalized.Substring(
                suffixStart + 2,
                normalized.Length - suffixStart - 3);
            return int.TryParse(numberText, out _)
                ? normalized.Substring(0, suffixStart).TrimEnd()
                : normalized;
        }

        #endregion

        #region 内部実装

        
        
        
        
        
        private static bool DisplayCancelableProgress(
            ExtractionResult result, string message, float progress)
        {
            bool cancelled = EditorUtility.DisplayCancelableProgressBar(
                "AvatarRecovery", message, progress);
            if (cancelled)
            {
                result.Cancelled   = true;
                result.ErrorMessage = $"ユーザーによりキャンセルされました ({message})";
                Debug.Log($"[AvatarRecovery] ユーザーキャンセル検出: {message}");
            }
            return cancelled;
        }

        
        
        
        
        
        
        
        
        
        
        
        private static string BuildOutputFolder(VrcaFileInfo info, string customFolder)
        {
            
            string baseFolder;
            if (string.IsNullOrWhiteSpace(customFolder))
            {
                baseFolder = DefaultOutputFolder;
            }
            else
            {
                var normalized = NormalizeToAssetsPath(customFolder);
                if (normalized == null)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] 出力先 '{customFolder}' は Unity プロジェクト外のため、" +
                        $"デフォルト '{DefaultOutputFolder}' にフォールバックします。");
                    baseFolder = DefaultOutputFolder;
                }
                else
                {
                    baseFolder = normalized;
                }
            }
            baseFolder = baseFolder.TrimEnd('/', '\\');

            
            var fileNameNoExt = Path.GetFileNameWithoutExtension(info.FileName ?? string.Empty);
            string subFolder;

            if (!string.IsNullOrEmpty(fileNameNoExt) &&
                !fileNameNoExt.Equals("__data", StringComparison.OrdinalIgnoreCase))
            {
                
                subFolder = fileNameNoExt;
            }
            else if (!string.IsNullOrEmpty(info.BlueprintId))
            {
                
                subFolder = info.BlueprintId;
            }
            else
            {
                subFolder = "Unknown";
            }

            
            subFolder = SanitizeAssetName(subFolder);

            return $"{baseFolder}/{subFolder}";
        }

        
        
        
        
        
        
        private static void EnsureFolderExists(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath)) return;

            
            var parts = assetPath.Replace('\\', '/').Split('/');
            if (parts.Length == 0 || !string.Equals(parts[0], "Assets", StringComparison.Ordinal))
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] EnsureFolderExists: Assets 相対パスではありません: {assetPath}");
                return;
            }

            var current = parts[0]; 
            for (int i = 1; i < parts.Length; i++)
            {
                if (string.IsNullOrEmpty(parts[i])) continue;
                var next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    var newGuid = AssetDatabase.CreateFolder(current, parts[i]);
                    if (string.IsNullOrEmpty(newGuid))
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] フォルダ作成失敗: {next} (親: {current})");
                        return;
                    }
                }
                current = next;
            }
        }

        
        
        
        
        
        private static string ExtractGameObjects(
            AssetBundle bundle,
            VrcaFileInfo info,
            string targetFolder)
        {
            
            UnityEngine.Object[] all;
            try
            {
                all = bundle.LoadAllAssets<UnityEngine.Object>();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AvatarRecovery] LoadAllAssets 失敗: {ex.Message}");
                return string.Empty;
            }

            if (all == null || all.Length == 0)
            {
                Debug.LogWarning($"[AvatarRecovery] バンドル内にアセットが見つかりません: {info.FilePath}");
                return string.Empty;
            }

            
            EnsureFolderExists(targetFolder + "/Textures");
            EnsureFolderExists(targetFolder + "/Meshes");
            EnsureFolderExists(targetFolder + "/Materials");
            EnsureFolderExists(targetFolder + "/Animations");

            
            var rootGo = FindRootGameObject(all, info);
            if (rootGo == null)
            {
                Debug.LogWarning($"[AvatarRecovery] ルート GameObject が見つかりません: {info.FilePath}");
                return string.Empty;
            }

            
            var usedMeshes    = CollectMeshes(rootGo);
            var usedMaterials = CollectMaterials(rootGo);
            var usedTextures  = CollectTextures(usedMaterials);

            
            foreach (var a in all)
            {
                if (a is Mesh m    && !usedMeshes.ContainsKey(m.GetInstanceID()))
                    usedMeshes[m.GetInstanceID()] = m;
                if (a is Material mat && !usedMaterials.ContainsKey(mat.GetInstanceID()))
                    usedMaterials[mat.GetInstanceID()] = mat;
                if (a is Texture2D t  && !usedTextures.ContainsKey(t.GetInstanceID()))
                    usedTextures[t.GetInstanceID()] = t;
            }

            
            var texSaved = new Dictionary<int, Texture2D>();
            foreach (var kv in usedTextures)
            {
                var saved = SaveAssetCopy<Texture2D>(
                    kv.Value, targetFolder + "/Textures", ".asset");
                if (saved != null) texSaved[kv.Key] = saved;
            }

            
            var meshSaved = new Dictionary<int, Mesh>();
            foreach (var kv in usedMeshes)
            {
                var saved = SaveAssetCopy<Mesh>(
                    kv.Value, targetFolder + "/Meshes", ".asset");
                if (saved != null) meshSaved[kv.Key] = saved;
            }

            
            var animClipSaved = new Dictionary<int, AnimationClip>();
            foreach (var a in all)
            {
                if (a is AnimationClip clip)
                {
                    
                    var saved = SaveAssetCopy<AnimationClip>(
                        clip, targetFolder + "/Animations", ".anim");
                    if (saved != null)
                        animClipSaved[clip.GetInstanceID()] = saved;
                }
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            
            var matSaved = new Dictionary<int, Material>();
            foreach (var kv in usedMaterials)
            {
                var saved = SaveMaterial(kv.Value, targetFolder + "/Materials", texSaved);
                if (saved != null) matSaved[kv.Key] = saved;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            
            
            EnsureFolderExists(targetFolder + "/Animators");
            EnsureFolderExists(targetFolder + "/ScriptableObjects");
            EnsureFolderExists(targetFolder + "/Misc");

            
            
            
            var allSaved = new Dictionary<int, UnityEngine.Object>();
            foreach (var kv in texSaved)       allSaved[kv.Key] = kv.Value;
            foreach (var kv in meshSaved)      allSaved[kv.Key] = kv.Value;
            foreach (var kv in animClipSaved)  allSaved[kv.Key] = kv.Value;  
            foreach (var kv in matSaved)       allSaved[kv.Key] = kv.Value;

            foreach (var a in all)
            {
                if (a == null) continue;
                if (allSaved.ContainsKey(a.GetInstanceID())) continue;
                if (a is GameObject)   continue; 
                if (a is Shader)       continue; 
                if (a is MonoScript)   continue; 

                var savedMisc = SaveMiscAsset(a, targetFolder);
                if (savedMisc != null) allSaved[a.GetInstanceID()] = savedMisc;
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            
            
            
            
            RedirectSavedAnimatorControllers(allSaved, targetFolder + "/Animators");

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            
            
            
            
            RedirectSavedScriptableObjects(allSaved, targetFolder);

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            
            
            var instance = UnityEngine.Object.Instantiate(rootGo);
            instance.name = rootGo.name;

            
            RedirectRendererAssets(instance, meshSaved, matSaved);

            
            
            RedirectAnimatorReferences(instance, allSaved);

            
            
            
            RedirectMonoScriptReferences(instance);

            
            
            RedirectAllObjectReferences(instance, allSaved);

            
            var prefabName = SanitizeAssetName(
                !string.IsNullOrEmpty(info.BlueprintId)
                    ? info.BlueprintId
                    : Path.GetFileNameWithoutExtension(info.FileName));

            var prefabPath = $"{targetFolder}/{prefabName}.prefab";

            GameObject savedPrefab = null;
            try
            {
                savedPrefab = PrefabUtility.SaveAsPrefabAsset(instance, prefabPath);
            }
            finally
            {
                
                UnityEngine.Object.DestroyImmediate(instance);
            }

            if (savedPrefab == null)
            {
                Debug.LogError($"[AvatarRecovery] Prefab 保存失敗: {prefabPath}");
                return string.Empty;
            }

            Debug.Log($"[AvatarRecovery] Prefab 保存: {prefabPath}  " +
                      $"(Mesh:{meshSaved.Count}, Mat:{matSaved.Count}, " +
                      $"Tex:{texSaved.Count}, Misc:{allSaved.Count})");
            return prefabPath;
        }

        

        
        private static GameObject FindRootGameObject(
            UnityEngine.Object[] all, VrcaFileInfo info)
        {
            
            foreach (var a in all)
            {
                if (a is GameObject go && go.GetComponent<Animator>() != null)
                    return go;
            }

            
            if (!string.IsNullOrEmpty(info.BlueprintId))
            {
                foreach (var a in all)
                {
                    if (a is GameObject go &&
                        go.name.IndexOf(info.BlueprintId,
                            StringComparison.OrdinalIgnoreCase) >= 0)
                        return go;
                }
            }

            
            GameObject best   = null;
            int        bestN  = -1;
            foreach (var a in all)
            {
                if (a is GameObject go)
                {
                    int n = go.GetComponentsInChildren<Transform>(true).Length;
                    if (n > bestN) { bestN = n; best = go; }
                }
            }
            return best;
        }

        private static Dictionary<int, Mesh> CollectMeshes(GameObject root)
        {
            var map = new Dictionary<int, Mesh>();
            foreach (var smr in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                if (smr.sharedMesh != null)
                    map[smr.sharedMesh.GetInstanceID()] = smr.sharedMesh;
            foreach (var mf in root.GetComponentsInChildren<MeshFilter>(true))
                if (mf.sharedMesh != null)
                    map[mf.sharedMesh.GetInstanceID()] = mf.sharedMesh;
            return map;
        }

        private static Dictionary<int, Material> CollectMaterials(GameObject root)
        {
            var map = new Dictionary<int, Material>();
            foreach (var r in root.GetComponentsInChildren<Renderer>(true))
                foreach (var mat in r.sharedMaterials)
                    if (mat != null)
                        map[mat.GetInstanceID()] = mat;
            return map;
        }

        private static Dictionary<int, Texture2D> CollectTextures(
            Dictionary<int, Material> materials)
        {
            var map = new Dictionary<int, Texture2D>();
            foreach (var mat in materials.Values)
            {
                if (mat == null) continue;
                try
                {
                    foreach (var prop in mat.GetTexturePropertyNames())
                    {
                        var tex = mat.GetTexture(prop) as Texture2D;
                        if (tex != null) map[tex.GetInstanceID()] = tex;
                    }
                }
                catch {  }
            }
            return map;
        }

        

        
        
        
        
        private static T SaveAssetCopy<T>(T asset, string folder, string ext)
            where T : UnityEngine.Object
        {
            if (asset == null) return null;

            var name = SanitizeAssetName(
                string.IsNullOrEmpty(asset.name) ? typeof(T).Name : asset.name);
            var path = BuildUniqueAssetPath(folder, name, ext);

            try
            {
                UnityEngine.Object copy;

                
                if (asset is Texture2D srcTex)
                    copy = CopyTexture(srcTex);
                else
                    copy = UnityEngine.Object.Instantiate(asset);

                if (copy == null) return null;
                copy.name = asset.name;

                AssetDatabase.CreateAsset(copy, path);
                return AssetDatabase.LoadAssetAtPath<T>(path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] 保存失敗 {typeof(T).Name} '{asset.name}': {ex.Message}");
                return null;
            }
        }

        
        
        
        private static Texture2D CopyTexture(Texture2D src)
        {
            if (src == null) return null;

            
            try
            {
                var copy = UnityEngine.Object.Instantiate(src);
                copy.name = src.name;
                return copy;
            }
            catch {  }

            
            
            if (src.width <= 0 || src.height <= 0)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] Texture2D 無効サイズ: {src.name} ({src.width}x{src.height})");
                return null;
            }

            
            RenderTexture rt = null;
            RenderTexture prev = null;
            bool prevSaved = false;
            try
            {
                rt = RenderTexture.GetTemporary(src.width, src.height, 0,
                    RenderTextureFormat.ARGB32);
                Graphics.Blit(src, rt);

                prev = RenderTexture.active;
                prevSaved = true;
                RenderTexture.active = rt;

                var dst = new Texture2D(src.width, src.height, TextureFormat.RGBA32, false);
                dst.ReadPixels(new Rect(0, 0, src.width, src.height), 0, 0);
                dst.Apply();

                dst.name = src.name;
                return dst;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] Texture2D コピー失敗: {src.name}: {ex.Message}");
                return null;
            }
            finally
            {
                
                if (prevSaved) RenderTexture.active = prev;
                if (rt != null) RenderTexture.ReleaseTemporary(rt);
            }
        }

        
        
        
        private static Material SaveMaterial(
            Material src, string folder, Dictionary<int, Texture2D> texSaved)
        {
            if (src == null) return null;

            var name = SanitizeAssetName(
                string.IsNullOrEmpty(src.name) ? "Material" : src.name);
            var path = BuildUniqueAssetPath(folder, name, ".mat");

            try
            {
                Material copy;
                var origShader = src.shader;
                bool shaderOk  = origShader != null &&
                                 !origShader.name.StartsWith("Hidden/");

                if (shaderOk)
                {
                    
                    copy = new Material(src);
                }
                else
                {
                    
                    var fallback = ShaderRemapper.FindBestShader()
                                   ?? Shader.Find("Standard");
                    copy = new Material(fallback);
                    copy.color = src.color;
                }
                copy.name = src.name;

                
                try
                {
                    foreach (var prop in src.GetTexturePropertyNames())
                    {
                        var tex = src.GetTexture(prop) as Texture2D;
                        if (tex == null) continue;

                        if (texSaved.TryGetValue(tex.GetInstanceID(), out var saved))
                            copy.SetTexture(prop, saved);
                        
                    }
                }
                catch {  }

                AssetDatabase.CreateAsset(copy, path);
                return AssetDatabase.LoadAssetAtPath<Material>(path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] Material 保存失敗 '{src.name}': {ex.Message}");
                return null;
            }
        }

        

        
        
        
        private static void RedirectRendererAssets(
            GameObject root,
            Dictionary<int, Mesh>     meshSaved,
            Dictionary<int, Material> matSaved)
        {
            foreach (var smr in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (smr.sharedMesh != null &&
                    meshSaved.TryGetValue(smr.sharedMesh.GetInstanceID(), out var m))
                    smr.sharedMesh = m;
                UpdateMaterials(smr, matSaved);
            }

            foreach (var mf in root.GetComponentsInChildren<MeshFilter>(true))
            {
                if (mf.sharedMesh != null &&
                    meshSaved.TryGetValue(mf.sharedMesh.GetInstanceID(), out var m))
                    mf.sharedMesh = m;
            }

            foreach (var r in root.GetComponentsInChildren<Renderer>(true))
            {
                if (r is SkinnedMeshRenderer) continue; 
                UpdateMaterials(r, matSaved);
            }
        }

        private static void UpdateMaterials(
            Renderer r, Dictionary<int, Material> matSaved)
        {
            if (matSaved.Count == 0) return;
            var mats    = r.sharedMaterials;
            bool changed = false;
            for (int i = 0; i < mats.Length; i++)
            {
                if (mats[i] != null &&
                    matSaved.TryGetValue(mats[i].GetInstanceID(), out var saved))
                {
                    mats[i]  = saved;
                    changed = true;
                }
            }
            if (changed) r.sharedMaterials = mats;
        }

        
        
        
        
        private static UnityEngine.Object SaveMiscAsset(
            UnityEngine.Object asset, string targetFolder)
        {
            if (asset == null) return null;

            
            if (asset is RuntimeAnimatorController ctrl)
            {
                EnsureFolderExists(targetFolder + "/Animators");
                return SaveAnimatorController(ctrl, targetFolder + "/Animators");
            }

            string folder, ext;

            if (asset is AvatarMask)
            {
                folder = targetFolder + "/AvatarMasks";
                ext    = ".mask";
                EnsureFolderExists(folder);
            }
            else if (asset is UnityEngine.Avatar)
            {
                folder = targetFolder + "/Avatars";
                ext    = ".asset";
                EnsureFolderExists(folder);
            }
            else if (asset is ScriptableObject)
            {
                
                folder = targetFolder + "/ScriptableObjects";
                ext    = ".asset";
            }
            else
            {
                folder = targetFolder + "/Misc";
                ext    = ".asset";
            }

            var name = SanitizeAssetName(
                string.IsNullOrEmpty(asset.name) ? asset.GetType().Name : asset.name);
            var path = BuildUniqueAssetPath(folder, name, ext);

            try
            {
                var copy = UnityEngine.Object.Instantiate(asset);
                copy.name = asset.name;
                AssetDatabase.CreateAsset(copy, path);
                return AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] {asset.GetType().Name} 保存失敗 '{asset.name}': {ex.Message}");
                return null;
            }
        }

        
        
        
        
        private static void RedirectAllObjectReferences(
            GameObject root,
            Dictionary<int, UnityEngine.Object> allSaved)
        {
            if (allSaved.Count == 0) return;

            foreach (var comp in root.GetComponentsInChildren<Component>(true))
            {
                if (comp == null) continue;

                try
                {
                    
                    using (var so = new SerializedObject(comp))
                    {
                        var prop    = so.GetIterator();
                        bool changed = false;

                        
                        while (prop.NextVisible(true))
                        {
                            if (prop.propertyType != SerializedPropertyType.ObjectReference) continue;

                            
                            
                            
                            var id = prop.objectReferenceInstanceIDValue;
                            if (id == 0) continue;

                            if (allSaved.TryGetValue(id, out var saved))
                            {
                                prop.objectReferenceValue = saved;
                                changed = true;
                            }
                        }

                        if (changed)
                            so.ApplyModifiedPropertiesWithoutUndo();
                    }
                }
                catch (Exception ex)
                {
                    
                    Debug.LogWarning(
                        $"[AvatarRecovery] 参照リダイレクト失敗 {comp.GetType().Name}: {ex.Message}");
                }
            }
        }

        
        
        
        
        
        private static RuntimeAnimatorController SaveAnimatorController(
            RuntimeAnimatorController ctrl, string folder)
        {
            if (ctrl == null) return null;

            var name = SanitizeAssetName(string.IsNullOrEmpty(ctrl.name) ? "Controller" : ctrl.name);
            var path = BuildUniqueAssetPath(folder, name, ".controller");

            
            if (!(ctrl is AnimatorController ac))
            {
                return SaveAssetCopy<RuntimeAnimatorController>(ctrl, folder, ".controller");
            }

            try
            {
                var copy = UnityEngine.Object.Instantiate(ac);
                copy.name = ac.name;
                AssetDatabase.CreateAsset(copy, path);

                
                foreach (var layer in copy.layers)
                {
                    if (layer.stateMachine != null)
                        EmbedStateMachine(layer.stateMachine, path);
                }

                AssetDatabase.SaveAssets();
                return AssetDatabase.LoadAssetAtPath<RuntimeAnimatorController>(path);
            }
            catch (Exception ex)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] AnimatorController 保存失敗 '{ac.name}': {ex.Message}");
                return null;
            }
        }

        
        private static void EmbedStateMachine(AnimatorStateMachine sm, string assetPath)
        {
            if (sm == null) return;

            AssetDatabase.AddObjectToAsset(sm, assetPath);

            foreach (var childSm in sm.stateMachines)
            {
                if (childSm.stateMachine != null)
                    EmbedStateMachine(childSm.stateMachine, assetPath);
            }

            foreach (var childState in sm.states)
            {
                var state = childState.state;
                if (state == null) continue;

                AssetDatabase.AddObjectToAsset(state, assetPath);

                
                if (state.motion is BlendTree bt)
                    EmbedBlendTree(bt, assetPath);

                foreach (var t in state.transitions)
                {
                    if (t != null) AssetDatabase.AddObjectToAsset(t, assetPath);
                }
            }

            foreach (var t in sm.anyStateTransitions)
                if (t != null) AssetDatabase.AddObjectToAsset(t, assetPath);

            foreach (var t in sm.entryTransitions)
                if (t != null) AssetDatabase.AddObjectToAsset(t, assetPath);
        }

        
        private static void EmbedBlendTree(BlendTree bt, string assetPath)
        {
            if (bt == null) return;
            AssetDatabase.AddObjectToAsset(bt, assetPath);

            foreach (var child in bt.children)
            {
                if (child.motion is BlendTree childBt)
                    EmbedBlendTree(childBt, assetPath);
            }
        }

        
        
        
        
        
        
        private static void RedirectSavedScriptableObjects(
            Dictionary<int, UnityEngine.Object> allSaved,
            string targetFolder)
        {
            if (allSaved.Count == 0) return;

            
            var guids = AssetDatabase.FindAssets("t:ScriptableObject", new[] { targetFolder });
            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var so_asset = AssetDatabase.LoadAssetAtPath<ScriptableObject>(path);
                if (so_asset == null) continue;

                try
                {
                    
                    using (var so = new SerializedObject(so_asset))
                    {
                        var prop    = so.GetIterator();
                        bool changed = false;

                        while (prop.NextVisible(true))
                        {
                            if (prop.propertyType != SerializedPropertyType.ObjectReference) continue;

                            var id = prop.objectReferenceInstanceIDValue;
                            if (id == 0) continue;

                            if (allSaved.TryGetValue(id, out var saved))
                            {
                                prop.objectReferenceValue = saved;
                                changed = true;
                            }
                        }

                        if (changed)
                        {
                            so.ApplyModifiedPropertiesWithoutUndo();
                            EditorUtility.SetDirty(so_asset);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] ScriptableObject 参照リダイレクト失敗 '{path}': {ex.Message}");
                }
            }
        }

        
        
        
        
        
        
        
        
        
        
        
        
        private static void RedirectMonoScriptReferences(GameObject root)
        {
            foreach (var mb in root.GetComponentsInChildren<MonoBehaviour>(true))
            {
                
                if (mb == null) continue;

                try
                {
                    
                    var projectMs = MonoScript.FromMonoBehaviour(mb);
                    if (projectMs == null) continue;

                    
                    using (var so = new SerializedObject(mb))
                    {
                        var scriptProp = so.FindProperty("m_Script");
                        if (scriptProp == null) continue;

                        
                        if (scriptProp.objectReferenceValue == (UnityEngine.Object)projectMs) continue;

                        
                        scriptProp.objectReferenceValue = projectMs;
                        so.ApplyModifiedPropertiesWithoutUndo();
                    }
                }
                catch (Exception ex)
                {
                    
                    Debug.LogWarning(
                        $"[AvatarRecovery] MonoScript リダイレクト失敗 ({mb.GetType().Name}): " +
                        ex.Message);
                }
            }
        }

        
        
        
        
        
        
        
        private static void RedirectSavedAnimatorControllers(
            Dictionary<int, UnityEngine.Object> allSaved, string animatorsFolder)
        {
            if (allSaved.Count == 0) return;
            if (!AssetDatabase.IsValidFolder(animatorsFolder)) return;

            var guids = AssetDatabase.FindAssets("t:AnimatorController", new[] { animatorsFolder });
            foreach (var guid in guids)
            {
                var path    = AssetDatabase.GUIDToAssetPath(guid);
                
                var objects = AssetDatabase.LoadAllAssetsAtPath(path);

                foreach (var obj in objects)
                {
                    if (obj == null) continue;

                    try
                    {
                        
                        using (var so = new SerializedObject(obj))
                        {
                            var prop    = so.GetIterator();
                            bool changed = false;

                            while (prop.NextVisible(true))
                            {
                                if (prop.propertyType != SerializedPropertyType.ObjectReference) continue;

                                var id = prop.objectReferenceInstanceIDValue;
                                if (id == 0) continue;

                                if (allSaved.TryGetValue(id, out var saved))
                                {
                                    prop.objectReferenceValue = saved;
                                    changed = true;
                                }
                            }

                            if (changed)
                            {
                                so.ApplyModifiedPropertiesWithoutUndo();
                                EditorUtility.SetDirty(obj);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.LogWarning(
                            $"[AvatarRecovery] AnimatorController リダイレクト失敗 " +
                            $"'{obj.name}': {ex.Message}");
                    }
                }
            }
        }

        
        
        
        
        
        
        private static void RedirectAnimatorReferences(
            GameObject root,
            Dictionary<int, UnityEngine.Object> allSaved)
        {
            foreach (var animator in root.GetComponentsInChildren<Animator>(true))
            {
                
                var ctrl = animator.runtimeAnimatorController;
                if (ctrl != null &&
                    allSaved.TryGetValue(ctrl.GetInstanceID(), out var savedCtrl) &&
                    savedCtrl is RuntimeAnimatorController rac)
                {
                    animator.runtimeAnimatorController = rac;
                }

                
                var avatar = animator.avatar;
                if (avatar != null &&
                    allSaved.TryGetValue(avatar.GetInstanceID(), out var savedAvatar) &&
                    savedAvatar is UnityEngine.Avatar av)
                {
                    animator.avatar = av;
                }
            }
        }

        
        private static GameObject PlaceInScene(string prefabAssetPath, VrcaFileInfo info)
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(prefabAssetPath);
            if (prefab == null)
            {
                Debug.LogWarning($"[AvatarRecovery] Prefab のロード失敗: {prefabAssetPath}");
                return null;
            }

            var instance = PrefabUtility.InstantiatePrefab(prefab) as GameObject;
            if (instance == null) return null;

            instance.name = info.DisplayName;
            instance.transform.position = Vector3.zero;
            instance.transform.rotation = Quaternion.identity;

            
            Selection.activeGameObject = instance;

            Debug.Log($"[AvatarRecovery] シーンに配置: {instance.name}");
            return instance;
        }

        
        
        
        
        
        
        
        private static string NormalizeToAssetsPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return null;

            path = path.Replace('\\', '/').TrimEnd('/');

            if (path == "Assets" || path.StartsWith("Assets/"))
                return path;

            try
            {
                var dataPath    = Application.dataPath.Replace('\\', '/').TrimEnd('/');
                var projectRoot = Path.GetDirectoryName(dataPath)
                    ?.Replace('\\', '/')?.TrimEnd('/');

                if (!string.IsNullOrEmpty(projectRoot))
                {
                    if (path.Equals(projectRoot, StringComparison.OrdinalIgnoreCase))
                        return "Assets";
                    if (path.StartsWith(projectRoot + "/", StringComparison.OrdinalIgnoreCase))
                        return path.Substring(projectRoot.Length + 1);
                }
            }
            catch {  }

            return null;
        }

        
        private static string ExportAsPackage(
            string assetFolder,
            VrcaFileInfo info,
            string packageOutputDir)
        {
            
            var normalized = NormalizeToAssetsPath(assetFolder);
            if (normalized == null)
            {
                Debug.LogError(
                    $"[AvatarRecovery] .unitypackage 出力スキップ — " +
                    $"出力先フォルダが Unity プロジェクトの Assets/ 以下ではありません: {assetFolder}");
                return string.Empty;
            }

            
            if (!AssetDatabase.IsValidFolder(normalized))
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] .unitypackage 出力スキップ — " +
                    $"フォルダが AssetDatabase に存在しません: {normalized}");
                return string.Empty;
            }

            
            
            var assetGuids = AssetDatabase.FindAssets(string.Empty, new[] { normalized });
            if (assetGuids == null || assetGuids.Length == 0)
            {
                Debug.LogWarning(
                    $"[AvatarRecovery] .unitypackage 出力スキップ — " +
                    $"フォルダ内にアセットが見つかりません (インポート待ちの可能性): {normalized}");
                return string.Empty;
            }

            
            
            AssetDatabase.Refresh(ImportAssetOptions.ForceSynchronousImport);

            var outputDir = string.IsNullOrWhiteSpace(packageOutputDir)
                ? Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                    DefaultPackageFolder)
                : packageOutputDir;

            if (!Directory.Exists(outputDir))
                Directory.CreateDirectory(outputDir);

            var id = SanitizeAssetName(
                !string.IsNullOrEmpty(info.BlueprintId)
                    ? info.BlueprintId
                    : Path.GetFileNameWithoutExtension(info.FileName));

            var packagePath = Path.Combine(outputDir, $"{id}.unitypackage");

            try
            {
                AssetDatabase.ExportPackage(
                    normalized,
                    packagePath,
                    ExportPackageOptions.Recurse | ExportPackageOptions.IncludeDependencies);

                
                
                if (!File.Exists(packagePath))
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] .unitypackage 出力失敗 — " +
                        $"ファイルが生成されませんでした: {packagePath}\n" +
                        $"AssetDatabase 内のアセット数: {assetGuids.Length}, フォルダ: {normalized}");
                    return string.Empty;
                }

                Debug.Log($"[AvatarRecovery] UnityPackage 出力: {packagePath} " +
                          $"(アセット数: {assetGuids.Length})");
                return packagePath;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AvatarRecovery] UnityPackage 出力エラー: {ex.Message}");
                return string.Empty;
            }
        }

        
        private static string SanitizeAssetName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "Unknown";

            var invalid = Path.GetInvalidFileNameChars();
            var sb = new System.Text.StringBuilder();
            foreach (var c in name)
            {
                if (Array.IndexOf(invalid, c) < 0)
                    sb.Append(c);
                else
                    sb.Append('_');
            }
            return sb.Length > 0 ? sb.ToString() : "Unknown";
        }

        private static string BuildUniqueAssetPath(string folder, string name, string extension)
        {
            var safeName = SanitizeAssetName(name);
            var safeExtension = extension ?? ".asset";
            var path = $"{folder}/{safeName}{safeExtension}";
            return AssetDatabase.GenerateUniqueAssetPath(path);
        }

        #endregion
    }
}
