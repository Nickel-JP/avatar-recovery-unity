





using System;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    public static class VrcaLoader
    {
        #region 定数

        
        private static readonly byte[] MagicUnityFS =
            Encoding.ASCII.GetBytes("UnityFS\0");

        
        private static readonly byte[] MagicUnityRaw =
            Encoding.ASCII.GetBytes("UnityRaw");

        
        private const string Version2019 = "2019.4.31f1";
        private const string Version2022_6  = "2022.3.6f1";
        private const string Version2022_22 = "2022.3.22f1";

        
        private const int VersionSearchStart = 0;
        private const int VersionSearchLength = 512;

        #endregion

        #region 公開 API

        
        
        
        
        
        
        public static bool ParseHeader(VrcaFileInfo info)
        {
            
            if (info == null)
            {
                Debug.LogWarning("[AvatarRecovery] VrcaLoader.ParseHeader: info が null です。");
                return false;
            }

            if (!File.Exists(info.FilePath))
            {
                info.ParseError = "ファイルが存在しません。";
                return false;
            }

            try
            {
                using (var fs = File.OpenRead(info.FilePath))
                {
                    
                    var targetLength = (int)Math.Min(VersionSearchLength, fs.Length);
                    if (targetLength <= 0)
                    {
                        info.ParseError = "ファイルが空です。";
                        info.IsParsed = false;
                        return false;
                    }

                    var buffer = new byte[targetLength];
                    int read = 0;
                    while (read < targetLength)
                    {
                        int n = fs.Read(buffer, read, targetLength - read);
                        if (n <= 0) break;
                        read += n;
                    }

                    
                    if (read < buffer.Length)
                    {
                        Array.Resize(ref buffer, read);
                    }

                    
                    if (!StartsWithMagic(buffer))
                    {
                        info.ParseError = IsEncryptedFile(info.FilePath)
                            ? "暗号化されたファイルです。最新VRChatのキャッシュは復元できません。"
                            : "Unity AssetBundle 形式ではありません。";
                        info.IsParsed = false;
                        return false;
                    }

                    
                    var versionStr = ExtractUnityVersion(buffer);
                    info.UnityVersionString = versionStr;
                    info.UnityVersion = ParseUnityVersion(versionStr);
                    info.IsParsed = true;
                    info.ParseError = null;
                }

                return true;
            }
            catch (Exception ex)
            {
                info.ParseError = $"ヘッダー解析エラー: {ex.Message}";
                info.IsParsed = false;
                return false;
            }
        }

        
        
        
        
        
        
        
        
        public static bool TryLoadBundle(VrcaFileInfo info, out AssetBundle bundle)
        {
            bundle = null;

            if (info == null || !File.Exists(info.FilePath))
            {
                Debug.LogWarning("[AvatarRecovery] ファイルが存在しません。");
                return false;
            }

            if (!info.IsParsed)
            {
                ParseHeader(info);
            }

            if (!string.IsNullOrEmpty(info.ParseError))
            {
                Debug.LogWarning($"[AvatarRecovery] 解析エラーのためロードをスキップ: {info.ParseError}");
                return false;
            }

            try
            {
                
                
                var existingBundle = AssetBundle.GetAllLoadedAssetBundles();
                var targetName = Path.GetFileName(info.FilePath);
                foreach (var b in existingBundle)
                {
                    if (b != null && b.name == targetName)
                    {
                        b.Unload(false);
                        
                    }
                }

                
                
                
                
                {
                    const int maxRetry = 3;
                    const int retryDelayMs = 500;
                    for (int i = 1; i <= maxRetry; i++)
                    {
                        try
                        {
                            using (System.IO.File.OpenRead(info.FilePath)) { } 
                            break; 
                        }
                        catch (System.IO.IOException ex)
                        {
                            if (i == maxRetry)
                            {
                                Debug.LogError(
                                    $"[SARS] ファイルアクセス不可({maxRetry}回リトライ失敗): " +
                                    $"{info.FilePath}\n{ex.Message}");
                                EditorUtility.DisplayDialog(
                                    "SARS 読み込みエラー",
                                    "ファイルにアクセスできません。\n\n" +
                                    $"パス: {info.FilePath}\n\n" +
                                    "VRChat が起動中の場合は終了してから再試行してください。",
                                    "OK");
                                throw; 
                            }
                            Debug.LogWarning(
                                $"[SARS] ファイルロック検出 リトライ {i}/{maxRetry}: {info.FilePath}");
                            System.Threading.Thread.Sleep(retryDelayMs);
                        }
                    }
                }

                
                bundle = AssetBundle.LoadFromFile(info.FilePath);

                if (bundle == null)
                {
                    
                    
                    
                    Debug.Log("[AvatarRecovery] 通常ロード失敗 — バージョンパッチを試みます...");
                    bundle = TryLoadWithVersionPatch(info.FilePath);
                }

                if (bundle == null)
                {
                    Debug.LogWarning(
                        $"[AvatarRecovery] ロード失敗: {info.FilePath}\n" +
                        $"バンドルバージョン: {info.UnityVersionString}\n" +
                        $"現在の Unity: {Application.unityVersion}\n" +
                        "メジャーバージョンが大きく異なる場合(2019↔2022等)は復元できません。");

                    
                    
                    Debug.LogError(
                        $"[SARS] AssetBundle.LoadFromFile が null を返しました: {info.FilePath}");
                    EditorUtility.DisplayDialog(
                        "SARS 読み込みエラー",
                        "ファイルの読み込みに失敗しました。\n\n" +
                        $"パス: {info.FilePath}\n\n" +
                        "ファイルが破損している、VRChat キャッシュ形式に対応していない、\n" +
                        "または Unity メジャーバージョンが大きく異なる可能性があります。\n" +
                        "VRChat のキャッシュクリア後に再度お試しください。",
                        "OK");

                    return false;
                }

                
                if (string.IsNullOrEmpty(info.BlueprintId))
                {
                    var bundleName = bundle.name;
                    if (bundleName.StartsWith("avtr_") || bundleName.StartsWith("wrld_"))
                        info.BlueprintId = bundleName;
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AvatarRecovery] AssetBundle ロードエラー: {ex.Message}");
                return false;
            }
        }

        
        
        
        public static string[] GetAssetNames(AssetBundle bundle)
        {
            if (bundle == null) return Array.Empty<string>();
            return bundle.GetAllAssetNames();
        }

        
        
        
        public static GameObject[] LoadAllGameObjects(AssetBundle bundle)
        {
            if (bundle == null) return Array.Empty<GameObject>();

            try
            {
                return bundle.LoadAllAssets<GameObject>();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[AvatarRecovery] GameObject ロードエラー: {ex.Message}");
                return Array.Empty<GameObject>();
            }
        }

        #endregion

        #region ヘッダー解析

        
        
        
        
        internal static bool IsEncryptedFile(string filePath)
        {
            if (!File.Exists(filePath)) return false;
            try
            {
                using (var fs = File.OpenRead(filePath))
                {
                    var header = new byte[8];
                    if (fs.Read(header, 0, 8) < 8) return true;
                    var magic = System.Text.Encoding.ASCII.GetString(header);
                    return !(magic.StartsWith("UnityFS") ||
                             magic.StartsWith("UnityRaw") ||
                             magic.StartsWith("UnityWeb") ||
                             magic.StartsWith("Unity"));
                }
            }
            catch { return true; }
        }

        
        private static bool StartsWithMagic(byte[] buffer)
        {
            if (buffer.Length < 8) return false;

            
            bool isUnityFS = true;
            for (int i = 0; i < MagicUnityFS.Length && i < buffer.Length; i++)
            {
                if (buffer[i] != MagicUnityFS[i]) { isUnityFS = false; break; }
            }
            if (isUnityFS) return true;

            
            bool isUnityRaw = true;
            for (int i = 0; i < MagicUnityRaw.Length && i < buffer.Length; i++)
            {
                if (buffer[i] != MagicUnityRaw[i]) { isUnityRaw = false; break; }
            }
            return isUnityRaw;
        }

        
        
        
        
        
        private static string ExtractUnityVersion(byte[] buffer)
        {
            
            
            int start = 8; 
            while (start < buffer.Length - 1)
            {
                
                int end = Array.IndexOf(buffer, (byte)0, start);
                if (end < 0) end = buffer.Length;

                if (end > start)
                {
                    var str = Encoding.ASCII.GetString(buffer, start, end - start);

                    
                    if (str.Length > 4 && str.StartsWith("20") &&
                        str.Contains(".") && !str.Contains(" "))
                    {
                        return str;
                    }
                }

                start = end + 1;
            }

            return string.Empty;
        }

        
        private static VrcaUnityVersion ParseUnityVersion(string versionStr)
        {
            if (string.IsNullOrEmpty(versionStr))
                return VrcaUnityVersion.Unknown;

            if (versionStr.Contains("2019.4"))
                return VrcaUnityVersion.Unity2019;

            if (versionStr.Contains("2022.3"))
            {
                
                return VrcaUnityVersion.Unity2022_22;
            }

            return VrcaUnityVersion.Unknown;
        }

        #endregion

        #region バージョンパッチ

        
        
        
        
        
        
        private static AssetBundle TryLoadWithVersionPatch(string filePath)
        {
            try
            {
                var original = File.ReadAllBytes(filePath);
                var patched  = PatchBundleVersion(original);

                if (patched == null)
                {
                    Debug.LogWarning("[AvatarRecovery] バージョンパッチを適用できませんでした。");
                    return null;
                }

                
                var bundle = AssetBundle.LoadFromMemory(patched);

                if (bundle != null)
                    Debug.Log("[AvatarRecovery] バージョンパッチ成功 — AssetBundle ロード完了");
                else
                    Debug.LogWarning("[AvatarRecovery] バージョンパッチ後もロードに失敗しました。");

                return bundle;
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] バージョンパッチ中にエラー: {ex.Message}");
                return null;
            }
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        private static byte[] PatchBundleVersion(byte[] original)
        {
            if (original == null || original.Length < 20) return null;

            
            if (Encoding.ASCII.GetString(original, 0, 7) != "UnityFS")
            {
                Debug.LogWarning("[AvatarRecovery] PatchBundleVersion: UnityFS マジック不一致");
                return null;
            }

            var targetVersion = Application.unityVersion;
            var targetBytes   = Encoding.ASCII.GetBytes(targetVersion);

            int pos = 12; 

            
            while (pos < original.Length && original[pos] != 0) pos++;
            if (pos >= original.Length) return null;
            pos++; 

            
            int revStart   = pos;
            while (pos < original.Length && original[pos] != 0) pos++;
            if (pos >= original.Length) return null;
            int revNullPos = pos; 
            pos++;

            var origVersion = Encoding.ASCII.GetString(
                original, revStart, revNullPos - revStart);

            
            if (origVersion == targetVersion)
            {
                Debug.Log("[AvatarRecovery] PatchBundleVersion: バージョンが一致 — パッチ不要");
                return null;
            }

            
            
            
            var origParts   = origVersion.Split('.');
            var targetParts = targetVersion.Split('.');
            bool sameFamily = origParts.Length >= 2 && targetParts.Length >= 2 &&
                              origParts[0] == targetParts[0] &&
                              origParts[1] == targetParts[1];

            if (!sameFamily)
            {
                Debug.LogError(
                    $"[AvatarRecovery] メジャーバージョン差異のためパッチを中止: " +
                    $"{origVersion} → {targetVersion}\n" +
                    "アセットフォーマットが互換性が無いため、文字列パッチではロードできません。\n" +
                    $"対応バージョンの Unity プロジェクト ({origParts[0]}.{origParts[1]}.x) で展開してください。");
                return null;
            }

            Debug.Log($"[AvatarRecovery] バージョンパッチ: {origVersion} → {targetVersion}");

            
            int oldRevLen = revNullPos - revStart + 1; 
            int newRevLen = targetBytes.Length + 1;    
            int delta     = newRevLen - oldRevLen;

            var patched = new byte[original.Length + delta];

            
            Buffer.BlockCopy(original, 0, patched, 0, revStart);

            
            Buffer.BlockCopy(targetBytes, 0, patched, revStart, targetBytes.Length);
            patched[revStart + targetBytes.Length] = 0;

            
            int srcAfter = revNullPos + 1;
            int dstAfter = revStart + newRevLen;
            Buffer.BlockCopy(
                original, srcAfter,
                patched,  dstAfter,
                original.Length - srcAfter);

            
            long newFileSize = patched.Length;
            for (int i = 0; i < 8; i++)
                patched[dstAfter + 7 - i] = (byte)(newFileSize >> (8 * i));

            return patched;
        }

        #endregion
    }
}

