




using System;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    public enum VrcaFileType
    {
        
        Avatar,

        
        World,

        
        Unknown
    }

    
    public enum VrcaPlatform
    {
        
        PC,

        
        Quest,

        
        Unknown
    }

    
    public enum VrcaUnityVersion
    {
        
        Unity2019,

        
        Unity2022_6,

        
        Unity2022_22,

        
        Unknown
    }

    
    
    
    
    public class VrcaFileInfo
    {
        #region ファイル情報

        
        public string FilePath { get; set; }

        
        public string FileName { get; set; }

        
        public long FileSize { get; set; }

        
        public DateTime LastModified { get; set; }

        
        public VrcaFileType FileType { get; set; }

        
        public VrcaPlatform Platform { get; set; }

        #endregion

        #region VRChat メタデータ（AssetBundle ヘッダー解析後に設定）

        
        
        
        
        public string BlueprintId { get; set; }

        
        
        
        
        public string AvatarName { get; set; }

        
        
        
        
        public string UnityVersionString { get; set; }

        
        public VrcaUnityVersion UnityVersion { get; set; }

        
        public bool IsParsed { get; set; }

        
        public string ParseError { get; set; }

        
        
        
        public bool IsFromCache { get; set; }

        
        
        
        public string ThumbnailUrl { get; set; }

        #endregion

        #region 表示用プロパティ

        
        public float FileSizeMb => FileSize / (1024f * 1024f);

        
        public string FileSizeDisplay
        {
            get
            {
                if (FileSize < 1024)         return $"{FileSize} B";
                if (FileSize < 1024 * 1024)  return $"{FileSize / 1024f:F1} KB";
                return $"{FileSizeMb:F1} MB";
            }
        }

        
        public string FileTypeDisplay => FileType == VrcaFileType.Avatar ? "アバター" :
                                         FileType == VrcaFileType.World  ? "ワールド" : "不明";

        
        public string PlatformDisplay => Platform == VrcaPlatform.PC    ? "PC" :
                                         Platform == VrcaPlatform.Quest ? "Quest" : "不明";

        
        public string DisplayName => !string.IsNullOrEmpty(AvatarName)  ? AvatarName :
                                     !string.IsNullOrEmpty(BlueprintId) ? BlueprintId :
                                     FileName;

        #endregion

        #region ファクトリメソッド

        
        
        
        
        public static VrcaFileInfo FromPath(string filePath)
        {
            var info = new System.IO.FileInfo(filePath);
            var ext  = info.Extension.ToLowerInvariant();
            var name = info.Name.ToLowerInvariant();

            var fileType = ext == ".vrca" ? VrcaFileType.Avatar :
                           ext == ".vrcw" ? VrcaFileType.World  : VrcaFileType.Unknown;

            
            var platform = name.Contains("_pc")    ? VrcaPlatform.PC    :
                           name.Contains("_quest") ? VrcaPlatform.Quest :
                           name.Contains("android") ? VrcaPlatform.Quest : VrcaPlatform.Unknown;

            return new VrcaFileInfo
            {
                FilePath     = filePath,
                FileName     = info.Name,
                FileSize     = info.Exists ? info.Length : 0,
                LastModified = info.Exists ? info.LastWriteTime : DateTime.MinValue,
                FileType     = fileType,
                Platform     = platform,
                IsParsed     = false
            };
        }

        #endregion
    }
}
