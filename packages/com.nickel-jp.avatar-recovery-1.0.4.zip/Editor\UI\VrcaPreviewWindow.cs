

















using System.Linq;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public sealed class VrcaPreviewWindow : EditorWindow
    {
        #region 定数

        private const string WindowTitle     = "VRCA Preview";
        private const float  MinWindowWidth  = 420f;
        private const float  MinWindowHeight = 320f;

        
        private const float  DefaultPitch    = 15f;

        
        private const float  DefaultYaw      = -145f;

        #endregion

        #region 状態

        
        [System.NonSerialized] private VrcaFileInfo         _info;
        [System.NonSerialized] private AssetBundle          _bundle;
        [System.NonSerialized] private GameObject           _previewRoot;
        [System.NonSerialized] private PreviewRenderUtility _preview;

        
        
        
        
        [System.NonSerialized] private Material _skyboxMaterial;

        
        private Vector2 _cameraAngle   = new Vector2(DefaultPitch, DefaultYaw);
        private float   _cameraDistance = 3f;
        private Vector3 _cameraTarget   = Vector3.zero;

        
        private enum DragMode { None, Orbit, Pan }
        private DragMode _dragMode   = DragMode.None;
        
        private int      _dragButton = -1;

        
        [System.NonSerialized] private int _rendererCount;
        [System.NonSerialized] private int _vertexCount;
        [System.NonSerialized] private int _materialCount;
        [System.NonSerialized] private int _boneCount;
        [System.NonSerialized] private int _remappedShaderCount;
        [System.NonSerialized] private string _statusMessage;

        #endregion

        #region 公開 API

        
        
        
        public static void Open(VrcaFileInfo info)
        {
            if (info == null || string.IsNullOrEmpty(info.FilePath))
            {
                Debug.LogWarning("[AvatarRecovery] VrcaPreviewWindow.Open: info が空のため開けません。");
                return;
            }

            var window = GetWindow<VrcaPreviewWindow>(
                utility: false,
                title: $"{WindowTitle} — {System.IO.Path.GetFileName(info.FilePath)}",
                focus: true);
            window.minSize = new Vector2(MinWindowWidth, MinWindowHeight);
            window.LoadVrca(info);
            window.Show();
        }

        #endregion

        #region Unity コールバック

        private void OnEnable()
        {
            
            EnsurePreviewUtility();

            
            LoadSkyboxPreference();

            
            
            
            
            AssemblyReloadEvents.beforeAssemblyReload += HandleBeforeAssemblyReload;
        }

        private void OnDisable()
        {
            AssemblyReloadEvents.beforeAssemblyReload -= HandleBeforeAssemblyReload;

            CleanupPreview();
            if (_preview != null)
            {
                _preview.Cleanup();
                _preview = null;
            }
        }

        
        
        
        
        private void HandleBeforeAssemblyReload()
        {
            CleanupPreview();
        }

        private void OnGUI()
        {
            EnsurePreviewUtility();

            DrawToolbar();

            if (_previewRoot == null)
            {
                EditorGUILayout.HelpBox(
                    string.IsNullOrEmpty(_statusMessage)
                        ? "VRCA ファイルをロードしてください。"
                        : _statusMessage,
                    MessageType.Info);
                return;
            }

            DrawInfoPanel();

            
            var previewRect = GUILayoutUtility.GetRect(
                100, 100, GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true));

            HandleMouseInput(previewRect);
            RenderPreview(previewRect);
        }

        #endregion

        #region UI 描画

        private void DrawToolbar()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.toolbar))
            {
                string title = _info != null
                    ? $"{_info.DisplayName}  ({_info.FileTypeDisplay})"
                    : "(未ロード)";
                GUILayout.Label(title, EditorStyles.toolbarButton,
                    GUILayout.ExpandWidth(true));

                
                
                
                
                GUILayout.Label(
                    new GUIContent("Skybox:",
                        "背景に使う Skybox マテリアルを選択 (Unity 標準の Skybox/* シェーダー推奨)。\n" +
                        "空にするとデフォルトの暗色背景に戻ります。"),
                    EditorStyles.miniLabel, GUILayout.Width(48));

                EditorGUI.BeginChangeCheck();
                var newSkybox = (Material)EditorGUILayout.ObjectField(
                    _skyboxMaterial, typeof(Material), allowSceneObjects: false,
                    GUILayout.Width(150));
                if (EditorGUI.EndChangeCheck())
                {
                    _skyboxMaterial = newSkybox;
                    ApplySkyboxToCamera();
                    SaveSkyboxPreference();
                    Repaint();
                }

                using (new EditorGUI.DisabledScope(_previewRoot == null))
                {
                    if (GUILayout.Button("視点リセット", EditorStyles.toolbarButton, GUILayout.Width(80)))
                    {
                        _cameraAngle = new Vector2(DefaultPitch, DefaultYaw);
                        ComputeCameraFraming();
                        Repaint();
                    }
                    if (GUILayout.Button("アンロード", EditorStyles.toolbarButton, GUILayout.Width(80)))
                    {
                        CleanupPreview();
                        _statusMessage = "アンロード済み。別の VRCA を開けます。";
                        Repaint();
                    }
                }
            }
        }

        private void DrawInfoPanel()
        {
            using (new EditorGUILayout.HorizontalScope(EditorStyles.helpBox))
            {
                GUILayout.Label(
                    $"Renderer: {_rendererCount}  •  Vertex: {_vertexCount:N0}  •  " +
                    $"Material: {_materialCount}  •  Bone: {_boneCount}" +
                    (_remappedShaderCount > 0
                        ? $"  •  ⚠ シェーダーをフォールバック: {_remappedShaderCount}"
                        : string.Empty),
                    EditorStyles.miniLabel);
            }

            
            EditorGUILayout.LabelField(
                "▶ 左ドラッグ=パン (視点移動 / 高さ変更)  •  " +
                "右ドラッグ=視点回転  •  ホイール=ズーム  •  " +
                "F=フォーカス  •  0=リセット",
                EditorStyles.centeredGreyMiniLabel);
        }

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        private static readonly int PreviewDragControlHint =
            "AvatarRecovery.VrcaPreviewWindow.Drag".GetHashCode();

        private void HandleMouseInput(Rect rect)
        {
            var e = Event.current;
            if (e == null) return;

            
            
            int controlId = GUIUtility.GetControlID(PreviewDragControlHint, FocusType.Passive);

            
            if (e.type == EventType.MouseDown && rect.Contains(e.mousePosition))
            {
                _dragMode = DetermineDragMode(e);
                if (_dragMode != DragMode.None)
                {
                    
                    _dragButton = e.button;
                    GUIUtility.hotControl = controlId;
                    e.Use();
                    return;
                }
            }

            
            if (e.type == EventType.MouseUp && _dragMode != DragMode.None && e.button == _dragButton)
            {
                _dragMode = DragMode.None;
                _dragButton = -1;
                if (GUIUtility.hotControl == controlId)
                    GUIUtility.hotControl = 0;
                e.Use();
                return;
            }

            
            if (e.type == EventType.MouseDrag && _dragMode != DragMode.None)
            {
                switch (_dragMode)
                {
                    case DragMode.Pan:
                        
                        
                        
                        var camRot = Quaternion.Euler(_cameraAngle.x, _cameraAngle.y, 0f);
                        var right  = camRot * Vector3.right;
                        var up     = camRot * Vector3.up;
                        float panSpeed = _cameraDistance * 0.0015f;
                        _cameraTarget -= right * (e.delta.x * panSpeed);
                        _cameraTarget += up    * (e.delta.y * panSpeed);
                        break;

                    case DragMode.Orbit:
                        
                        _cameraAngle.y += e.delta.x * 0.3f;
                        _cameraAngle.x += e.delta.y * 0.3f;
                        _cameraAngle.x = Mathf.Clamp(_cameraAngle.x, -89f, 89f);
                        
                        _cameraAngle.y = Mathf.Repeat(_cameraAngle.y + 180f, 360f) - 180f;
                        break;
                }
                e.Use();
                Repaint();
                return;
            }

            
            
            if (e.type == EventType.ScrollWheel && rect.Contains(e.mousePosition))
            {
                float zoomFactor = 1f + e.delta.y * 0.08f;
                _cameraDistance = Mathf.Clamp(
                    _cameraDistance * zoomFactor, 0.05f, 500f);
                e.Use();
                Repaint();
                return;
            }

            
            
            
            
            if (e.type == EventType.KeyDown && rect.Contains(e.mousePosition))
            {
                switch (e.keyCode)
                {
                    case KeyCode.F:
                        
                        ComputeCameraFraming();
                        e.Use();
                        Repaint();
                        return;

                    case KeyCode.Alpha0:
                    case KeyCode.Keypad0:
                        
                        _cameraAngle = new Vector2(DefaultPitch, DefaultYaw);
                        ComputeCameraFraming();
                        e.Use();
                        Repaint();
                        return;
                }
            }
        }

        
        
        
        
        private static DragMode DetermineDragMode(Event e)
        {
            
            if (e.button == 0) return DragMode.Pan;

            
            if (e.button == 2) return DragMode.Pan;

            
            if (e.button == 1) return DragMode.Orbit;

            return DragMode.None;
        }

        
        private void RenderPreview(Rect rect)
        {
            if (Event.current.type != EventType.Repaint) return;
            if (_preview == null || _previewRoot == null) return;

            _preview.BeginPreview(rect, GUIStyle.none);

            
            var rot = Quaternion.Euler(_cameraAngle.x, _cameraAngle.y, 0f);
            var cam = _preview.camera;
            cam.transform.position = _cameraTarget + rot * (Vector3.back * _cameraDistance);
            cam.transform.LookAt(_cameraTarget);
            cam.nearClipPlane = Mathf.Max(0.001f, _cameraDistance * 0.01f);
            cam.farClipPlane  = _cameraDistance * 100f;

            cam.Render();
            _preview.EndAndDrawPreview(rect);
        }

        #endregion

        #region VRCA ロード / アンロード

        
        
        
        
        private void LoadVrca(VrcaFileInfo info)
        {
            CleanupPreview();
            EnsurePreviewUtility();

            _info = info;
            _statusMessage = null;

            try
            {
                
                if (!info.IsParsed) VrcaLoader.ParseHeader(info);

                if (!string.IsNullOrEmpty(info.ParseError))
                {
                    _statusMessage = $"ロード失敗: {info.ParseError}";
                    return;
                }

                if (!VrcaLoader.TryLoadBundle(info, out _bundle) || _bundle == null)
                {
                    _statusMessage = "AssetBundle のロードに失敗しました。\n" +
                                     "Unity バージョンが一致していない可能性があります。";
                    return;
                }

                
                var allGos = _bundle.LoadAllAssets<GameObject>();
                if (allGos == null || allGos.Length == 0)
                {
                    _statusMessage = "バンドル内に GameObject が見つかりません。";
                    return;
                }

                var rootOriginal = FindRootForPreview(allGos, info);
                if (rootOriginal == null)
                {
                    _statusMessage = "ルート GameObject が特定できませんでした。";
                    return;
                }

                
                _previewRoot = Object.Instantiate(rootOriginal);
                _previewRoot.name = "VrcaPreview_" + info.DisplayName;
                _previewRoot.hideFlags = HideFlags.HideAndDontSave;

                
                _preview.AddSingleGO(_previewRoot);

                
                
                _remappedShaderCount = ShaderRemapper.RemapOnGameObject(_previewRoot);

                
                CollectStatistics();

                
                ComputeCameraFraming();

                _statusMessage = $"プレビュー中: {_rendererCount} Renderer / {_vertexCount:N0} 頂点";
                Repaint();
            }
            catch (System.Exception ex)
            {
                _statusMessage = $"プレビューロードでエラー: {ex.Message}";
                Debug.LogError($"[AvatarRecovery] VrcaPreviewWindow.LoadVrca: {ex}");
                CleanupPreview();
            }
        }

        
        private void CleanupPreview()
        {
            if (_previewRoot != null)
            {
                try { Object.DestroyImmediate(_previewRoot); } catch { }
                _previewRoot = null;
            }
            if (_bundle != null)
            {
                try { _bundle.Unload(unloadAllLoadedObjects: true); } catch { }
                _bundle = null;
            }

            _rendererCount = _vertexCount = _materialCount = _boneCount = 0;
            _remappedShaderCount = 0;
        }

        
        private static GameObject FindRootForPreview(GameObject[] all, VrcaFileInfo info)
        {
            
            foreach (var go in all)
            {
                if (go != null && go.GetComponent<Animator>() != null) return go;
            }

            
            if (!string.IsNullOrEmpty(info?.BlueprintId))
            {
                foreach (var go in all)
                {
                    if (go == null) continue;
                    if (go.name.IndexOf(info.BlueprintId,
                        System.StringComparison.OrdinalIgnoreCase) >= 0) return go;
                }
            }

            
            GameObject best = null;
            int bestCount = -1;
            foreach (var go in all)
            {
                if (go == null) continue;
                var n = go.GetComponentsInChildren<Transform>(true).Length;
                if (n > bestCount) { bestCount = n; best = go; }
            }
            return best;
        }

        #endregion

        #region カメラフレーミングと統計

        
        private void ComputeCameraFraming()
        {
            if (_previewRoot == null)
            {
                _cameraTarget   = Vector3.zero;
                _cameraDistance = 3f;
                return;
            }

            var renderers = _previewRoot.GetComponentsInChildren<Renderer>(true);
            if (renderers.Length == 0)
            {
                _cameraTarget   = _previewRoot.transform.position;
                _cameraDistance = 3f;
                return;
            }

            Bounds bounds = renderers[0].bounds;
            foreach (var r in renderers.Skip(1))
            {
                if (r != null) bounds.Encapsulate(r.bounds);
            }

            _cameraTarget = bounds.center;

            
            
            float radius   = Mathf.Max(0.1f, bounds.extents.magnitude);
            float fovRad   = 30f * Mathf.Deg2Rad;
            _cameraDistance = radius / Mathf.Tan(fovRad * 0.5f) * 1.2f;
        }

        
        private void CollectStatistics()
        {
            if (_previewRoot == null) return;

            var renderers = _previewRoot.GetComponentsInChildren<Renderer>(true);
            _rendererCount = renderers.Length;

            var materialSet = new System.Collections.Generic.HashSet<int>();
            int verts = 0;
            foreach (var r in renderers)
            {
                if (r == null) continue;
                foreach (var m in r.sharedMaterials)
                {
                    if (m != null) materialSet.Add(m.GetInstanceID());
                }
                if (r is SkinnedMeshRenderer smr && smr.sharedMesh != null)
                    verts += smr.sharedMesh.vertexCount;
                else if (r is MeshRenderer mr)
                {
                    var mf = mr.GetComponent<MeshFilter>();
                    if (mf != null && mf.sharedMesh != null)
                        verts += mf.sharedMesh.vertexCount;
                }
            }
            _vertexCount   = verts;
            _materialCount = materialSet.Count;

            var smrs = _previewRoot.GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var boneSet = new System.Collections.Generic.HashSet<int>();
            foreach (var smr in smrs)
            {
                if (smr == null || smr.bones == null) continue;
                foreach (var b in smr.bones)
                {
                    if (b != null) boneSet.Add(b.GetInstanceID());
                }
            }
            _boneCount = boneSet.Count;
        }

        #endregion

        #region PreviewRenderUtility セットアップ

        
        private void EnsurePreviewUtility()
        {
            if (_preview != null) return;

            _preview = new PreviewRenderUtility();
            var cam = _preview.camera;
            cam.fieldOfView      = 30f;
            cam.clearFlags       = CameraClearFlags.SolidColor;
            cam.backgroundColor  = new Color(0.12f, 0.12f, 0.14f, 1f);
            cam.nearClipPlane    = 0.01f;
            cam.farClipPlane     = 1000f;

            
            _preview.ambientColor = new Color(0.4f, 0.4f, 0.45f);

            
            if (_preview.lights != null && _preview.lights.Length > 0 && _preview.lights[0] != null)
            {
                _preview.lights[0].intensity = 1.0f;
                _preview.lights[0].transform.rotation = Quaternion.Euler(50f, -30f, 0f);
            }
            if (_preview.lights != null && _preview.lights.Length > 1 && _preview.lights[1] != null)
            {
                _preview.lights[1].intensity = 0.6f;
                _preview.lights[1].transform.rotation = Quaternion.Euler(-30f, 150f, 0f);
            }

            
            ApplySkyboxToCamera();
        }

        #endregion

        #region v2.3: Skybox マテリアル

        
        
        
        
        
        
        
        
        
        
        
        
        private void ApplySkyboxToCamera()
        {
            if (_preview == null || _preview.camera == null) return;

            var cam = _preview.camera;
            var skyboxComp = cam.gameObject.GetComponent<Skybox>();

            if (_skyboxMaterial != null)
            {
                if (skyboxComp == null)
                {
                    skyboxComp = cam.gameObject.AddComponent<Skybox>();
                    skyboxComp.hideFlags = HideFlags.HideAndDontSave;
                }
                skyboxComp.material = _skyboxMaterial;
                cam.clearFlags = CameraClearFlags.Skybox;
            }
            else
            {
                
                if (skyboxComp != null) DestroyImmediate(skyboxComp);
                cam.clearFlags       = CameraClearFlags.SolidColor;
                cam.backgroundColor  = new Color(0.12f, 0.12f, 0.14f, 1f);
            }
        }

        
        private void LoadSkyboxPreference()
        {
            var path = EditorPrefsHelper.LoadPreviewSkyboxPath();
            if (string.IsNullOrEmpty(path))
            {
                _skyboxMaterial = null;
            }
            else
            {
                _skyboxMaterial = AssetDatabase.LoadAssetAtPath<Material>(path);
                
            }
            ApplySkyboxToCamera();
        }

        
        private void SaveSkyboxPreference()
        {
            var path = _skyboxMaterial != null
                ? AssetDatabase.GetAssetPath(_skyboxMaterial)
                : string.Empty;
            EditorPrefsHelper.SavePreviewSkyboxPath(path);
        }

        #endregion
    }
}
