






using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    
    
    
    
    public static class ShaderRemapper
    {
        #region 定数

        
        private static readonly string[] PreferredShaderNames =
        {
            ".poiyomi/Poiyomi Toon",        
            "Poiyomi/Poiyomi Toon",
            "arktoon/Opaque",               
            "lilToon",                      
            "VRChat/Mobile/Toon Lit",       
            "Standard"                      
        };

        #endregion

        #region 公開 API

        
        
        
        
        
        
        public static int RemapInFolder(string assetFolder)
        {
            var guids = AssetDatabase.FindAssets("t:Material", new[] { assetFolder });
            int count = 0;

            foreach (var guid in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var mat  = AssetDatabase.LoadAssetAtPath<Material>(path);

                if (mat == null) continue;

                if (RemapMaterial(mat))
                {
                    EditorUtility.SetDirty(mat);
                    count++;
                }
            }

            if (count > 0)
            {
                AssetDatabase.SaveAssets();
                Debug.Log($"[AvatarRecovery] シェーダー再割り当て: {count} 件のマテリアルを更新しました");
            }

            return count;
        }

        
        
        
        
        
        public static bool RemapMaterial(Material mat)
        {
            if (mat == null) return false;

            
            if (mat.shader != null &&
                mat.shader.name != "Hidden/InternalErrorShader" &&
                mat.shader.name != "Standard (Specular setup)" &&
                !mat.shader.name.StartsWith("Hidden/"))
            {
                return false;
            }

            var replacement = FindBestShader();
            if (replacement == null)
            {
                Debug.LogWarning($"[AvatarRecovery] 代替シェーダーが見つかりません: {mat.name}");
                return false;
            }

            Debug.Log($"[AvatarRecovery] シェーダー置換: {mat.name}  " +
                      $"{mat.shader?.name ?? "null"} → {replacement.name}");

            mat.shader = replacement;
            return true;
        }

        
        
        
        
        
        
        public static int RemapOnGameObject(GameObject root)
        {
            if (root == null) return 0;

            var renderers = root.GetComponentsInChildren<Renderer>(includeInactive: true);
            int count = 0;

            foreach (var renderer in renderers)
            {
                var mats = renderer.sharedMaterials;
                bool changed = false;

                for (int i = 0; i < mats.Length; i++)
                {
                    if (RemapMaterial(mats[i]))
                    {
                        changed = true;
                        count++;
                    }
                }

                if (changed)
                {
                    renderer.sharedMaterials = mats;
                    
                    
                    
                    EditorUtility.SetDirty(renderer);
                }
            }

            return count;
        }

        
        
        
        
        public static Shader FindBestShader()
        {
            foreach (var name in PreferredShaderNames)
            {
                var shader = Shader.Find(name);
                if (shader != null) return shader;
            }

            return null;
        }

        
        
        
        public static List<string> GetAvailableShaders()
        {
            var result = new List<string>();
            foreach (var name in PreferredShaderNames)
            {
                if (Shader.Find(name) != null)
                    result.Add(name);
            }
            return result;
        }

        #endregion
    }
}
