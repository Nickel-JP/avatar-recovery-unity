using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace EditorTools.AvatarRecovery
{
    public sealed class ShaderListViewerWindow : EditorWindow
    {
        private const string WindowTitle = "Shader Lists";
        private const string MenuItemPath = "AvatarRecovery/Shader一覧を開く";
        private const float MinWindowWidth = 760f;
        private const float MinWindowHeight = 420f;

        private static readonly string[] TabNames =
        {
            "Material → Shader",
            "Shaders.txt",
            "MaterialShaderMap.txt"
        };

        private readonly List<MaterialShaderRow> _materialRows = new List<MaterialShaderRow>();
        private readonly List<ShaderListSource> _shaderListSources = new List<ShaderListSource>();

        private int _tab;
        private bool _shaderListFoldout = true;
        private string _restoredRootAssetPath;
        private string _listFolderAssetPath;
        private string _materialCsvAssetPath;
        private string _materialTextAssetPath;
        private string _shadersTextAssetPath;
        private string _materialText;
        private string _shadersText;
        private string _filter = string.Empty;
        private string _statusMessage = string.Empty;
        private bool _statusIsError;
        private Vector2 _materialScroll;
        private Vector2 _shaderTextScroll;
        private Vector2 _materialTextScroll;

        [MenuItem(MenuItemPath, priority = 45)]
        private static void OpenFromMenu()
        {
            var window = GetWindow<ShaderListViewerWindow>(WindowTitle);
            window.minSize = new Vector2(MinWindowWidth, MinWindowHeight);
            window.TryLoadFromSelection();
            window.Show();
        }

        private void OnEnable()
        {
            minSize = new Vector2(MinWindowWidth, MinWindowHeight);

            EditorApplication.delayCall += TryLoadFromSelectionAfterLayoutRestore;
        }

        private void OnDisable()
        {
            EditorApplication.delayCall -= TryLoadFromSelectionAfterLayoutRestore;
        }

        private void TryLoadFromSelectionAfterLayoutRestore()
        {
            if (this == null)
                return;

            if (string.IsNullOrEmpty(_restoredRootAssetPath))
                TryLoadFromSelection();
        }

        private void OnGUI()
        {
            Styles.EnsureInitialized();

            DrawToolbar();
            DrawListFolderDropArea();
            DrawSourceSummary();

            _tab = GUILayout.Toolbar(_tab, TabNames);
            GUILayout.Space(4);

            switch (_tab)
            {
                case 0:
                    DrawMaterialShaderTab();
                    break;
                case 1:
                    DrawTextTab(
                        "Shaders.txt",
                        _shadersTextAssetPath,
                        _shadersText,
                        ref _shaderTextScroll);
                    break;
                case 2:
                    DrawTextTab(
                        "MaterialShaderMap.txt",
                        _materialTextAssetPath,
                        _materialText,
                        ref _materialTextScroll);
                    break;
            }

            DrawStatusBar();
        }

        private void DrawToolbar()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);

            if (GUILayout.Button("Selectionから読込", EditorStyles.toolbarButton, GUILayout.Width(110)))
                TryLoadFromSelection();

            if (GUILayout.Button("復元フォルダを選択", EditorStyles.toolbarButton, GUILayout.Width(120)))
                PickRestoredFolder();

            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(_restoredRootAssetPath)))
            {
                if (GUILayout.Button("再読込", EditorStyles.toolbarButton, GUILayout.Width(60)))
                    LoadFromRoot(_restoredRootAssetPath);

                using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(_listFolderAssetPath)))
                {
                    if (GUILayout.Button("Listフォルダへ", EditorStyles.toolbarButton, GUILayout.Width(90)))
                        PingAsset(_listFolderAssetPath);
                }
            }

            GUILayout.FlexibleSpace();
            EditorGUILayout.EndHorizontal();
        }

        private void DrawListFolderDropArea()
        {
            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            EditorGUILayout.BeginHorizontal();
            _shaderListFoldout = EditorGUILayout.Foldout(
                _shaderListFoldout,
                "List of Shaders",
                true);
            GUILayout.FlexibleSpace();
            using (new EditorGUI.DisabledScope(true))
            {
                EditorGUILayout.IntField(_shaderListSources.Count, GUILayout.Width(48));
            }
            EditorGUILayout.EndHorizontal();

            if (_shaderListFoldout)
            {
                for (int i = 0; i < _shaderListSources.Count; i++)
                    DrawShaderListSourceRow(i);

                DrawShaderListSourceAddRow();
            }

            EditorGUILayout.EndVertical();
        }

        private void DrawShaderListSourceRow(int index)
        {
            if (index < 0 || index >= _shaderListSources.Count)
                return;

            var source = _shaderListSources[index];
            bool requestedVisible;
            bool requestedRemove;

            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(14);
            requestedVisible = EditorGUILayout.Toggle(source.Visible, GUILayout.Width(18));
            GUILayout.Label($"List {index}", GUILayout.Width(48));

            using (new EditorGUI.DisabledScope(true))
            {
                var folderObject = AssetDatabase.LoadAssetAtPath<DefaultAsset>(source.ListFolderAssetPath);
                if (folderObject != null)
                {
                    EditorGUILayout.ObjectField(
                        folderObject,
                        typeof(DefaultAsset),
                        false,
                        GUILayout.MinWidth(180));
                }
                else
                {
                    EditorGUILayout.TextField(source.ListFolderAssetPath ?? "(missing)");
                }
            }

            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(source.ListFolderAssetPath)))
            {
                if (GUILayout.Button("Ping", GUILayout.Width(48)))
                    PingAsset(source.ListFolderAssetPath);
            }

            requestedRemove = GUILayout.Button("-", GUILayout.Width(24));
            EditorGUILayout.EndHorizontal();

            if (requestedVisible != source.Visible)
            {
                if (requestedVisible)
                    SetActiveSource(index);
                else
                    ClearCurrentDisplay();
            }

            if (requestedRemove)
                RemoveSourceAt(index);
        }

        private void DrawShaderListSourceAddRow()
        {
            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(14);
            GUILayout.Label("Add", GUILayout.Width(66));
            var droppedObject = EditorGUILayout.ObjectField(
                null,
                typeof(DefaultAsset),
                false,
                GUILayout.MinWidth(180));

            if (GUILayout.Button("+", GUILayout.Width(56)))
                PickRestoredFolder();

            EditorGUILayout.EndHorizontal();

            var dropRect = GUILayoutUtility.GetLastRect();
            HandleListFolderDragAndDrop(dropRect);

            if (droppedObject == null)
                return;

            var assetPath = AssetDatabase.GetAssetPath(droppedObject);
            if (!TryLoadDroppedPath(assetPath))
            {
                SetStatus(
                    "List of Shadersフォルダ、またはList of Shadersを含む復元フォルダを指定してください。",
                    true);
            }

            GUIUtility.ExitGUI();
        }

        private void HandleListFolderDragAndDrop(Rect dropRect)
        {
            var ev = Event.current;
            if (ev == null || !dropRect.Contains(ev.mousePosition))
                return;

            if (ev.type == EventType.DragUpdated)
            {
                DragAndDrop.visualMode = CanAcceptCurrentDrag()
                    ? DragAndDropVisualMode.Copy
                    : DragAndDropVisualMode.Rejected;
                ev.Use();
                return;
            }

            if (ev.type != EventType.DragPerform)
                return;

            DragAndDrop.AcceptDrag();

            var loaded = TryLoadCurrentDrag();
            if (!loaded)
            {
                SetStatus(
                    "List of Shadersフォルダ、またはList of Shadersを含む復元フォルダをドロップしてください。",
                    true);
            }

            ev.Use();
        }

        private bool CanAcceptCurrentDrag()
        {
            if (DragAndDrop.paths != null)
            {
                foreach (var path in DragAndDrop.paths)
                {
                    if (!string.IsNullOrEmpty(ResolveDroppedRoot(path)))
                        return true;
                }
            }

            if (DragAndDrop.objectReferences != null)
            {
                foreach (var obj in DragAndDrop.objectReferences)
                {
                    var assetPath = AssetDatabase.GetAssetPath(obj);
                    if (!string.IsNullOrEmpty(ResolveDroppedRoot(assetPath)))
                        return true;
                }
            }

            return false;
        }

        private bool TryLoadCurrentDrag()
        {
            bool loaded = false;

            if (DragAndDrop.paths != null)
            {
                foreach (var path in DragAndDrop.paths)
                {
                    if (TryLoadDroppedPath(path))
                        loaded = true;
                }
            }

            if (DragAndDrop.objectReferences != null)
            {
                foreach (var obj in DragAndDrop.objectReferences)
                {
                    var assetPath = AssetDatabase.GetAssetPath(obj);
                    if (TryLoadDroppedPath(assetPath))
                        loaded = true;
                }
            }

            return loaded;
        }

        private bool TryLoadDroppedPath(string rawPath)
        {
            var root = ResolveDroppedRoot(rawPath);
            if (string.IsNullOrEmpty(root))
                return false;

            AddOrEnableSource(root);
            return true;
        }

        private static string ResolveDroppedRoot(string rawPath)
        {
            if (string.IsNullOrEmpty(rawPath))
                return null;

            var assetPath = NormalizeAssetPath(rawPath).TrimEnd('/');
            if (!assetPath.Equals("Assets", StringComparison.OrdinalIgnoreCase) &&
                !assetPath.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
            {
                assetPath = AbsolutePathToAssetPath(assetPath);
            }

            if (string.IsNullOrEmpty(assetPath))
                return null;

            return FindRestoredRoot(assetPath);
        }

        private void DrawSourceSummary()
        {
            if (string.IsNullOrEmpty(_restoredRootAssetPath))
            {
                EditorGUILayout.HelpBox(
                    _shaderListSources.Count == 0
                        ? "List of Shadersフォルダを上の枠へドラッグ&ドロップしてください。Selection読込やフォルダ選択も利用できます。"
                        : "表示したいList of ShadersのチェックボックスをONにしてください。",
                    MessageType.Info);
                return;
            }

            EditorGUILayout.HelpBox(
                $"表示中: {GetActiveSourceDisplayName()}\n" +
                $"復元フォルダ: {_restoredRootAssetPath}\n" +
                $"追加済みList: {_shaderListSources.Count} 件\n" +
                $"Material対応: {_materialRows.Count} 件\n" +
                $"CSV: {FormatAssetPresence(_materialCsvAssetPath)}",
                _statusIsError ? MessageType.Warning : MessageType.Info);
        }

        private void DrawMaterialShaderTab()
        {
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("検索", GUILayout.Width(36));
            _filter = EditorGUILayout.TextField(_filter);
            if (GUILayout.Button("クリア", GUILayout.Width(60)))
            {
                _filter = string.Empty;
                GUI.FocusControl(null);
            }
            EditorGUILayout.EndHorizontal();

            GUILayout.Space(4);

            if (_materialRows.Count == 0)
            {
                EditorGUILayout.HelpBox(
                    "MaterialShaderMap.csvが見つからないか、読み込めるMaterial行がありません。",
                    MessageType.Warning);
                return;
            }

            DrawMaterialTableHeader();

            int visibleIndex = 0;
            _materialScroll = EditorGUILayout.BeginScrollView(_materialScroll);
            foreach (var row in _materialRows)
            {
                if (!MatchesFilter(row, _filter))
                    continue;

                DrawMaterialRow(row, visibleIndex);
                visibleIndex++;
            }
            EditorGUILayout.EndScrollView();

            if (visibleIndex == 0)
                EditorGUILayout.HelpBox("検索条件に一致するMaterialはありません。", MessageType.None);
        }

        private static void DrawMaterialTableHeader()
        {
            EditorGUILayout.BeginHorizontal(EditorStyles.toolbar);
            GUILayout.Label("Status", EditorStyles.boldLabel, GUILayout.Width(72));
            GUILayout.Label("Material", EditorStyles.boldLabel, GUILayout.Width(210));
            GUILayout.Label("Original Shader", EditorStyles.boldLabel, GUILayout.MinWidth(220));
            GUILayout.Label("Path", EditorStyles.boldLabel, GUILayout.Width(280));
            GUILayout.Label(string.Empty, GUILayout.Width(58));
            EditorGUILayout.EndHorizontal();
        }

        private void DrawMaterialRow(MaterialShaderRow row, int visibleIndex)
        {
            var rowStyle = Styles.GetRowStyle(visibleIndex, -1);

            EditorGUILayout.BeginHorizontal(rowStyle);
            GUILayout.Label(string.IsNullOrEmpty(row.Status) ? "(なし)" : row.Status, GUILayout.Width(72));

            var materialLabel = string.IsNullOrEmpty(row.MaterialName)
                ? "(名称なし)"
                : row.MaterialName;
            var materialContent = new GUIContent(materialLabel, row.MaterialAssetPath);
            if (GUILayout.Button(materialContent, Styles.LinkButton, GUILayout.Width(210)))
                PingMaterial(row);
            EditorGUIUtility.AddCursorRect(GUILayoutUtility.GetLastRect(), MouseCursor.Link);

            GUILayout.Label(
                string.IsNullOrEmpty(row.OriginalShaderName) ? "(特定不可)" : row.OriginalShaderName,
                GUILayout.MinWidth(220));
            GUILayout.Label(row.MaterialRelativePath ?? string.Empty, EditorStyles.miniLabel, GUILayout.Width(280));

            using (new EditorGUI.DisabledScope(!row.MaterialExists))
            {
                if (GUILayout.Button("Ping", GUILayout.Width(58)))
                    PingMaterial(row);
            }

            EditorGUILayout.EndHorizontal();
        }

        private void DrawTextTab(
            string displayName,
            string assetPath,
            string text,
            ref Vector2 scroll)
        {
            EditorGUILayout.BeginHorizontal();
            using (new EditorGUI.DisabledScope(string.IsNullOrEmpty(assetPath)))
            {
                if (GUILayout.Button("Projectで選択", GUILayout.Width(110)))
                    PingAsset(assetPath);

                if (GUILayout.Button("開く", GUILayout.Width(60)))
                    OpenAsset(assetPath);
            }
            GUILayout.FlexibleSpace();
            GUILayout.Label(assetPath ?? displayName, EditorStyles.miniLabel);
            EditorGUILayout.EndHorizontal();

            if (string.IsNullOrEmpty(text))
            {
                EditorGUILayout.HelpBox($"{displayName} が見つからないか、内容が空です。", MessageType.Warning);
                return;
            }

            scroll = EditorGUILayout.BeginScrollView(scroll);
            EditorGUILayout.TextArea(text, GUILayout.ExpandHeight(true));
            EditorGUILayout.EndScrollView();
        }

        private void DrawStatusBar()
        {
            if (string.IsNullOrEmpty(_statusMessage))
                return;

            var style = _statusIsError ? Styles.ErrorLabel : Styles.SuccessLabel;
            EditorGUILayout.LabelField(_statusMessage, style);
        }

        private void TryLoadFromSelection()
        {
            var selected = Selection.activeObject;
            if (selected == null)
            {
                SetStatus("Projectビューで復元フォルダまたは一覧ファイルを選択してください。", true);
                return;
            }

            var assetPath = AssetDatabase.GetAssetPath(selected);
            if (string.IsNullOrEmpty(assetPath))
            {
                SetStatus("選択中のObjectはProject内assetではありません。", true);
                return;
            }

            if (!TryLoadFromAssetPath(assetPath))
                SetStatus($"List of Shadersを含む復元フォルダを特定できません: {assetPath}", true);
        }

        private bool TryLoadFromAssetPath(string assetPath)
        {
            var root = FindRestoredRoot(assetPath);
            if (string.IsNullOrEmpty(root))
                return false;

            AddOrEnableSource(root);
            return true;
        }

        private void PickRestoredFolder()
        {
            var initial = string.IsNullOrEmpty(_restoredRootAssetPath)
                ? AssetPathToAbsolutePath("Assets")
                : AssetPathToAbsolutePath(_restoredRootAssetPath);

            var picked = EditorUtility.OpenFolderPanel(
                "復元フォルダまたはList of Shadersフォルダを選択",
                initial,
                string.Empty);
            if (string.IsNullOrEmpty(picked))
                return;

            var assetPath = AbsolutePathToAssetPath(picked);
            if (string.IsNullOrEmpty(assetPath))
            {
                SetStatus("Assets配下のフォルダを選択してください。", true);
                return;
            }

            if (!TryLoadFromAssetPath(assetPath))
                SetStatus($"List of Shadersを含む復元フォルダを特定できません: {assetPath}", true);
        }

        private void AddOrEnableSource(string rootAssetPath)
        {
            var root = NormalizeAssetPath(rootAssetPath).TrimEnd('/');
            if (string.IsNullOrEmpty(root))
            {
                SetStatus("List of Shadersを含む復元フォルダを特定できません。", true);
                return;
            }

            for (int i = 0; i < _shaderListSources.Count; i++)
            {
                if (!_shaderListSources[i].RootAssetPath.Equals(root, StringComparison.OrdinalIgnoreCase))
                    continue;

                SetActiveSource(i);
                SetStatus($"既存のList of Shadersを表示しました: {_shaderListSources[i].ListFolderAssetPath}", false);
                return;
            }

            _shaderListSources.Add(new ShaderListSource
            {
                RootAssetPath = root,
                ListFolderAssetPath = $"{root}/{ShaderListWriter.SubFolderName}",
                DisplayName = Path.GetFileName(root)
            });

            SetActiveSource(_shaderListSources.Count - 1);
            SetStatus($"List of Shadersを追加しました: {_listFolderAssetPath}", false);
        }

        private void SetActiveSource(int index)
        {
            if (index < 0 || index >= _shaderListSources.Count)
            {
                ClearCurrentDisplay();
                return;
            }

            for (int i = 0; i < _shaderListSources.Count; i++)
                _shaderListSources[i].Visible = i == index;

            LoadFromRoot(_shaderListSources[index].RootAssetPath);
        }

        private void RemoveSourceAt(int index)
        {
            if (index < 0 || index >= _shaderListSources.Count)
                return;

            bool wasVisible = _shaderListSources[index].Visible;
            _shaderListSources.RemoveAt(index);

            if (wasVisible)
            {
                if (_shaderListSources.Count == 0)
                {
                    ClearCurrentDisplay();
                    return;
                }

                SetActiveSource(Math.Min(index, _shaderListSources.Count - 1));
                return;
            }

            Repaint();
        }

        private void ClearCurrentDisplay()
        {
            for (int i = 0; i < _shaderListSources.Count; i++)
                _shaderListSources[i].Visible = false;

            _restoredRootAssetPath = null;
            _listFolderAssetPath = null;
            _materialCsvAssetPath = null;
            _materialTextAssetPath = null;
            _shadersTextAssetPath = null;
            _materialRows.Clear();
            _materialText = string.Empty;
            _shadersText = string.Empty;
            SetStatus("表示対象のList of Shadersが未選択です。", false);
        }

        private void LoadFromRoot(string rootAssetPath)
        {
            _restoredRootAssetPath = NormalizeAssetPath(rootAssetPath).TrimEnd('/');
            _listFolderAssetPath = $"{_restoredRootAssetPath}/{ShaderListWriter.SubFolderName}";
            _materialCsvAssetPath = $"{_listFolderAssetPath}/{ShaderListWriter.MaterialMapCsvFileName}";
            _materialTextAssetPath = $"{_listFolderAssetPath}/{ShaderListWriter.MaterialMapFileName}";
            _shadersTextAssetPath = $"{_listFolderAssetPath}/{ShaderListWriter.FileName}";

            _materialRows.Clear();
            _materialText = ReadTextAsset(_materialTextAssetPath);
            _shadersText = ReadTextAsset(_shadersTextAssetPath);

            var csvText = ReadTextAsset(_materialCsvAssetPath);
            if (!string.IsNullOrEmpty(csvText))
                _materialRows.AddRange(ParseMaterialShaderCsv(csvText));

            SetStatus($"Shader一覧を読み込みました: {_restoredRootAssetPath}", false);
            Repaint();
        }

        private string GetActiveSourceDisplayName()
        {
            for (int i = 0; i < _shaderListSources.Count; i++)
            {
                if (_shaderListSources[i].Visible)
                    return string.IsNullOrEmpty(_shaderListSources[i].DisplayName)
                        ? $"List {i}"
                        : $"{_shaderListSources[i].DisplayName} (List {i})";
            }

            return "(未選択)";
        }

        private List<MaterialShaderRow> ParseMaterialShaderCsv(string csvText)
        {
            var rows = new List<MaterialShaderRow>();
            var records = ParseCsvRecords(csvText);
            if (records.Count <= 1)
                return rows;

            var header = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < records[0].Count; i++)
            {
                var key = records[0][i];
                if (!string.IsNullOrEmpty(key) && !header.ContainsKey(key))
                    header.Add(key, i);
            }

            for (int i = 1; i < records.Count; i++)
            {
                var record = records[i];
                if (record.Count == 0)
                    continue;

                var row = new MaterialShaderRow
                {
                    MaterialName = GetCsvValue(record, header, "MaterialName"),
                    MaterialRelativePath = NormalizeAssetPath(GetCsvValue(record, header, "MaterialPath")),
                    OriginalShaderName = GetCsvValue(record, header, "OriginalShaderName"),
                    ShaderFileId = GetCsvValue(record, header, "ShaderFileID"),
                    ShaderGuid = GetCsvValue(record, header, "ShaderGuid"),
                    Status = GetCsvValue(record, header, "Status")
                };

                row.MaterialAssetPath = ResolveMaterialAssetPath(row.MaterialRelativePath);
                row.MaterialExists = AssetPathExists(row.MaterialAssetPath);
                rows.Add(row);
            }

            return rows;
        }

        private string ResolveMaterialAssetPath(string materialPath)
        {
            if (string.IsNullOrEmpty(materialPath))
                return null;

            var normalized = NormalizeAssetPath(materialPath).TrimStart('/');
            if (normalized.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                return normalized;

            return $"{_restoredRootAssetPath}/{normalized}";
        }

        private void PingMaterial(MaterialShaderRow row)
        {
            if (row == null)
                return;

            if (!row.MaterialExists)
            {
                EditorUtility.DisplayDialog(
                    "Materialが見つかりません",
                    $"次のMaterial assetが見つかりません。\n{row.MaterialAssetPath}",
                    "OK");
                return;
            }

            PingAsset(row.MaterialAssetPath);
        }

        private static void PingAsset(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return;

            var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
            if (obj == null)
                return;

            Selection.activeObject = obj;
            EditorGUIUtility.PingObject(obj);
        }

        private static void OpenAsset(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return;

            var obj = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath);
            if (obj != null)
                AssetDatabase.OpenAsset(obj);
        }

        private static bool MatchesFilter(MaterialShaderRow row, string filter)
        {
            if (row == null)
                return false;
            if (string.IsNullOrWhiteSpace(filter))
                return true;

            return Contains(row.MaterialName, filter) ||
                   Contains(row.MaterialRelativePath, filter) ||
                   Contains(row.OriginalShaderName, filter) ||
                   Contains(row.ShaderGuid, filter) ||
                   Contains(row.Status, filter);
        }

        private static bool Contains(string value, string filter)
        {
            return !string.IsNullOrEmpty(value) &&
                   value.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string FindRestoredRoot(string assetPath)
        {
            var normalized = NormalizeAssetPath(assetPath).TrimEnd('/');
            if (string.IsNullOrEmpty(normalized))
                return null;

            if (Path.GetFileName(normalized).Equals(ShaderListWriter.MaterialMapCsvFileName, StringComparison.OrdinalIgnoreCase) ||
                Path.GetFileName(normalized).Equals(ShaderListWriter.MaterialMapFileName, StringComparison.OrdinalIgnoreCase) ||
                Path.GetFileName(normalized).Equals(ShaderListWriter.FileName, StringComparison.OrdinalIgnoreCase))
            {
                var listFolder = GetAssetDirectory(normalized);
                if (Path.GetFileName(listFolder).Equals(ShaderListWriter.SubFolderName, StringComparison.OrdinalIgnoreCase))
                    return GetAssetDirectory(listFolder);
            }

            var current = AssetDatabase.IsValidFolder(normalized)
                ? normalized
                : GetAssetDirectory(normalized);

            while (!string.IsNullOrEmpty(current))
            {
                if (Path.GetFileName(current).Equals(ShaderListWriter.SubFolderName, StringComparison.OrdinalIgnoreCase))
                    return GetAssetDirectory(current);

                if (HasShaderListFolder(current))
                    return current;

                if (current.Equals("Assets", StringComparison.OrdinalIgnoreCase))
                    break;

                current = GetAssetDirectory(current);
            }

            return null;
        }

        private static bool HasShaderListFolder(string rootAssetPath)
        {
            if (string.IsNullOrEmpty(rootAssetPath))
                return false;

            var listFolder = $"{rootAssetPath.TrimEnd('/')}/{ShaderListWriter.SubFolderName}";
            return AssetPathExists($"{listFolder}/{ShaderListWriter.MaterialMapCsvFileName}") ||
                   AssetPathExists($"{listFolder}/{ShaderListWriter.MaterialMapFileName}") ||
                   AssetPathExists($"{listFolder}/{ShaderListWriter.FileName}");
        }

        private static List<List<string>> ParseCsvRecords(string text)
        {
            var records = new List<List<string>>();
            if (string.IsNullOrEmpty(text))
                return records;

            var record = new List<string>();
            var field = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < text.Length; i++)
            {
                char c = text[i];

                if (inQuotes)
                {
                    if (c == '"')
                    {
                        if (i + 1 < text.Length && text[i + 1] == '"')
                        {
                            field.Append('"');
                            i++;
                        }
                        else
                        {
                            inQuotes = false;
                        }
                    }
                    else
                    {
                        field.Append(c);
                    }

                    continue;
                }

                if (c == '"')
                {
                    inQuotes = true;
                }
                else if (c == ',')
                {
                    record.Add(field.ToString());
                    field.Length = 0;
                }
                else if (c == '\r' || c == '\n')
                {
                    if (c == '\r' && i + 1 < text.Length && text[i + 1] == '\n')
                        i++;

                    record.Add(field.ToString());
                    field.Length = 0;
                    AddCsvRecord(records, record);
                    record = new List<string>();
                }
                else
                {
                    field.Append(c);
                }
            }

            if (field.Length > 0 || record.Count > 0)
            {
                record.Add(field.ToString());
                AddCsvRecord(records, record);
            }

            return records;
        }

        private static void AddCsvRecord(List<List<string>> records, List<string> record)
        {
            if (record == null || record.Count == 0)
                return;

            bool hasValue = false;
            for (int i = 0; i < record.Count; i++)
            {
                if (!string.IsNullOrEmpty(record[i]))
                {
                    hasValue = true;
                    break;
                }
            }

            if (hasValue)
                records.Add(record);
        }

        private static string GetCsvValue(
            List<string> record,
            Dictionary<string, int> header,
            string key)
        {
            if (record == null || header == null || string.IsNullOrEmpty(key))
                return string.Empty;

            int index;
            if (!header.TryGetValue(key, out index))
                return string.Empty;
            if (index < 0 || index >= record.Count)
                return string.Empty;

            return record[index] ?? string.Empty;
        }

        private static string ReadTextAsset(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return string.Empty;

            var absolute = AssetPathToAbsolutePath(assetPath);
            if (string.IsNullOrEmpty(absolute) || !File.Exists(absolute))
                return string.Empty;

            try
            {
                return File.ReadAllText(absolute, Encoding.UTF8);
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[AvatarRecovery] テキスト読み込み失敗 '{assetPath}': {ex.Message}");
                return string.Empty;
            }
        }

        private static bool AssetPathExists(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return false;

            if (AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(assetPath) != null)
                return true;

            var absolute = AssetPathToAbsolutePath(assetPath);
            return !string.IsNullOrEmpty(absolute) && File.Exists(absolute);
        }

        private static string FormatAssetPresence(string assetPath)
        {
            return AssetPathExists(assetPath) ? assetPath : "(なし)";
        }

        private static string GetAssetDirectory(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return null;

            var dir = Path.GetDirectoryName(assetPath);
            return NormalizeAssetPath(dir);
        }

        private static string NormalizeAssetPath(string path)
        {
            return string.IsNullOrEmpty(path) ? string.Empty : path.Replace('\\', '/');
        }

        private static string AbsolutePathToAssetPath(string path)
        {
            if (string.IsNullOrEmpty(path))
                return null;

            var normalized = NormalizeAssetPath(path).TrimEnd('/');
            if (normalized.Equals("Assets", StringComparison.OrdinalIgnoreCase) ||
                normalized.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
            {
                return normalized;
            }

            var dataPath = NormalizeAssetPath(Application.dataPath).TrimEnd('/');
            var projectRoot = NormalizeAssetPath(Directory.GetParent(dataPath)?.FullName).TrimEnd('/');
            if (string.IsNullOrEmpty(projectRoot))
                return null;

            if (normalized.Equals(dataPath, StringComparison.OrdinalIgnoreCase))
                return "Assets";

            if (normalized.StartsWith(projectRoot + "/", StringComparison.OrdinalIgnoreCase))
                return normalized.Substring(projectRoot.Length + 1);

            return null;
        }

        private static string AssetPathToAbsolutePath(string assetPath)
        {
            if (string.IsNullOrEmpty(assetPath))
                return null;

            var projectRoot = Directory.GetParent(Application.dataPath)?.FullName;
            if (string.IsNullOrEmpty(projectRoot))
                return null;

            return Path.GetFullPath(
                Path.Combine(projectRoot, assetPath.Replace('/', Path.DirectorySeparatorChar)));
        }

        private void SetStatus(string message, bool isError)
        {
            _statusMessage = message;
            _statusIsError = isError;
            Repaint();
        }

        private sealed class MaterialShaderRow
        {
            public string MaterialName;
            public string MaterialRelativePath;
            public string MaterialAssetPath;
            public string OriginalShaderName;
            public string ShaderFileId;
            public string ShaderGuid;
            public string Status;
            public bool MaterialExists;
        }

        private sealed class ShaderListSource
        {
            public bool Visible;
            public string RootAssetPath;
            public string ListFolderAssetPath;
            public string DisplayName;
        }
    }
}
