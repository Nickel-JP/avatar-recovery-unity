




using UnityEditor;

namespace EditorTools.AvatarRecovery
{
    
    public static class EditorPrefsHelper
    {
        #region プレフィックス

        
        public const string PrefsPrefix = "AvatarRecovery_";

        #endregion

        #region キー定数

        private const string KeyCachePath       = PrefsPrefix + "CachePath";
        private const string KeyAvatarOutput    = PrefsPrefix + "AvatarOutput";
        private const string KeyWorldOutput     = PrefsPrefix + "WorldOutput";
        private const string KeyPackageOutput   = PrefsPrefix + "PackageOutput";
        private const string KeyAutoScan        = PrefsPrefix + "AutoScan";
        private const string KeyPlaceInScene    = PrefsPrefix + "PlaceInScene";
        private const string KeyExportPackage   = PrefsPrefix + "ExportPackage";
        private const string KeyRemapShaders    = PrefsPrefix + "RemapShaders";
        private const string KeyUseAssetRipper  = PrefsPrefix + "UseAssetRipper";
        private const string KeyAssetRipperExe  = PrefsPrefix + "AssetRipperExe";
        private const string KeyAutoMissingScriptPrompt = PrefsPrefix + "AutoMissingScriptPrompt"; 
        private const string KeyMissingScriptPolicy     = PrefsPrefix + "MissingScriptPolicy";     
        private const string KeyAutoReassignShaders     = PrefsPrefix + "AutoReassignShaders";     
        private const string KeyBackgroundImagePath     = PrefsPrefix + "BackgroundImagePath";     
        private const string KeyBackgroundOpacity       = PrefsPrefix + "BackgroundOpacity";       
        private const string KeyBackgroundScaleMode     = PrefsPrefix + "BackgroundScaleMode";     
        private const string KeyPreviewSkyboxPath       = PrefsPrefix + "PreviewSkyboxPath";       
        private const string KeyAutoDiagnosticsAfterExtract = PrefsPrefix + "AutoDiagnosticsAfterExtract"; 
        private const string KeyLastFilePath    = PrefsPrefix + "LastFilePath";
        private const string KeyWindowTab       = PrefsPrefix + "WindowTab";
        private const string KeyScanMode        = PrefsPrefix + "ScanMode";
        private const string KeyBackupDestPath    = PrefsPrefix + "BackupDestPath";    
        private const string KeyAutoBackupEnabled = PrefsPrefix + "AutoBackupEnabled"; 
        private const string KeyLanguage          = PrefsPrefix + "Language";          

        #endregion

        #region キャッシュ・出力フォルダー

        
        public static void SaveCachePath(string path)
            => EditorPrefs.SetString(KeyCachePath, path ?? string.Empty);

        
        public static string LoadCachePath()
            => EditorPrefs.GetString(KeyCachePath, string.Empty);

        
        public static void SaveAvatarOutput(string path)
            => EditorPrefs.SetString(KeyAvatarOutput, path ?? string.Empty);

        
        private const string DefaultAvatarOutput = "Assets/AvatarRecovery/Restored Avatar data";

        
        private const string DefaultWorldOutput  = "Assets/AvatarRecovery/Restored World data";

        
        private static readonly string[] LegacyAvatarDefaults =
        {
            "Assets/AvatarRecovery/Extracted",
        };

        
        private static readonly string[] LegacyWorldDefaults =
        {
            "Assets/AvatarRecovery/Worlds",
        };

        
        
        
        
        public static string LoadAvatarOutput()
        {
            var saved = EditorPrefs.GetString(KeyAvatarOutput, DefaultAvatarOutput);
            foreach (var legacy in LegacyAvatarDefaults)
            {
                if (string.Equals(saved, legacy, System.StringComparison.OrdinalIgnoreCase))
                {
                    
                    EditorPrefs.SetString(KeyAvatarOutput, DefaultAvatarOutput);
                    return DefaultAvatarOutput;
                }
            }
            return saved;
        }

        
        public static void SaveWorldOutput(string path)
            => EditorPrefs.SetString(KeyWorldOutput, path ?? string.Empty);

        
        
        
        
        public static string LoadWorldOutput()
        {
            var saved = EditorPrefs.GetString(KeyWorldOutput, DefaultWorldOutput);
            foreach (var legacy in LegacyWorldDefaults)
            {
                if (string.Equals(saved, legacy, System.StringComparison.OrdinalIgnoreCase))
                {
                    EditorPrefs.SetString(KeyWorldOutput, DefaultWorldOutput);
                    return DefaultWorldOutput;
                }
            }
            return saved;
        }

        
        public static void SavePackageOutput(string path)
            => EditorPrefs.SetString(KeyPackageOutput, path ?? string.Empty);

        
        public static string LoadPackageOutput()
            => EditorPrefs.GetString(KeyPackageOutput, string.Empty);

        #endregion

        #region オプションフラグ

        
        public static void SaveAutoScan(bool value)
            => EditorPrefs.SetBool(KeyAutoScan, value);

        
        public static bool LoadAutoScan()
            => EditorPrefs.GetBool(KeyAutoScan, false);

        
        public static void SavePlaceInScene(bool value)
            => EditorPrefs.SetBool(KeyPlaceInScene, value);

        
        public static bool LoadPlaceInScene()
            => EditorPrefs.GetBool(KeyPlaceInScene, false);

        
        public static void SaveExportPackage(bool value)
            => EditorPrefs.SetBool(KeyExportPackage, value);

        
        public static bool LoadExportPackage()
            => EditorPrefs.GetBool(KeyExportPackage, false);

        
        public static void SaveRemapShaders(bool value)
            => EditorPrefs.SetBool(KeyRemapShaders, value);

        
        public static bool LoadRemapShaders()
            => EditorPrefs.GetBool(KeyRemapShaders, false);

        
        public static void SaveUseAssetRipper(bool value)
            => EditorPrefs.SetBool(KeyUseAssetRipper, value);

        
        public static bool LoadUseAssetRipper()
            => EditorPrefs.GetBool(KeyUseAssetRipper, true);

        
        
        
        
        public static void SaveAssetRipperExePath(string path)
            => EditorPrefs.SetString(KeyAssetRipperExe, path ?? string.Empty);

        
        public static string LoadAssetRipperExePath()
            => EditorPrefs.GetString(KeyAssetRipperExe, string.Empty);

        
        
        
        
        
        public static void SaveAutoReassignShaders(bool value)
            => EditorPrefs.SetBool(KeyAutoReassignShaders, value);

        
        
        
        public static bool LoadAutoReassignShaders()
            => EditorPrefs.GetBool(KeyAutoReassignShaders, false);

        
        public static void SaveBackgroundImagePath(string path)
            => EditorPrefs.SetString(KeyBackgroundImagePath, path ?? string.Empty);

        
        public static string LoadBackgroundImagePath()
            => EditorPrefs.GetString(KeyBackgroundImagePath, string.Empty);

        
        public static void SaveBackgroundOpacity(float value)
            => EditorPrefs.SetFloat(KeyBackgroundOpacity, UnityEngine.Mathf.Clamp01(value));

        
        public static float LoadBackgroundOpacity()
            => UnityEngine.Mathf.Clamp01(EditorPrefs.GetFloat(KeyBackgroundOpacity, 0.3f));

        
        
        
        
        public static void SaveBackgroundScaleMode(int mode)
            => EditorPrefs.SetInt(KeyBackgroundScaleMode, mode);

        
        public static int LoadBackgroundScaleMode()
            => EditorPrefs.GetInt(KeyBackgroundScaleMode, 0);

        
        
        
        
        public static void SavePreviewSkyboxPath(string path)
            => EditorPrefs.SetString(KeyPreviewSkyboxPath, path ?? string.Empty);

        
        public static string LoadPreviewSkyboxPath()
            => EditorPrefs.GetString(KeyPreviewSkyboxPath, string.Empty);

        
        public static void SaveAutoDiagnosticsAfterExtract(bool value)
            => EditorPrefs.SetBool(KeyAutoDiagnosticsAfterExtract, value);

        
        public static bool LoadAutoDiagnosticsAfterExtract()
            => EditorPrefs.GetBool(KeyAutoDiagnosticsAfterExtract, false);

        
        
        
        public static void SaveMissingScriptPolicy(MissingScriptDeletePolicy value)
            => EditorPrefs.SetInt(KeyMissingScriptPolicy, (int)value);

        
        
        
        
        
        
        
        public static MissingScriptDeletePolicy LoadMissingScriptPolicy()
        {
            
            if (EditorPrefs.HasKey(KeyMissingScriptPolicy))
            {
                int raw = EditorPrefs.GetInt(KeyMissingScriptPolicy, (int)MissingScriptDeletePolicy.Always);
                
                if (raw < 0 || raw > (int)MissingScriptDeletePolicy.Never)
                    return MissingScriptDeletePolicy.Always;
                return (MissingScriptDeletePolicy)raw;
            }

            
            if (EditorPrefs.HasKey(KeyAutoMissingScriptPrompt))
            {
                var migrated = EditorPrefs.GetBool(KeyAutoMissingScriptPrompt, false)
                    ? MissingScriptDeletePolicy.Ask
                    : MissingScriptDeletePolicy.Always;
                EditorPrefs.SetInt(KeyMissingScriptPolicy, (int)migrated);
                EditorPrefs.DeleteKey(KeyAutoMissingScriptPrompt);
                return migrated;
            }

            return MissingScriptDeletePolicy.Always;
        }

        #endregion

        #region UI 状態

        
        public static void SaveLastFilePath(string path)
            => EditorPrefs.SetString(KeyLastFilePath, path ?? string.Empty);

        
        public static string LoadLastFilePath()
            => EditorPrefs.GetString(KeyLastFilePath, string.Empty);

        
        public static void SaveWindowTab(int index)
            => EditorPrefs.SetInt(KeyWindowTab, index);

        
        public static int LoadWindowTab()
            => EditorPrefs.GetInt(KeyWindowTab, 0);

        
        public static void SaveScanMode(int mode)
            => EditorPrefs.SetInt(KeyScanMode, mode);

        
        public static int LoadScanMode()
            => EditorPrefs.GetInt(KeyScanMode, 0);

        
        public static void SaveBackupDestPath(string path)
            => EditorPrefs.SetString(KeyBackupDestPath, path ?? string.Empty);

        
        public static string LoadBackupDestPath()
            => EditorPrefs.GetString(KeyBackupDestPath, string.Empty);

        
        public static void SaveAutoBackupEnabled(bool value)
            => EditorPrefs.SetBool(KeyAutoBackupEnabled, value);

        
        public static bool LoadAutoBackupEnabled()
            => EditorPrefs.GetBool(KeyAutoBackupEnabled, false);

        
        public static void SaveLanguage(AppLanguage lang)
            => EditorPrefs.SetInt(KeyLanguage, (int)lang);

        
        public static AppLanguage LoadLanguage()
        {
            int raw = EditorPrefs.GetInt(KeyLanguage, (int)AppLanguage.English);
            return System.Enum.IsDefined(typeof(AppLanguage), raw)
                ? (AppLanguage)raw
                : AppLanguage.English;
        }

        #endregion

        #region リセット

        
        public static void ResetAll()
        {
            EditorPrefs.DeleteKey(KeyCachePath);
            EditorPrefs.DeleteKey(KeyAvatarOutput);
            EditorPrefs.DeleteKey(KeyWorldOutput);
            EditorPrefs.DeleteKey(KeyPackageOutput);
            EditorPrefs.DeleteKey(KeyAutoScan);
            EditorPrefs.DeleteKey(KeyPlaceInScene);
            EditorPrefs.DeleteKey(KeyExportPackage);
            EditorPrefs.DeleteKey(KeyRemapShaders);
            EditorPrefs.DeleteKey(KeyUseAssetRipper);
            EditorPrefs.DeleteKey(KeyAssetRipperExe);
            EditorPrefs.DeleteKey(KeyAutoMissingScriptPrompt);
            EditorPrefs.DeleteKey(KeyMissingScriptPolicy);
            EditorPrefs.DeleteKey(KeyAutoReassignShaders);
            EditorPrefs.DeleteKey(KeyBackgroundImagePath);
            EditorPrefs.DeleteKey(KeyBackgroundOpacity);
            EditorPrefs.DeleteKey(KeyBackgroundScaleMode);
            EditorPrefs.DeleteKey(KeyPreviewSkyboxPath);
            EditorPrefs.DeleteKey(KeyAutoDiagnosticsAfterExtract);
            EditorPrefs.DeleteKey(KeyLastFilePath);
            EditorPrefs.DeleteKey(KeyWindowTab);
            EditorPrefs.DeleteKey(KeyScanMode);
            EditorPrefs.DeleteKey(KeyBackupDestPath);
            EditorPrefs.DeleteKey(KeyAutoBackupEnabled);
            EditorPrefs.DeleteKey(KeyLanguage);
        }

        #endregion
    }
}
