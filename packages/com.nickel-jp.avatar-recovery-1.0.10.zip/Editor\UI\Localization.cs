





using UnityEditor;

namespace EditorTools.AvatarRecovery
{
    public enum AppLanguage { English = 0, Japanese = 1 }

    
    public sealed class LS
    {
        
        public string HeaderSubtitle;
        public string ResetSettings;
        public string ResetConfirmTitle;
        public string ResetConfirmMsg;
        public string ResetBtn;
        public string Cancel;

        
        public string EncryptionWarning;

        
        public string TabFileSelect;
        public string TabMissingScripts;
        public string TabBackup;
        public string TabSettings;
        public string TabLicense;
        public string TabDiagnostics;
        private string[] _tabLabelsCache;
        public string[] TabLabels => _tabLabelsCache ??= new[]
            { TabFileSelect, TabMissingScripts, TabBackup, TabSettings, TabDiagnostics, TabLicense };

        
        public string FileSectionHeader;
        public string BrowseFileBtn;
        public string BrowseFileBtnTooltip;
        public string AddFromFolderBtn;
        public string AddFromFolderBtnTooltip;
        public string ClearListBtn;
        public string DropAreaHint;

        
        public string SelectedCountFmt;     
        public string PreviewBtn;
        public string PreviewBtnTooltip;
        public string NoFilesHelpBox;

        
        public string ExtractSingle;
        public string ExtractBatchFmt;      
        public string NeedFilesHelp;
        public string AllSkippedError;
        public string SomeSkippedFmt;       

        
        public string FileInfoHeader;
        public string LblFile;
        public string LblSize;
        public string LblLastModified;
        public string LblType;
        public string LblPlatform;
        public string LblUnityVersion;
        public string TypeAvatar;
        public string TypeWorld;
        public string TypeProp;
        public string Unknown;
        public string PlatformPC;
        public string PlatformQuest;
        public string PreviewFileBtn;
        public string PreviewFileBtnTooltip;

        
        public string DialogSelectFile;
        public string DialogSelectFolderForFiles;
        public string DialogSelectAvatarOutput;
        public string DialogSelectWorldOutput;
        public string DialogSelectPropOutput;
        public string DialogSelectPackageOutput;
        public string DialogSelectAssetRipper;
        public string DialogSelectBackground;

        
        public string FileAddedFmt;             
        public string AlreadyInList;
        public string NoFilesInFolder;
        public string FilesAddedFmt;            
        public string BatchProgressTitle;
        public string BatchSummaryFmt;          
        public string BatchMissingRemovedFmt;   
        public string BatchAutoRemovedFmt;      
        public string SarsSummaryHeader;
        public string FixScriptsFmt;            
        public string FixShadersFmt;            
        public string MissingRemovedFmt;        
        public string PoseResetFmt;             
        public string ShaderDetectedFmt;        
        public string BatchDiagnosticsFmt;      
        public string AutoReassignOn;
        public string AutoReassignOff;
        public string BatchCancelledByUser;
        public string BatchOtherLinesFmt;       

        
        public string MissingCleanupTitle;
        public string MissingCleanupMsgFmt;     
        public string MissingCleanupOk;
        public string MissingCleanupSkip;

        
        public string OutsideProjectTitle;
        public string OutsideProjectMsgFmt;     

        
        public string OutputFolderHeader;
        public string LblAvatarOutput;
        public string LblWorldOutput;
        public string LblPropOutput;
        public string LblPackageOutput;
        public string BrowseDots;
        public string OptionsHeader;
        public string PlaceInSceneLabel;
        public string PlaceInSceneTooltip;
        public string AutoReassignShadersLabel;
        public string AutoReassignShadersTooltip;
        public string AutoDiagnosticsAfterExtractLabel;
        public string AutoDiagnosticsAfterExtractTooltip;
        public string RemapShadersLabel;
        public string RemapShadersTooltip;
        public string ExportPackageLabel;
        public string ExportPackageTooltip;
        public float   SettingsLabelWidth;             
        public string MissingScriptPolicyLabel;
        public string MissingScriptPolicyTooltip;
        public string[] MissingScriptPolicyOptions; 
        public string AssetRipperHeader;
        public string AssetRipperExeLabel;
        public string AssetRipperExeTooltip;
        public string AssetRipperDetectedFmt;       
        public string AssetRipperNotFoundMsg;
        public string UseAssetRipperLabel;
        public string UseAssetRipperDisabledLabel;
        public string UseAssetRipperTooltip;
        public string AvailableShadersHeader;
        public string NoShadersWarning;
        public string SaveSettingsBtn;
        public string BackgroundHeader;
        public string BackgroundImageLabel;
        public string BackgroundImageTooltip;
        public string BackgroundClearBtn;
        public string BackgroundWrongFormat;
        public string BackgroundLoadedFmt;          
        public string BackgroundPending;
        public string BackgroundNotFoundFmt;        
        public string OpacityLabel;
        public string OpacityTooltip;
        public string ScaleModeLabel;
        public string ScaleModeTooltip;
        public string PreviewLabel;

        
        public string LicAvatarRecoveryDesc;
        public string LicMITLinkLabel;
        public string LicSarsDesc;
        public string LicSarsLinkLabel;
        public string LicAssetRipperDesc;
        public string LicAssetRipperDownloadLabel;
        public string LicDisclaimer;

        
        public string MSScanProgressTitle;
        public string MSDropHintNoTarget;
        public string MSDropHintHasTargetFmt;       
        public string MSScanHierarchyBtn;
        public string MSNoScanHelp;
        public string MSNoMissingHelp;
        public string MSRescanBtn;
        public string MSFilterLabel;
        public string MSInfoNoFilterFmt;            
        public string MSInfoFilterFmt;              
        public string MSSelectAllBtn;
        public string MSClearAllBtn;
        public string MSDeleteBtnFmt;               
        public string MSDeleteConfirmTitle;
        public string MSDeleteConfirmMsgFmt;        
        public string MSDeleteBtn;
        public string MSPrefabWarning;

        
        public string BPBackupHeader;
        public string BPBackupHelpBox;
        public string BPBackupToggle;
        public string BPDestLabel;
        public string BPBrowseBtn;
        public string BPBrowseFolderTitle;
        public string BPNoDestWarning;
        public string BPWatchingFmt;                
        public string BPDisabledMsg;
    }

    
    
    
    
    public static class Loc
    {
        public static readonly string[] LanguageNames = { "English", "日本語" };

        public static AppLanguage Current { get; private set; }

        public static LS S => Current == AppLanguage.English ? _en : _ja;

        private static readonly LS _en;
        private static readonly LS _ja;

        static Loc()
        {
            _en = BuildEnglish();
            _ja = BuildJapanese();
            Current = EditorPrefsHelper.LoadLanguage();
        }

        public static void SetLanguage(AppLanguage lang)
        {
            Current = lang;
            EditorPrefsHelper.SaveLanguage(lang);
        }

        
        #region English

        private static LS BuildEnglish() => new LS
        {
            
            HeaderSubtitle        = "AvatarRecovery — .vrca / .vrcw / .vrcp Extraction Tool",
            ResetSettings         = "Reset Settings",
            ResetConfirmTitle     = "Confirm",
            ResetConfirmMsg       = "Reset all settings to their defaults?",
            ResetBtn              = "Reset",
            Cancel                = "Cancel",

            
            EncryptionWarning =
                "Note: Recent versions of VRChat encrypt the cache. " +
                "Only files cached before encryption was introduced can be recovered.",

            
            TabFileSelect     = "File Select",
            TabMissingScripts = "Missing Scripts",
            TabBackup         = "Backup",
            TabSettings       = "Settings",
            TabLicense        = "License",
            TabDiagnostics    = "Diagnostics",

            
            FileSectionHeader      = "Select Target Files (multi-select supported)",
            BrowseFileBtn          = "Browse File...",
            BrowseFileBtnTooltip   =
                "Select and add a single .vrca / .vrcw / .vrcp file.\n" +
                "Click multiple times to add more files one by one.",
            AddFromFolderBtn       = "Add from Folder...",
            AddFromFolderBtnTooltip =
                "Select a folder and add all .vrca / .vrcw / .vrcp files found directly inside it.",
            ClearListBtn           = "Clear List",
            DropAreaHint           = "Drop .vrca / .vrcw / .vrcp files here (multiple files supported)",
            SelectedCountFmt       = "Selected: {0} file(s)",
            PreviewBtn             = " Preview",
            PreviewBtnTooltip      = "Preview this file inside Unity without extracting it",
            NoFilesHelpBox         =
                "Add .vrca / .vrcw / .vrcp files using the Browse button, the Add object field, or drag and drop.\n" +
                "Multiple files can be extracted in a single batch.",
            ExtractSingle          = "Extract",
            ExtractBatchFmt        = "Extract {0} Files",
            NeedFilesHelp          = "Select one or more files.",
            AllSkippedError        = "All selected files are encrypted or corrupted and cannot be extracted.",
            SomeSkippedFmt         = "{0} file(s) will be skipped (encrypted or corrupted).",

            
            FileInfoHeader         = "File Info",
            LblFile                = "File",
            LblSize                = "Size",
            LblLastModified        = "Last Modified",
            LblType                = "Type",
            LblPlatform            = "Platform",
            LblUnityVersion        = "Unity Version",
            TypeAvatar             = "Avatar (.vrca)",
            TypeWorld              = "World (.vrcw)",
            TypeProp               = "Prop (.vrcp)",
            Unknown                = "Unknown",
            PlatformPC             = "PC (Windows)",
            PlatformQuest          = "Quest (Android)",
            PreviewFileBtn         = "  Preview This File (no extraction)",
            PreviewFileBtnTooltip  =
                "Loads the AssetBundle into memory to preview the asset inside Unity.\n" +
                "No files are written to Assets/.\n" +
                "No separate Unity instance is launched.",

            
            DialogSelectFile           = "Select .vrca / .vrcw / .vrcp File",
            DialogSelectFolderForFiles = "Select Folder Containing .vrca / .vrcw / .vrcp Files",
            DialogSelectAvatarOutput   = "Select Avatar Output Folder",
            DialogSelectWorldOutput    = "Select World Output Folder",
            DialogSelectPropOutput     = "Select Prop Output Folder",
            DialogSelectPackageOutput  = "Select .unitypackage Output Folder",
            DialogSelectAssetRipper    = "Select AssetRipper.exe",
            DialogSelectBackground     = "Select Background Image",

            
            FileAddedFmt           = "Added: {0}",
            AlreadyInList          = "Already in the list.",
            NoFilesInFolder        = "No .vrca / .vrcw / .vrcp files found in the selected folder.",
            FilesAddedFmt          = "{0} file(s) added.",
            BatchProgressTitle     = "AvatarRecovery — Batch Extraction",
            BatchSummaryFmt        =
                "Batch extraction complete: {0} succeeded / {1} failed / {2} skipped (total: {3})",
            BatchMissingRemovedFmt = "  Missing Scripts removed (post-extraction prompt): {0}",
            BatchAutoRemovedFmt    = "  Successful files removed from list: {0}",
            SarsSummaryHeader      = "─ SARS Pipeline Summary ─",
            FixScriptsFmt          = "  FixScripts: {0} file(s) / {1} reference(s)",
            FixShadersFmt          = "  FixShaders: {0} file(s) / {1} reference(s)",
            MissingRemovedFmt      = "  Missing Scripts removed: {0}",
            PoseResetFmt           = "  Bind pose restored: {0}",
            ShaderDetectedFmt      =
                "  Shaders detected: {0} total / Shader list exported: {1} ({2})",
            BatchDiagnosticsFmt    =
                "  Diagnostics: Critical {0} / Warning {1} / Info {2}",
            AutoReassignOn         = "Auto-replace ON",
            AutoReassignOff        = "Auto-replace OFF",
            BatchCancelledByUser   = "⊘ Cancelled by user",
            BatchOtherLinesFmt     = "... {0} more",

            
            MissingCleanupTitle    = "Remove Missing Scripts",
            MissingCleanupMsgFmt   =
                "Run automatic Missing Script removal on {0} extracted Prefab(s)?\n\n" +
                "Remove: Opens each Prefab and deletes Missing Script components.\n" +
                "Skip: Does nothing (Missing Scripts remain in the extracted Prefab).",
            MissingCleanupOk       = "Remove",
            MissingCleanupSkip     = "Skip",

            
            OutsideProjectTitle    = "Folder Outside Project",
            OutsideProjectMsgFmt   =
                "The selected folder is outside the current Unity project.\n" +
                "Restored assets must be placed under Assets/, so the default path will be used.\n\n" +
                "Selected: {0}",

            
            OutputFolderHeader  = "Output Folder Settings",
            LblAvatarOutput     = "Avatar Output",
            LblWorldOutput      = "World Output",
            LblPropOutput       = "Prop Output",
            LblPackageOutput    = ".unitypackage Output",
            BrowseDots          = "Browse...",
            OptionsHeader       = "Options",
            PlaceInSceneLabel   = "Place in Scene After Extraction",
            PlaceInSceneTooltip =
                "Automatically places the extracted Prefab into the active scene.\n" +
                "Not recommended with the AssetRipper pipeline — the instance may appear empty immediately after restoration.\n" +
                "Instead, drag the Prefab from the Project window manually.",
            AutoReassignShadersLabel   = "Auto-Reassign Shaders (SARS)",
            AutoReassignShadersTooltip =
                "Within the SARS pipeline, automatically rewrites each material's m_Shader reference " +
                "to a matching shader (Poiyomi / lilToon / Standard) found in the project.\n\n" +
                "• OFF (default / recommended): No rewriting — original shader names are saved to\n" +
                "  \"_ShaderReport/Shaders.txt\" for manual reassignment. Materials will appear\n" +
                "  pink; use the list as a reference to reassign shaders manually.\n\n" +
                "• ON: Legacy behavior (v1.5 and earlier). Rewrites m_Shader automatically.\n" +
                "  (Shaders.txt is still generated either way.)",
            AutoDiagnosticsAfterExtractLabel = "Run Diagnostics After Extraction",
            AutoDiagnosticsAfterExtractTooltip =
                "After each successful extraction, runs a read-only upload preflight diagnosis on the restored Prefab.\n" +
                "This detects blueprint IDs, Missing Scripts, shader compile errors, and material issues without modifying assets.",
            RemapShadersLabel   = "Fix Pink Materials (Fallback)",
            RemapShadersTooltip =
                "After extraction, force-assigns remaining pink materials to Poiyomi / lilToon / Standard via the Unity API.\n" +
                "This operates independently from the SARS auto-reassign option above.",
            ExportPackageLabel   = "Export as .unitypackage",
            ExportPackageTooltip = "Exports the extracted assets as a .unitypackage file.",
            MissingScriptPolicyLabel   = "Missing Script Removal on Extraction",
            MissingScriptPolicyTooltip =
                "Controls when MissingScriptCleaner runs inside the SARS pipeline.\n\n" +
                "• Always (recommended): Removes Missing Scripts automatically during extraction.\n" +
                "• Ask: Shows a confirmation popup after extraction.\n" +
                "• Never: Skip removal. Use the Missing Scripts tab to clean up manually.",
            MissingScriptPolicyOptions = new[]
            {
                "Auto Remove (Recommended)",
                "Ask after Extraction",
                "Never Remove",
            },
            SettingsLabelWidth  = 320f,
            AssetRipperHeader   = "AssetRipper Settings",
            AssetRipperExeLabel = "AssetRipper.exe Path",
            AssetRipperExeTooltip =
                "Path to AssetRipper.exe. Leave blank for automatic detection in common locations.\n" +
                "Environment variables such as %USERPROFILE% are supported.",
            AssetRipperDetectedFmt    = "  ✓ Found: {0}",
            AssetRipperNotFoundMsg    =
                "AssetRipper.exe was not found.\n" +
                "Specify the path above, or place the executable in one of these locations:\n" +
                "  • %USERPROFILE%\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • C:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • D:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • C:\\Tools\\ARC\\Assets\\AssetRipper\\AssetRipper.exe\n" +
                "Download: https://assetripper.github.io/",
            UseAssetRipperLabel =
                "Use AssetRipper + SARS [Recommended]",
            UseAssetRipperDisabledLabel =
                "Use AssetRipper + SARS (exe not found)",
            UseAssetRipperTooltip =
                "Extracts assets with AssetRipper.exe, then runs AvatarRecovery's SARS-inspired " +
                "FixScripts / FixShaders / RemoveMissingScripts steps in sequence.\n" +
                "Fundamentally resolves missing VRCAvatarDescriptor components and pink materials.",
            AvailableShadersHeader = "Available Shaders",
            NoShadersWarning       =
                "Poiyomi / lilToon not found. Falling back to Standard shader.",
            SaveSettingsBtn        = "Save Settings",
            BackgroundHeader       = "Background Image (v1.8)",
            BackgroundImageLabel   = "Background Image",
            BackgroundImageTooltip =
                "Path to a PNG or JPEG file to display as the window background.\n" +
                "Leave blank for no background (Unity default).",
            BackgroundClearBtn     = "Clear",
            BackgroundWrongFormat  = "Please select a PNG or JPEG file.",
            BackgroundLoadedFmt    = "  ✓ Loaded: {0} × {1} px",
            BackgroundPending      = "  (will load on next draw)",
            BackgroundNotFoundFmt  = "File not found: {0}",
            OpacityLabel           = "Opacity",
            OpacityTooltip         =
                "Background image opacity (0 = fully transparent / 1 = fully opaque).\n" +
                "Around 0.3 is recommended to keep the UI readable.",
            ScaleModeLabel         = "Scale Mode",
            ScaleModeTooltip       =
                "StretchToFill: Stretches the image to fill the window (ignores aspect ratio)\n" +
                "ScaleAndCrop:  Fills while preserving aspect ratio, cropping any overflow\n" +
                "ScaleToFit:    Fits the image while preserving aspect ratio, leaving margins",
            PreviewLabel           = "Preview",

            
            LicAvatarRecoveryDesc =
                "This tool is distributed under the MIT License.\n" +
                "You are free to use, modify, redistribute, or use it commercially (attribution required).",
            LicMITLinkLabel            = "Full license text →",
            LicSarsDesc                =
                "This tool independently reimplements SARS algorithms and techniques in C#.\n" +
                "The SARS source code is neither bundled nor distributed.\n" +
                "SARS License: Custom license (redistribution of code is prohibited).\n" +
                "This tool is not subject to that restriction as it contains no SARS source code.",
            LicSarsLinkLabel           = "SARS Repository →",
            LicAssetRipperDesc         =
                "This tool launches AssetRipper as an external process.\n" +
                "AssetRipper itself is not bundled — please download and install it separately.\n" +
                "AssetRipper License: GNU General Public License v3.0 (GPL-3.0)\n" +
                "Because it is called as an external process, GPL copyleft obligations do not apply to AvatarRecovery itself.",
            LicAssetRipperDownloadLabel = "Download (via SARS Release.zip) →",
            LicDisclaimer =
                "This tool is provided \"as is\" without any warranty.\n" +
                "The developer is not liable for any damages resulting from its use.\n" +
                "Please ensure compliance with VRChat's Terms of Service and applicable copyright laws.",

            
            MSScanProgressTitle     = "AvatarRecovery — Missing Script Scan",
            MSDropHintNoTarget      = "Drag a GameObject or Prefab from the Hierarchy here",
            MSDropHintHasTargetFmt  = "▶ {0}\n[Drop another object to change target]",
            MSScanHierarchyBtn      = "Scan Entire Hierarchy",
            MSNoScanHelp            =
                "Click \"Scan Entire Hierarchy\" or drag a GameObject / Prefab into the area above.\n\n" +
                "• Multi-select: Shift+click for range / Ctrl+click for individual\n" +
                "• Checkbox toggles the individual row only",
            MSNoMissingHelp         = "No Missing Scripts found.",
            MSRescanBtn             = "Rescan",
            MSFilterLabel           = "Filter:",
            MSInfoNoFilterFmt       = "Found: {0}   Selected: {1}",
            MSInfoFilterFmt         = "Showing: {0}/{1}   Selected: {2}",
            MSSelectAllBtn          = "Select All",
            MSClearAllBtn           = "Clear All",
            MSDeleteBtnFmt          = "Delete Selected Missing Scripts  ({0})",
            MSDeleteConfirmTitle    = "Confirm Deletion",
            MSDeleteConfirmMsgFmt   =
                "Delete {0} selected Missing Script(s)?\n(Undoable with Ctrl+Z){1}",
            MSDeleteBtn             = "Delete",
            MSPrefabWarning         =
                "\n\nNote: Prefab instances are included.\n" +
                "You may need to Apply changes to the Prefab source.",

            
            BPBackupHeader      = "Auto Backup Settings",
            BPBackupHelpBox     =
                "When you build an avatar, the generated .vrca file is automatically copied to the specified folder.\n" +
                "The avatar name set in the SDK will be used as the filename.",
            BPBackupToggle      = "Auto-backup on build",
            BPDestLabel         = "Destination Folder",
            BPBrowseBtn         = "Browse...",
            BPBrowseFolderTitle = "Select Backup Destination",
            BPNoDestWarning     = "Please specify a destination folder.",
            BPWatchingFmt       = "Watching: {0}\nDestination: {1}",
            BPDisabledMsg       = "Auto-backup is disabled.",
        };

        #endregion

        
        #region Japanese

        private static LS BuildJapanese() => new LS
        {
            
            HeaderSubtitle        = "AvatarRecovery  —  .vrca / .vrcw / .vrcp 展開ツール",
            ResetSettings         = "設定リセット",
            ResetConfirmTitle     = "確認",
            ResetConfirmMsg       = "全設定を初期値に戻します。よろしいですか？",
            ResetBtn              = "リセット",
            Cancel                = "キャンセル",

            
            EncryptionWarning =
                "注意: 最新の VRChat はキャッシュを暗号化しているため、" +
                "暗号化以前に保存されたファイルのみ復元可能です。",

            
            TabFileSelect     = "ファイル指定",
            TabMissingScripts = "MissingScriptSearch",
            TabBackup         = "バックアップ",
            TabSettings       = "設定",
            TabLicense        = "ライセンス",
            TabDiagnostics    = "診断",

            
            FileSectionHeader      = "対象ファイルを選択 (複数選択可)",
            BrowseFileBtn          = "ファイルを選択...",
            BrowseFileBtnTooltip   =
                "1 つのファイルを選択して追加します。複数追加したい場合は何度かクリックしてください。",
            AddFromFolderBtn       = "フォルダーから一括追加...",
            AddFromFolderBtnTooltip =
                "フォルダーを選択し、その直下にある .vrca / .vrcw / .vrcp を全て追加します。",
            ClearListBtn           = "リストをクリア",
            DropAreaHint           = "ここに .vrca / .vrcw / .vrcp ファイル (複数可) をドラッグ＆ドロップ",
            SelectedCountFmt       = "選択中: {0} 件",
            PreviewBtn             = " プレビュー",
            PreviewBtnTooltip      = "このファイルを Unity 内でプレビュー (展開しない)",
            NoFilesHelpBox         =
                ".vrca / .vrcw / .vrcp ファイルを「参照...」ボタン、Add欄、またはドラッグ＆ドロップで追加してください。\n" +
                "複数のファイルを一括展開できます。",
            ExtractSingle          = "展開する",
            ExtractBatchFmt        = "{0} 件を一括展開する",
            NeedFilesHelp          = "ファイルを選択してください (複数可)。",
            AllSkippedError        = "選択したファイルはすべて展開できません (暗号化または破損)。",
            SomeSkippedFmt         = "{0} 件は暗号化/破損でスキップされます。",

            
            FileInfoHeader         = "ファイル情報",
            LblFile                = "ファイル",
            LblSize                = "サイズ",
            LblLastModified        = "更新日時",
            LblType                = "種別",
            LblPlatform            = "プラットフォーム",
            LblUnityVersion        = "Unity バージョン",
            TypeAvatar             = "Avatar (.vrca)",
            TypeWorld              = "World (.vrcw)",
            TypeProp               = "Prop (.vrcp)",
            Unknown                = "不明",
            PlatformPC             = "PC (Windows)",
            PlatformQuest          = "Quest (Android)",
            PreviewFileBtn         = "  このファイルをプレビュー (展開しない)",
            PreviewFileBtnTooltip  =
                "AssetBundle をメモリロードして Unity 内で対象アセットを確認します。\n" +
                "展開 (Assets/ への書き込み) は行いません。\n" +
                "別 Unity インスタンスは起動しません。",

            
            DialogSelectFile           = ".vrca / .vrcw / .vrcp ファイルを選択",
            DialogSelectFolderForFiles = ".vrca / .vrcw / .vrcp を含むフォルダーを選択",
            DialogSelectAvatarOutput   = "アバター出力先を選択",
            DialogSelectWorldOutput    = "ワールド出力先を選択",
            DialogSelectPropOutput     = "プロップ出力先を選択",
            DialogSelectPackageOutput  = ".unitypackage 出力先を選択",
            DialogSelectAssetRipper    = "AssetRipper.exe を選択",
            DialogSelectBackground     = "背景画像を選択",

            
            FileAddedFmt           = "追加しました: {0}",
            AlreadyInList          = "既にリストに含まれています。",
            NoFilesInFolder        = "選択フォルダーに .vrca / .vrcw / .vrcp が見つかりませんでした。",
            FilesAddedFmt          = "{0} 件のファイルを追加しました。",
            BatchProgressTitle     = "AvatarRecovery — 一括展開",
            BatchSummaryFmt        =
                "一括展開完了: 成功 {0} / 失敗 {1} / スキップ {2} (全 {3} 件)",
            BatchMissingRemovedFmt = "  Missing Script 削除 (展開後ポップアップ): {0} 個",
            BatchAutoRemovedFmt    = "  成功ファイルをリストから自動削除: {0} 件",
            SarsSummaryHeader      = "─ SARS パイプライン累計 ─",
            FixScriptsFmt          = "  FixScripts: {0} ファイル / {1} 参照",
            FixShadersFmt          = "  FixShaders: {0} ファイル / {1} 参照",
            MissingRemovedFmt      = "  Missing Script 削除: {0}",
            PoseResetFmt           = "  ボーン バインドポーズ復元: {0} 個",
            ShaderDetectedFmt      =
                "  検出シェーダー: 合計 {0} 件 / Shader一覧出力 {1} 件 ({2})",
            BatchDiagnosticsFmt    =
                "  診断結果: Critical {0} / Warning {1} / Info {2}",
            AutoReassignOn         = "自動置換 ON",
            AutoReassignOff        = "自動置換 OFF",
            BatchCancelledByUser   = "⊘ ユーザーによりキャンセルされました",
            BatchOtherLinesFmt     = "... 他 {0} 件",

            
            MissingCleanupTitle    = "Missing Script 削除確認",
            MissingCleanupMsgFmt   =
                "展開完了した {0} 件の Prefab に対して、Missing Script の自動削除を実行しますか?\n\n" +
                "OK: 各 Prefab を開いて Missing Script コンポーネントを削除します。\n" +
                "NO: 何もしません (Missing Script は復元 Prefab に残ります)。",
            MissingCleanupOk       = "OK (削除実行)",
            MissingCleanupSkip     = "NO (スキップ)",

            
            OutsideProjectTitle    = "プロジェクト外のフォルダ",
            OutsideProjectMsgFmt   =
                "選択したフォルダは現在の Unity プロジェクトの外にあります。\n" +
                "復元アセットは Assets/ 配下に出力する必要があるため、" +
                "デフォルトパスにフォールバックします。\n\n" +
                "選択: {0}",

            
            OutputFolderHeader  = "出力フォルダー設定",
            LblAvatarOutput     = "アバター出力先",
            LblWorldOutput      = "ワールド出力先",
            LblPropOutput       = "プロップ出力先",
            LblPackageOutput    = ".unitypackage 出力先",
            BrowseDots          = "参照...",
            OptionsHeader       = "動作オプション",
            PlaceInSceneLabel   = "展開後にシーンへ配置 (非推奨)",
            PlaceInSceneTooltip =
                "展開した Prefab をアクティブシーンに自動配置します。\n" +
                "AssetRipper パイプラインでは、復元直後にシーン配置すると " +
                "インスタンスが空になる場合があるため通常はオフのままにし、" +
                "必要に応じて Project ウィンドウから手動でドラッグしてください。",
            AutoReassignShadersLabel   = "Shader 自動再割り当て (SARS)",
            AutoReassignShadersTooltip =
                "SARS パイプライン内でマテリアルの m_Shader 参照を、プロジェクト内の\n" +
                "本物のシェーダー (Poiyomi / lilToon / Standard) に自動書き換えします。\n\n" +
                "・OFF (デフォルト・推奨): 書き換えは行わず、元シェーダー一覧のみ\n" +
                "  「_ShaderReport/Shaders.txt」として出力します。\n" +
                "  マテリアルはピンクで表示されるので、一覧を参考に手動で\n" +
                "  シェーダーを割り当て直してください (SARS 本来の思想)。\n\n" +
                "・ON: v1.5 以前の動作。マテリアルの m_Shader を自動書き換え。\n" +
                "  (書き換えた場合でも「_ShaderReport/Shaders.txt」は出力されます)",
            AutoDiagnosticsAfterExtractLabel = "展開後に自動診断",
            AutoDiagnosticsAfterExtractTooltip =
                "展開成功した Prefab に対して、読み取り専用のアップロード前診断を自動実行します。\n" +
                "Blueprint ID、Missing Script、shader compile error、Material 問題を検出しますが、アセットは変更しません。",
            RemapShadersLabel   = "ピンクマテリアル修正 (フォールバック)",
            RemapShadersTooltip =
                "展開後に Unity API 経由で、ピンクのまま残ったマテリアルの\n" +
                "シェーダーを Poiyomi / lilToon / Standard に強制フォールバック。\n" +
                "上記 SARS 自動再割り当てとは独立して動作する補助機能。",
            ExportPackageLabel   = ".unitypackage として出力",
            ExportPackageTooltip = "展開後に .unitypackage ファイルとして出力します",
            MissingScriptPolicyLabel   = "展開時の Missing Script 削除",
            MissingScriptPolicyTooltip =
                "SARS パイプライン内の MissingScriptCleaner の実行タイミングを制御します。\n\n" +
                "・自動削除: 展開時に常に削除 (推奨・現状の動作)\n" +
                "・展開後にポップアップで確認: OK/NO で都度判断\n" +
                "・削除しない: スキップ (後で MissingScriptSearch タブから手動削除可能)",
            MissingScriptPolicyOptions = new[]
            {
                "自動削除 (推奨)",
                "展開後にポップアップで確認",
                "削除しない",
            },
            SettingsLabelWidth  = 260f,
            AssetRipperHeader   = "AssetRipper 設定",
            AssetRipperExeLabel = "AssetRipper.exe パス",
            AssetRipperExeTooltip =
                "AssetRipper.exe の場所を直接指定します。\n" +
                "空欄の場合は %USERPROFILE%\\Tools\\AssetRipper\\, C:\\Tools\\AssetRipper\\ 等を自動検索します。\n" +
                "環境変数 (%USERPROFILE% 等) も使用可能。",
            AssetRipperDetectedFmt    = "  ✓ 検出済み: {0}",
            AssetRipperNotFoundMsg    =
                "AssetRipper.exe が見つかりません。\n" +
                "上の入力欄でパスを指定するか、以下のいずれかに配置してください:\n" +
                "  • %USERPROFILE%\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • C:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • D:\\Tools\\AssetRipper\\AssetRipper.exe\n" +
                "  • C:\\Tools\\ARC\\Assets\\AssetRipper\\AssetRipper.exe\n" +
                "ダウンロード: https://assetripper.github.io/",
            UseAssetRipperLabel =
                "AssetRipper + SARS パイプラインで展開 [推奨]",
            UseAssetRipperDisabledLabel =
                "AssetRipper + SARS パイプラインで展開 (AssetRipper.exe 未検出)",
            UseAssetRipperTooltip =
                "AssetRipper.exe で抽出後、SARS の手法を参考にした AvatarRecovery 独自の " +
                "FixScripts / FixShaders / RemoveMissingScripts 相当処理を順次実行します。\n" +
                "VRCAvatarDescriptor 等の Missing Script やピンク マテリアルを根本解決します。",
            AvailableShadersHeader = "利用可能なシェーダー",
            NoShadersWarning       =
                "Poiyomi / lilToon が見つかりません。Standard シェーダーにフォールバックします。",
            SaveSettingsBtn        = "設定を保存",
            BackgroundHeader       = "背景画像 (v1.8)",
            BackgroundImageLabel   = "背景画像ファイル",
            BackgroundImageTooltip =
                "ウィンドウ背景に表示する PNG / JPEG のファイルパス。\n" +
                "空欄にすると背景なし (Unity デフォルト)。",
            BackgroundClearBtn     = "クリア",
            BackgroundWrongFormat  = "PNG または JPEG ファイルを指定してください。",
            BackgroundLoadedFmt    = "  ✓ 読み込み成功: {0} × {1} px",
            BackgroundPending      = "  (次回描画時にロード)",
            BackgroundNotFoundFmt  = "ファイルが見つかりません: {0}",
            OpacityLabel           = "不透明度",
            OpacityTooltip         =
                "背景画像の不透明度 (0 = 完全透明 / 1 = 不透明)。\n" +
                "UI の視認性を保つため 0.3 前後を推奨。",
            ScaleModeLabel         = "描画モード",
            ScaleModeTooltip       =
                "StretchToFill: ウィンドウ全体に引き伸ばす (比率無視)\n" +
                "ScaleAndCrop:  アスペクト比を保ち、はみ出す部分をトリミング\n" +
                "ScaleToFit:    アスペクト比を保ち、余白を残して全体表示",
            PreviewLabel           = "プレビュー",

            
            LicAvatarRecoveryDesc =
                "本ツールは MIT License で配布しています。\n" +
                "使用・改変・再配布・商用利用はすべて自由です（著作権表示を残してください）。",
            LicMITLinkLabel            = "ライセンス全文 →",
            LicSarsDesc                =
                "本ツールは SARS のアルゴリズム・技術的手法を参考に C# コードを独自実装しています。\n" +
                "SARS 本体は同梱・配布していません。\n" +
                "SARS のライセンス: カスタムライセンス（コード再配布禁止）\n" +
                "本ツールは SARS 本体を同梱しないため上記制限の対象外です。",
            LicSarsLinkLabel           = "SARS リポジトリ →",
            LicAssetRipperDesc         =
                "本ツールは AssetRipper を外部プロセスとして呼び出します。\n" +
                "AssetRipper 本体は同梱していません。ユーザーが個別に取得・配置してください。\n" +
                "AssetRipper のライセンス: GNU General Public License v3.0 (GPL-3.0)\n" +
                "外部プロセス呼び出しのため GPL のコピーレフト義務は AvatarRecovery 本体には及びません。",
            LicAssetRipperDownloadLabel = "入手先 (SARS Release.zip) →",
            LicDisclaimer =
                "本ツールは現状有姿（AS IS）で提供されます。\n" +
                "使用によって生じたいかなる損害についても開発者は責任を負いません。\n" +
                "VRChat の利用規約および各国の著作権法を遵守した上でご使用ください。",

            
            MSScanProgressTitle     = "AvatarRecovery — Missing Script スキャン中…",
            MSDropHintNoTarget      = "Hierarchy の GameObject / Prefab をここにドラッグ&ドロップ",
            MSDropHintHasTargetFmt  = "▶ {0}\n[別のオブジェクトをドロップして変更]",
            MSScanHierarchyBtn      = "Hierarchy 全体をスキャン",
            MSNoScanHelp            =
                "「Hierarchy 全体をスキャン」を押すか、対象の GameObject / Prefab を上のエリアにドラッグ&ドロップしてください。\n\n" +
                "・複数選択: Shift+クリックで範囲選択 / Ctrl+クリックで個別選択\n" +
                "・チェックボックスは個別 ON/OFF 専用",
            MSNoMissingHelp         = "Missing Script は見つかりませんでした。",
            MSRescanBtn             = "再スキャン",
            MSFilterLabel           = "フィルター:",
            MSInfoNoFilterFmt       = "検出: {0} 件   選択中: {1} 件",
            MSInfoFilterFmt         = "表示中: {0} / {1} 件   選択中: {2} 件",
            MSSelectAllBtn          = "全選択",
            MSClearAllBtn           = "全解除",
            MSDeleteBtnFmt          = "選択した Missing Script を削除  ({0} 件)",
            MSDeleteConfirmTitle    = "Missing Script 削除確認",
            MSDeleteConfirmMsgFmt   =
                "選択した {0} 件の Missing Script を削除します。\n(Ctrl+Z で元に戻せます){1}",
            MSDeleteBtn             = "削除する",
            MSPrefabWarning         =
                "\n\n※ Prefab インスタンスが含まれています。\n  Prefab 元の変更には Apply が必要です。",

            
            BPBackupHeader      = "自動バックアップ設定",
            BPBackupHelpBox     =
                "アバターをビルドした際、生成された .vrca を自動的に指定フォルダへコピーします。\n" +
                "ファイル名は SDK で設定したアバター名が使用されます。",
            BPBackupToggle      = "ビルド時に自動バックアップ",
            BPDestLabel         = "保存先フォルダ",
            BPBrowseBtn         = "参照...",
            BPBrowseFolderTitle = "バックアップ先を選択",
            BPNoDestWarning     = "保存先フォルダを指定してください。",
            BPWatchingFmt       = "監視中: {0}\n保存先: {1}",
            BPDisabledMsg       = "自動バックアップは無効です。",
        };

        #endregion
    }
}
