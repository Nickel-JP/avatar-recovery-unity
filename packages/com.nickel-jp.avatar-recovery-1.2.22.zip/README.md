# AvatarRecovery 1.2.22 利用・導入・更新情報ガイド

AvatarRecovery は、VRChat の `.vrca` / `.vrcw` / `.vrcp` / `.vrcap` AssetBundle を Unity Editor 内で確認し、許可された範囲で Unity プロジェクトへ復元するための Editor 拡張です。

同梱された AssetRipper.exe を外部プロセスとして呼び出し、その後に AvatarRecovery 独自の C# 後処理で Script GUID、Shader GUID、Missing Script、Prefab 選択、Pose Reset の確認を補助します。AssetRipperについては、AssetRipper.exeおよび動作に必要な関連ファイルのみを同梱しています。AssetRipperとSARSのソースコードは同梱していません。

## 対象環境

| 項目 | 内容 |
|---|---|
| Unity | 2022.3.x (VCC 推奨) |
| OS | Windows 10 / 11 |
| VRChat SDK | `com.vrchat.base >=3.10.5 <3.11.0` |
| 同梱ツール | AssetRipper 1.3.14。利用者による別途配置・バージョン指定は不要 |
| 推奨 Shader | Poiyomi Toon Shader または lilToon |

Avatar プロジェクトでは `VRChat SDK - Avatars`、World プロジェクトでは `VRChat SDK - Worlds` を VCC または ALCOM から導入してください。Base と導入中の Avatars / Worlds は同じバージョンへ揃えてください。

1.2.22では、検証済み環境に合わせてSDK下限を3.10.5へ引き上げました。3.10.4以前のSDKを使用している場合は、SDKを更新してから1.2.22を導入してください。古い復元元データの読み取りや、Avatar／World構成に応じた処理は引き続き維持します。

Unity 2022.3.22f1 / VRChat SDK 3.10.5で、ソース段階の環境チェック36ケースと既存テスト41ケースが成功しています。

Shader Listsのキュー不明時の再割り当てについても、同環境のソース段階で回帰テスト63件が成功しています。旧レポート、空・無効なキュー、現在のキュー設定の保持、Shader既定値の選択、保存後の再読込・再実行、未選択Materialの保持を確認しました。

Materialに保存された描画設定については、Shader既定値と異なる20項目を持つ8個のMaterialを検証Bundleに保存し、抽出・Shader再割り当て・再実行・再読込後に元の値との一致を確認しました。Blend、Cull、ZWrite、ZTest、Stencilの参照値・マスク・比較と更新操作などが対象です。キュー不明時の再割り当てでも保持できました。この検証は保存値の復元確認であり、実アバターの描画比較は含みません。

## インストール

VCC から利用する場合は、以下の VPM リポジトリを追加します。

```text
https://nickel-jp.github.io/avatar-recovery-unity/index.json
```

GitHub Pages の追加ページ:

```text
https://nickel-jp.github.io/avatar-recovery-unity/add/
```

インストール後、Unity メニューの `AvatarRecovery → Open Window` からウィンドウを開きます。互換用に `Tools → AvatarRecovery` も残しています。

## AvatarRecovery Community Server

AvatarRecovery のアップデート情報の確認、バグ・不具合報告、利用者同士の情報共有を行える公式 Discord サーバーです。

[AvatarRecovery Community Serverに参加する方はこちらから](https://discord.gg/M9nFq8HXv)

## 同梱版 AssetRipper

AvatarRecovery は同梱ZIP内の AssetRipper 1.3.14 だけを使用します。初回利用時にプロジェクトの `Library/AvatarRecovery` 配下へ展開されるため、AssetRipper.exe の別途ダウンロード、任意バージョンの指定、パス設定は不要です。

## 基本操作

1. `File Recovery`（ファイル復元）タブで `.vrca` / `.vrcw` / `.vrcp` / `.vrcap` を追加します。
2. ファイル一覧は Avatar / World / Prop / Avatar Parts の種類別に常時見出し表示され、必要な種類だけ展開できます。
3. `復元履歴` では成功した復元をプロジェクトごとに最大 20 件まで保持し、復元順、容量順、拡張子順で確認できます。
4. `File Preview` ボタンで、展開せず AssetBundle 内の情報や GameObject プレビューを確認できます。
5. `Run` または `Run N Files` で解析・展開を実行します。
6. 復元物は種類ごとの既定フォルダーへ出力されます。

実行ボタンの下のコンソールには、バージョンと選択ファイル名、復元の進行状況を英語で表示します。成功は緑、ERRORは赤、Failedは赤紫です。最終成功時は `File restored successfully!!` と表示され、次のファイルの復元開始時に前の進行表示が消えます。元データの保持や処理のスキップは、復元全体の失敗とは区別して表示します。

既定出力先:

```text
Assets/AvatarRecovery/Restored Avatar data
Assets/AvatarRecovery/Restored World data
Assets/AvatarRecovery/Restored Prop data
Assets/AvatarRecovery/Restored Avatar Parts data
```

## 主なタブ

| タブ | 内容 |
|---|---|
| File Recovery | 対象ファイル追加、種類別一覧、復元履歴、View Assets Info、解析・展開、進行コンソール |
| MissingScriptSearch | Hierarchy / Prefab の Missing Script 検出と Undo 対応削除。Add 欄から対象を追加 |
| Backup | VRChat SDK ビルド時の `.vrca` 自動バックアップ |
| Settings | 出力先、同梱版AssetRipperの利用、Missing Script 削除ポリシー、利用可能なShader一覧など |
| Logs | 直近の一括実行結果を TXT / Markdown / CSV で出力 |
| License | AvatarRecovery、SARS、AssetRipper のライセンス情報 |
| GitHub/Discord | リリースノート、最新バージョン、導入・利用案内、公式 Discord サーバーへのリンク |

v1.1.0 では旧診断タブと自動診断処理を削除し、実行結果の保存は `Logs` タブへ移しました。

## View Assets Info

`View Assets Info` は `.vrca` / `.vrcw` / `.vrcp` / `.vrcap` を展開せずに確認するためのウィンドウです。

- GameObject がある AssetBundle は `PreviewRenderUtility` で隔離プレビューします。
- Scene-only の `.vrcw` など、GameObject プレビューがない AssetBundle は Scene パスと Asset 名を表示します。
- Camera は近距離に寄りすぎないよう、対象 Bounds に基づいて最小距離を制限します。
- Preview 中の Shader fallback は表示用の一時 Material にのみ適用され、展開時設定とは独立しています。

## Shader Lists

`AvatarRecovery → Open Shader Lists` から `_ShaderReport` を開けます。

- `MaterialShaderMap.csv` を使った `Material → Shader` 表示
- 元VRCAのデータに基づくRender Queueの数値表示。元Shader未導入でも確認でき、判定できない値は「不明」と表示
- 不明なキューは現在のMaterialのキュー設定を保持してShaderを再割り当て。キュー不明を理由とするスキップや自動ロールバックは行いません
- 不明時に割り当て先Shaderの既定値を使う設定も選択可能。現在のキュー設定を保持する場合も、その設定がShader既定値なら割り当て先Shaderの既定値を使用します
- `Shaders.txt` 表示
- `Original Shader` の名前を右クリックし「シェーダー名をコピー」で名前全体をコピー。未導入のShader名も対象で、「特定不可」の行はコピー不可
- Material 行の選択と、元 Shader 名に完全一致する `Shader.Find` 結果だけを使う再割り当て
- 復元と再割り当てでは、Material内に保存されたBlend、Cull、ZWrite、ZTest、Stencilなどの描画設定も保持。ShaderReportは対応表として使い、描画設定の保存値はMaterialで保持します
- 表示中 Material 行の全選択 / 全解除
- Match / Mismatch フィルターと、Match 先頭 / Mismatch 先頭ソート
- 複数の `_ShaderReport` フォルダー追加と表示切り替え

`MaterialShaderMap.txt` は互換用に生成されることがありますが、v1.1.0 のビューアでは専用タブを表示しません。

## 出力される主なファイル

```text
Restored .../
  _ShaderReport/
    Shaders.txt
    MaterialShaderMap.csv
    MaterialShaderMap.txt
  RawPoseBackup/
  PoseResetCandidate/
```

## ライセンス

AvatarRecovery v1.1.0 以降は AvatarRecovery Custom License で配布します。詳細は同梱の `LICENSE` を確認してください。

過去に MIT License で公開済みの AvatarRecovery 版は、公開時点で同梱されていたライセンス条件に従います。v1.1.0 以降の配布物には、この README と同梱 `LICENSE` の条件が適用されます。

AssetRipper と SARS は別プロジェクトです。AssetRipperについては、AssetRipper.exeおよび動作に必要な関連ファイルのみを同梱しています。同梱されたAssetRipper関連ファイルには、AvatarRecovery Custom Licenseではなく、それぞれの第三者ライセンスが適用されます。

## 利用上の注意

このツールは、自分のアセット、正当に購入したアセット、または明示的に許可を得たアセットの保守・復旧・検証を目的としています。

第三者の作品を無断で抽出、複製、再配布、販売、再アップロード、なりすまし利用する目的では使用しないでください。VRChat の利用規約、各アセットのライセンス、適用される法律を必ず守ってください。

## v1.2.21 の主な変更

- Shader Listsで、変換設定の数値やSDKの版数がShaderのバージョンとして誤表示される問題を修正しました。
- 属性、改行、引用符を含むバージョン表記の読み取りを改善しました。元データに版数がない場合や、候補が競合する場合は「不明」と表示します。
- 既存ShaderReportは引き続き読み込めます。過去の誤表示を修正するには、この版で空の出力フォルダーへ復元し、レポートを再生成してください。
- Unity 2022.3.22f1 / VRChat SDK 3.10.5でソースの回帰テスト34件が成功し、実データのPoiyomi 10.0.10を15 Shaderすべてで正しく取得しました。
- マテリアル保持とレンダーキューの動作は維持しています。VCCまたはALCOMでリポジトリを更新し、AvatarRecovery 1.2.21を選択してください。

## v1.2.20 の主な変更

- シェーダー再割り当てでレンダーキューが初期化される問題を修正し、色・数値・UV・タグ・キーワードなどのMaterial設定を保持
- Shader Listsに元データに基づくRender Queue表示を追加。元Shaderが未導入でも数値を確認可能
- 旧レポートの読込を維持。キュー情報を含まない旧レポートでは不明と表示されるため、元VRCAから再復元して新しいレポートを生成
- スキップ・仮置き換え・適用失敗を区別。スキップ時はMaterialを変更せず、適用後の自動ロールバックは実施しない
- 3D Textureと配列Textureの元寸法・画素配置を保持。直接保存できないShader参照や実行時Textureは失敗理由を表示し、AssetRipper経路を案内
- Unity 2022.3.22f1 / VRChat SDK 3.10.5で、8種類のキュー、15通りの操作、元Shader未導入時の数値表示、3D/配列Textureの画素一致を検証

## v1.2.16 の主な変更

- Behaviourを持つStateと同期Layerの復元を改善し、Animation設定・参照の保持を強化
- プロジェクトに同名Script型がある場合の復元停止を改善
- Animation後処理の整合性と診断を改善し、不要な復元停止を緩和
- AssetRipper選択時は直接復元へ自動切り替えせず、選択した方式を維持
- 「シェーダーエラー修正」「Shader自動再割り当て」を廃止。Shader Listsの操作・一覧出力は変更なし
- 通常ログを集約し、直接復元の重複したアセット取得を削減。警告・エラーの詳細は保持
- 直接復元のMaterial保存でGUIDエラーが生じる場合があります。今回の更新で全ての直接復元・Unityクラッシュを解消したものではありません
- VCCまたはALCOMでリポジトリを更新し、AvatarRecovery 1.2.16を選択してください

## v1.2.15 の主な変更

- `.vrcap` を `Avatar Parts` として追加し、専用一覧、出力先、プレビュー、復元履歴に対応
- 部品の姿勢を保つため、Avatar Partsでは姿勢リセットとアバター用Gesture Layer修正をスキップ
- Shader ListsのOriginal Shaderを右クリックして、表示が省略された長い名前も全体をコピー可能
- プロジェクトにないコンポーネントは未解決となる場合があります。削除は既存のMissing Scripts設定に従います
- VCCまたはALCOMでリポジトリを更新し、AvatarRecovery 1.2.15を選択してください

## v1.2.14 の主な変更

- VCCまたはALCOMで、Avatar ProjectとWorld ProjectのどちらからでもAvatarRecoveryを選択・導入できるよう修正
- Avatar専用機能はAvatar SDKがある場合だけ有効化し、World Projectでは既存のWorld復元機能をそのまま利用可能
- Unity 2022.3.22f1とVRChat SDK 3.10.xの既存対応範囲を維持

## v1.2.12 の主な変更

- AssetRipper 1.3.14と動作に必要な関連ファイルをZIPで同梱
- 外部のAssetRipper.exeを指定・検索する設定を廃止し、同梱版だけを使用する構成へ変更
- 既存の復元処理、AAO対応、Expression Menu追加復元、Shader・Missing Script修復の動作を維持

## v1.2.11 の主な変更

- 従来型のスキニング情報を必要としない正常なAAO生成Avatarで、復元が失敗する問題を修正
- AAO修復候補を採用できない場合、元のRaw Prefabを正常に再読み込みできるときだけRaw Prefabを維持して復元を継続
- バージョン1.2.10の復元手順と互換性を維持し、取り下げ済み1.3系のHotSwapおよびアニメーション処理変更は未導入
- Unity 2022.3.22f1でAAO復元回帰テスト15件がすべて成功し、復元済みAAO Avatarの実データでも確認
- VCCまたはALCOMでリポジトリを再読み込みし、AvatarRecoveryをバージョン1.2.11へ更新してください

## v1.2.10 の主な変更

- AvatarRecovery 1.2.9で、BoneWeightを使用しない正常なAAO生成メッシュが整合性検査により誤って復元失敗になる問題を修正
- BoneWeightを使用するメッシュに対するrootBone・使用ボーン・Prefab参照の安全検査を維持
- 問題が報告された2件のVRCAをUnity 2022.3.22f1で再検証し、AAO整合性検査を含む復元成功を確認
- VCCまたはALCOMでリポジトリを再読み込みし、AvatarRecoveryをバージョン1.2.10へ更新してください

## v1.2.9 の主な変更

- AssetRipperでExpression Menuを復元できるVRCAは、従来どおり既存の復元経路を使用
- Expression MenuがMissingになるVRCAでは、不足したMenuを追加復元
- 追加復元したRoot Menu、SubMenu、コントロール、パラメーター、アイコンをFinal PrefabとRaw Prefabの両方で検証
- 対応できないMenu構造では不完全な成果物を採用せず、従来の復元経路へ安全に戻る動作を維持
- AAO最適化済みAvatarの検出・メッシュ破綻修正・Pose Reset保護を維持
- Unity 2022.3.22f1で、通常復元、Menu追加復元、AAO修復済みAvatarの回帰検証を実施
- VCCまたはALCOMでリポジトリを再読み込みし、AvatarRecoveryをバージョン1.2.9へ更新してください

## v1.2.8 の主な変更

- Windows 標準のファイル・フォルダー選択とフォルダー列挙を Unity Editor のメインスレッド外で処理し、選択画面で発生する停止を軽減
- 多数の選択結果を段階的に一覧へ追加し、AvatarRecovery ウィンドウが一度に長時間停止する問題を軽減
- 復元履歴の表示、AssetRipper の検索、背景画像の読み込みで繰り返される処理を削減
- 選択キャンセル、スクリプト再読み込み、Unity 終了時の Windows 標準ダイアログ解放を改善
- Face アニメーション選別と Blueprint ID 消去を含む、既存の展開・復元工程を維持
- VCC または ALCOM でリポジトリを再読み込みし、AvatarRecovery をバージョン 1.2.8 へ更新してください

## v1.2.7 の主な変更

- Windows 標準の選択画面で Ctrl キーを使用し、複数の復元ファイルまたは複数の対象フォルダーをまとめて追加可能
- AvatarRecovery の Console 出力が、他の Unity Editor ツールで使用されるログ設定を変更しないよう改善
- 既存の色分け表示を維持し、一括実行結果をピンク色の見出しと緑色の詳細を持つ1件の `[Batch Extraction Complete]` エントリへ集約
- Face アニメーション選別や Blueprint ID 消去を含む、既存の復元動作を維持
- Unity 2022.3.22f1 で `Selena_sample.vrca` の復元工程を検証し、1件の復元成功と成功実行中のエラー0件を確認
- VCC または ALCOM でリポジトリを再読み込みし、AvatarRecovery をバージョン 1.2.7 へ更新してください

## v1.2.6 の主な変更

- `GitHub` タブを `GitHub/Discord` に変更し、公式 Discord サーバーの説明と参加リンクを追加
- GitHub タブに、公式リポジトリから取得した最新3件の更新履歴を表示
- Unity 起動時はバックグラウンドで更新を確認し、明確にオフラインの場合は通信を実行しない
- GitHub タブの「リロード」から、ユーザー操作で最新情報を再取得可能
- 更新履歴は原文を保持し、ツール内で「原文」と「日本語訳」を切り替え可能
- オフラインまたは取得失敗時は、保存済みの履歴があれば継続表示
- 一括実行結果を「Run」ボタン下から Unity Console へ移し、「Logs」のレポートは継続して利用可能
- 「Run」ボタン下に、導入中の AvatarRecovery バージョン、Unity バージョン、および GitHub 情報に基づく更新状況を表示
- 過去の出力削除後に残る Unity 内部情報を、実在するアセットの GUID 衝突として誤検出しないよう改善
- Missing Script を含む Prefab は自動 Pose Reset の保存対象から安全に除外し、Prefab 保存エラーを防止
- 以前の 1.2.6 を導入済みの場合は、VCC または ALCOM でリポジトリを再読み込みしてから 1.2.6 を再インストールしてください

## v1.2.5 の主な変更

- 長時間かかる AssetRipper の展開が、処理中にもかかわらず途中で失敗扱いになる問題を修正
- 実行開始から 60 分経過しても自動停止せず、`待機`または`キャンセル`を選べる継続確認を表示
- `待機`を選んだ場合は処理を継続し、その後も 60 分ごとに継続確認を表示
- AssetRipper 実行中のキャンセル処理と、失敗時の診断情報・一時出力の取り扱いを改善

## v1.2.4 の主な変更

- Unity の AvatarRecovery メニューに、表示言語に関係なく `Language` と表示される言語切り替えを追加
- `Language` 配下の `Japanese` / `English` から言語を選択でき、ツール内の言語切り替えと双方向に連動して保存
- ツール内に `GitHub` 案内タブを追加し、リリースノート、最新バージョン、導入・利用案内を確認できる公式ページへのリンクを日英で表示
- Unity メニューの説明書を `AvatarRecovery > Manual` へ英語化
- 説明書のウィンドウ名と全文を日英対応し、ツールおよびメニューの言語設定へ即時連動

## v1.2.3 の主な変更

- Unity の AvatarRecovery メニューに表示する項目を整理
- PhysBone・Contact 参照チェックと Scene の旧復元配置クリーンアップ機能は内部に保持したまま、メニューから非表示化

## v1.2.2 の主な変更

- AssetRipper の反映用一時ファイルを、元のファイル名へ接尾辞を追加せず、同じディレクトリ内の短い一時名で作成
- 250 文字の AnimationClip・Material と 255 文字の meta ファイルを含む長いパスの処理を修正
- Script・Shader GUID 修正と GUID 衝突検査でも長いパスを一貫して処理

## v1.2.1 の主な変更

- 配布パッケージのセキュリティ保証範囲と制限を明確化
- 意図した安全性に寄与しない保護動作を整理
- リリース検証と回帰テストを強化

## セキュリティモデルと限界

公開検証情報は配布物の完全性確認を支援します。期待値は独立して信頼できる経路から取得してください。同じ配布元だけから取得した情報は、それ単独では信頼の起点になりません。

クライアントへ配布されるコードは、機密性や改変不能性を保証しません。真に秘密である必要がある処理は、管理されたサーバー側へ置いてください。
## v1.2.0 の主な変更

- 既存の復元機能を維持したまま、主要な復元工程の安定性を改善
- 抽出、復元、自動バックアップ処理が継続できない場合に、失敗理由と推奨する解決方法をポップアップ表示
- Unity 起動時に誤って AvatarRecovery が利用できなくなる問題を修正

## v1.1.20 の主な変更

- Shader Lists の `Material → Shader` 表示で、表示中 Material 行を全選択 / 全解除できるように変更
- Match / Mismatch フィルターを追加。どちらも未選択の場合は両方を表示
- 元の順、Match 先頭、Mismatch 先頭のソートを追加

## v1.1.19 の主な変更

- 復元履歴を Unity プロジェクト単位で保存するよう変更
- Unity プロジェクトを閉じて開き直しても、同じプロジェクトの復元履歴が残るよう改善
- 復元履歴の保存件数を最新 20 件までに制限

## v1.1.18 の主な変更

- 復元履歴を読み込む際に Unity Console へ `The same field name is serialized multiple times` が出る問題を修正
- 復元後に File Select タブの復元履歴を開いても、履歴読み込みが止まらないよう改善

## v1.1.17 の主な変更

- Unity のドメインリロード時に古いログ handler が残らないよう、Editor 再読み込み前にログ handler を復元
- Unity 起動直後に package DLL の場所が一時的に取得できない場合、警告を固定せず遅延再確認するよう改善

## v1.1.16 の主な変更

- File Select に `復元履歴` 折り畳みメニューを追加
- 復元履歴を復元順、容量順、拡張子順 `.vrca` / `.vrcw` / `.vrcp` でソート可能に変更
- 履歴行を `復元名 [.vrca]` のように表示し、クリックで復元先へ移動できるよう改善

## v1.1.8 の主な変更

- File Select の各ファイル行にあるプレビューボタン表記を `File Preview` に変更

## v1.1.7 の主な変更

- `View Assets Info` で scene-only の `.vrcw` を開いた時に、Unity の GameObject 読み込み API を呼ばないよう修正
- scene-only AssetBundle は Scene パスと Asset 名を表示し、`This method cannot be used on a streamed scene AssetBundle` 例外を出さないよう改善
- 直接 AssetBundle 解析経路でも streamed scene AssetBundle への `LoadAllAssets` 呼び出しを回避

## v1.1.2 の主な変更

- VPM package と repository metadata を v1.1.2 向けに更新
- Unity メッセージ、VRC SDK callback、package metadata、VPM index fields の互換性を維持

## v1.1.1 の主な変更

- MissingScriptSearch の対象追加 UI を大きな D&D 欄から Add 式の ObjectField 行へ変更
- MissingScriptSearch は Add 欄へのドラッグまたは選択で GameObject / Prefab を追加し、複数対象の追加式スキャンを維持
- File Select の Avatar / World / Prop 折り畳み見出しは常時表示のまま、初期状態を閉じる形へ変更

## v1.1.0 の主な変更

- UI 名称を `AvatarRecovery` / `View Assets Info` / `Run` 系へ整理
- File Select の未選択時ヘルプを簡素化
- Avatar / World / Prop 折り畳みを追加
- `Shader Error Fix` 表記へ変更
- `MaterialShaderMap.txt` タブを削除
- 旧診断タブと自動診断処理を削除
- `Logs` タブを追加し、実行結果の TXT / Markdown / CSV 出力に対応
- 初回利用時の同意画面を追加。同意しない場合もファイル削除は行いません
- `View Assets Info` の scene-only `.vrcw` 情報表示とカメラ距離制御を改善
- MissingScriptSearch の D&D を追加式に変更
- ライセンスを AvatarRecovery Custom License へ変更
